/* 
* File: LipSync_Firmware.ino
* Firmware: LipSync
* Developed by: MakersMakingChange
* Version: v4.1 (28 March 2025)
  License: GPL v3.0 or later

  Copyright (C) 2024 - 2025 Neil Squire Society
  This program is free software: you can redistribute it and/or modify it under the terms of
  the GNU General Public License as published by the Free Software Foundation,
  either version 3 of the License, or (at your option) any later version.
  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  You should have received a copy of the GNU General Public License along with this program.
  If not, see <http://www.gnu.org/licenses/>
*/

#include <WString.h>
#include <Wire.h>
#include <FreeRTOS.h>  // 4.5.10: the BLE init task's static allocation (see setup)
#include <task.h>
#include "LSUtils.h"
#include "LSApiDeclarations.h"  // Explicit cross-tab declarations (roadmap item 5) — early so every tab sees them
#include "LSConfig.h"
#include "LSI2CScan.h"  // 4.9.8: the boot I2C scan's pure layer (self-contained — carries its own CONF_I2C_SCAN_* constants)
#define LSTIMER_USE_SERIAL_TX_QUEUE 1  // Normal-context timer diagnostics share the line-safe CDC queue
#include "LSTimer.h"
#include <ArduinoJson.h>
#include "LSOutput.h"
#include "LSUSB.h"
#include "LSBLE.h"
#include "LSCircularBuffer.h"
#include "LSInput.h"
#include "LSPressure.h"
#include "LSJoystick.h"
#include "LSMemory.h"
#include "LSScreen.h"
#include "LSBuzzer.h"
#include "LSWatchdog.h"

// 4.9.1: the host-compiled classifier's state numbers are mirrored into the
// SAP action-table rows by hand (LSPressureClassify.h deliberately compiles
// without LSConfig.h, so the pin lives HERE, where both headers are
// visible) — the same static_assert treatment the release fraction already
// has in LSPressure.h. A silent renumber of either side would remap the
// hard sip/puff actions or route them to an inert row: the hard rows are
// the mobility-critical instant-DRAG/SCROLL path for users who cannot
// sustain holds.
static_assert(LSPRESSURE_CLASSIFY_NONE == PRESS_SAP_MAIN_STATE_NONE &&
              LSPRESSURE_CLASSIFY_SIP == PRESS_SAP_MAIN_STATE_SIP &&
              LSPRESSURE_CLASSIFY_PUFF == PRESS_SAP_MAIN_STATE_PUFF &&
              LSPRESSURE_CLASSIFY_HARD_SIP == PRESS_SAP_MAIN_STATE_HARD_SIP &&
              LSPRESSURE_CLASSIFY_HARD_PUFF == PRESS_SAP_MAIN_STATE_HARD_PUFF,
              "LSPressureClassify state numbers must mirror PRESS_SAP_MAIN_STATE_*");

// Unique ID
String g_deviceUID = "";  // Global variable for storing unique identifier for board

// Communication mode and debug mode variables
int g_comMode;        // 0 = None , 1 = USB , 2 = Wireless
int g_operatingMode;  // 0 = None, 1 = Mouse, 2 = Gamepad, 3 = Safe
int g_soundMode;      // 0 = None, 1 = Basic, 2 = Advanced // TODO 2025-Feb-05 Currently not used - buzzer.begin sets sound mode from memory
int g_lightMode;      // 0 = None, 1 = Basic, 2 = Advanced

int g_debugMode;  // 0 = Debug mode is Off
                  // 1 = Joystick debug mode is On
                  // 2 = Pressure debug mode is On
                  // 3 = Buttons debug mode is On
                  // 4 = Switch debug mode is On
                  // 5 = Sip & Puff state debug mode is On

int g_errorCode = 0;  // Global variable for storing error code. 0 is no error. Additional errors defined in LSConfig.h

uint32_t g_lastRebootReason = 0;
bool g_watchdogReset = false;
uint8_t g_watchdogBootCount = 0;  // Consecutive watchdog-reset boots (see LSWatchdog.h)
uint8_t g_hangBootStreak = 0;     // Consecutive TIMER3-witnessed loop-hang deaths (survives the SREQ resets via GPREGRET2 bits 0-1 — see checkResetReason)
bool g_usbRecoveryRestartedPrev = false; // True only on the immediate successor of the automatic USB-recovery reset
bool g_safeModeEnabled = false;
int  g_safeModeReason = 0;
bool readyToUseFirstTime = true;

bool g_btIsConnected = false;   // Bluetooth connection state

bool g_displayConnected = false;                   // Display connection state
bool g_joystickSensorConnected = false;            // Joystick sensor connection state
bool g_mouthpiecePressureSensorConnected = false;  // Mouthpiece pressure sensor connection state
bool g_ambientPressureSensorConnected = false;     // Ambient pressure sensor connection state

// LED module variables. Static storage avoids a boot-time heap allocation for
// an object that lives for the entire firmware lifetime.
ledStateStruct ledCurrentStateStorage = {0, 0, 0, 0, 0, 0};
ledStateStruct* const ledCurrentState = &ledCurrentStateStorage;
bool ledActionEnabled = false;

// Input module variables
int buttonActionSize, switchActionSize;
unsigned long buttonActionMaxTime, switchActionMaxTime;
inputStateStruct buttonState, switchState;

int inputButtonPinArray[] = { CONF_BUTTON1_PIN, CONF_BUTTON2_PIN };
int inputSwitchPinArray[] = { CONF_SWITCH1_PIN, CONF_SWITCH2_PIN, CONF_SWITCH3_PIN };

LSInput ib(inputButtonPinArray, CONF_BUTTON_NUMBER);  // Instance of input button object (tactile buttons on Hub)
LSInput is(inputSwitchPinArray, CONF_SWITCH_NUMBER);  // Create an instance of the input switch object (external switches)

inputStateStruct sapActionState;

int sapActionSize;
unsigned long sapActionMaxTime = 0;

// Timer related variables
int actionTimerId[8] = {-1, -1, -1, -1, -1, -1, -1, -1};  // Independent B1-B8 pulse-release timers
LSTimer<int> actionTimer;

int calibrationTimerId[2] = {-1, -1};  // 2 calibration timers: 0 - , 1-
LSTimer<int> calibrationTimer;

int pollTimerId[10] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};  // 9 poll timers — the CAPTURED ids (4.5.7 review): every enable/disable path must use these, not the CONF_TIMER_* constants; the two are equal only while every boot registration lands sequentially into an empty pool, and one refused registration or reorder away from the constants is disabling the WRONG feature's loop
LSTimer<void> pollTimer;

int ledTimerId[5] = {-1, -1, -1, -1, -1};  // LED timers 0 - startup feedback, 1 - IBM, 2- normal blinks, 3 - Bluetooth Status, 4 - error — -1 = none registered (4.5.7 review: zero-init made blinkLed's delete-before-rearm guard delete pool slot 0 on its first call)
LSTimer<ledStateStruct> ledStateTimer;

int usbConnectTimerId[1] = {-1};
LSTimer<int> usbConnectTimer;
static void usbConnectRearm(unsigned long delayMs);  // 4.6.6: delete-before-arm one-shot re-arm — defined before usbCheckConnection; called from setup() (no Arduino auto-prototype reliance, the 4.3.0 discipline)
void usbEventDrain();  // 4.9.9 review round 3: emit the TinyUSB mount/unmount debug lines from the LOOP task (defined at the callbacks) — the hooks run in the TinyUSB task, whose direct Serial.print interleaved with the TX queue's chunked writes at chunk granularity

unsigned int g_usbConnectDelay = CONF_USB_HID_INIT_DELAY;
unsigned long g_usbNotReadySinceMs = 0;  // When the current HID-not-ready stretch began; 0 = none in progress
unsigned int g_usbReenumCount = 0;        // Forced re-enumerations spent on the current episode
unsigned long g_watchdogLastFeedMs = 0;   // Loop-liveness witness (bench 2026-10-18): ms timestamp of the last watchdog feed
volatile bool g_watchdogArmed = false;   // True from initWatchdog() until the retry limit stops re-arming (ISR-read by the TIMER3 witness — 4.5.7 review)
// The USB-recovery auto-restart once-guard: a full chip reset is the one cure
// that has cleared every configured-but-HID-dead boot on the bench
// (2026-10-17: a wedge survived all three forced re-enumerations), but an
// automatic restart must never loop. (4.9.0 review: this block formerly
// described a .noinit word written with CONF_USB_RESTART_MAGIC — both the
// macro and the mechanism are GONE: the bench proved .noinit does not
// survive resets on this platform, and the guard lives in the retention
// marker CONF_RETENTION_MARKER_USB_RECOVERY / g_usbRecoveryRestartedPrev
// since witness v5. Do not resurrect the .noinit word.)
// WITNESS v4 + PLATFORM FIX (bench 2026-10-23): the .noinit section DOES NOT
// survive resets on this platform — the bench proved it (every soft-reset and
// watchdog boot read boot#1/ptrail=0 back; the map places the section at
// 0x20007bac but its content is zeroed by the time the next boot's setup()
// runs — the bootloader/core scrubs it). Every cross-reset word therefore
// moves to the nRF52 POWER RETENTION REGISTERS, which survive every warm
// reset and clear only on cold power-on. (4.9.0 review: the v4 bit-map block
// below was removed — it mapped GPREGRET2 bits 8-31 to trail/USB-guard/boot
// counter, a layout the register does not have; witness v5 corrected it
// (GPREGRET2 is 8 bits wide) and v7 is the live record of the real layout.
// A future contributor reading only v4 would have written fields into
// unimplemented bits and silently lost them.)
// WITNESS v5 (bench 2026-10-23): the platform offers NO reliable cross-reset
// storage — the retention register GPREGRET2 is 8 bits wide (SVD: only bits
// 0-7 implemented; the 4.2.0 watchdog counter lives there), GPREGRET belongs
// to the bootloader's DFU magic, and the .noinit section is wiped by the
// boot path (the map even shows its orphan placement straddling
// __bss_start__, so most of it lands inside the bss-clear loop). The trail
// is therefore a plain RAM byte, printed live by the HB line: for a freezing
// boot, the LAST PRINTED trail names the site the loop died at. Cross-reset
// questions are answered by rst= (the nRF52 RESETREAS register — the one
// reset fact that does survive).
// WITNESS v7 (bench 2026-10-23): the freeze's CPU does NOT hardfault (the
// Seeed core's HardFault_Handler is an instant NVIC_SystemReset — a fault
// would read rst=0x4 on the next boot; every freeze successor reads rst=0x2,
// the 30-s watchdog: the CPU is SPINNING, not faulting) — and every bounded
// wait in the Wire/Tone/HardwarePWM paths checks out, so the spin site is
// somewhere no witness has survived to report: RAM dies at the reset. The
// trail therefore moves into the retention register's spare bits
// (GPREGRET2 bits 5-7 — the watchdog counter only needs bits 0-1): the last
// 3-bit milestone a dying boot stamped SURVIVES the watchdog reset, and the
// next boot prints it as pt=. Trail codes (3 bits): 1 setup-done, 2
// safeModePage, 3 safeMenu, 4 LED action, 5 softwareReset, 6
// usbCheckConnection.
uint8_t g_bootTrailPrev = 0;  // The DEAD boot's last trail code (read from retention at setup)
uint8_t g_hangMarkerPrev = 0;  // The DEAD boot's hang-witness marker (retention bits 2-4)
volatile bool g_shutdownInProgress = false;  // witness v9: softwareReset's deliberate blocking shutdown is NOT a hang — the witness exempts it
// (4.5.7 review) Seconds since the loop last fed the watchdog, counted BY
// THE WITNESS ITSELF: the old ISR called millis() (a FreeRTOS xTaskGetTickCount
// read — unsupported use at interrupt priority 0) and read non-volatile
// globals shared with loop context. The counter is a single aligned volatile
// word: the ISR increments it on every 1 s tick, watchdogLoop() (loop
// context) writes it back to 0 on every feed — a 32-bit aligned store/load
// is atomic on the ARM, so the worst case of the race is one tick of lag.
// >3 consecutive un-fed seconds (counter reaches 4) is a loop hang.
volatile uint32_t g_witnessSecondsUnfed = 0;
// 4.5.27 (Fable 5.1 consult): these were RAW POWER-peripheral writes — the
// SoftDevice's watch unit flags every one with the SD up (APP_MEMACC, the
// root cause of the entire 4.5.6-4.5.26 BLE death saga: the stamps were the
// killer, the "death sites" the stamps named were the stamp's own callers).
// Both now route through the SD-aware helper: the SVC path with the stack
// up, the raw write when it is down.
uint8_t readTrailByte()            { return (lipsyncRetentionGet(1) >> 5) & 0x07; }
void writeTrailByte(uint8_t step)  {
  // 4.6.6: inside the Bluefruit.begin() window the SD is already enabled but
  // g_softDeviceEnabled cannot be true yet (raising it early would send SD
  // SVCs into the core's FreeRTOS SVC trampoline with the SD down — worse
  // than the fault). The loop task runs time-sliced with the 16 KB init
  // task, so a pt=4 (LED action) or pt=7 (serial dispatch) stamp landing in
  // that window would take the RAW GPREGRET path with the SD up — the exact
  // APP_MEMACC death 4.5.27 eliminated. Stamps are pure forensics: skip the
  // write for the sub-second window; every post-init path stamps normally.
  if (lipsyncRetentionUnsafe()) return;
  lipsyncRetentionUpdate(1, 0xE0, (uint8_t)((step & 0x07) << 5));
}

// WITNESS v8 — THE HANG WITNESS (bench 2026-10-23): this round proved the
// freeze ends in a WATCHDOG reset that WIPES GPREGRET2 (every freeze
// successor read pt=0 while the dead boot demonstrably stamped trail=1/3;
// SREQ resets preserve it — pt=5 survived every SR). So the freeze's death
// site could never be reported. This converts the freeze's silent DOG death
// into an SREQ the trail survives: TIMER3 (free — the core only touches
// TIMER2 read-only for the bootloader version) fires an interrupt every
// second and watches the loop's watchdog feed stamp — the loop pass
// refreshes it on every iteration. If the loop hangs for >3 s, the IRQ
// writes a hang marker into retention bits 2-4 and resets via
// NVIC_SystemReset (SREQ): the trail bits 5-7 SURVIVE, the next boot prints
// pt= (the last milestone the dead boot stamped) and pm=1 (hang witnessed),
// and the bench cycle drops from 30 s to ~4 s. If the hang instead masks
// interrupts, the IRQ never fires and the hardware DOG still ends it
// (pt=0) — that split (pm=1 vs pm=0) is itself decisive: IRQs-live hang vs
// IRQs-masked hang.
//
// 4.5.13: declared up here because initHangWitness() reads it at ARM time.
// A BLE boot has the SoftDevice enable still PENDING when the witness arms
// (the init task starts at the very END of setup), so the witness must
// take an SD-legal priority from the start — see the priority note in the
// body below. g_bleInitPending is set by beginComOpMode long before this
// point in setup.
static volatile bool g_bleInitPending = false;   // a BLE boot deferred its init to the task
void initHangWitness() {
  NRF_TIMER3->MODE = TIMER_MODE_MODE_Timer << TIMER_MODE_MODE_Pos;
  NRF_TIMER3->BITMODE = TIMER_BITMODE_BITMODE_32Bit << TIMER_BITMODE_BITMODE_Pos;
  NRF_TIMER3->PRESCALER = 9;                       // 16 MHz / 512 = 31.25 kHz
  NRF_TIMER3->CC[0] = 31250;                       // 1 s
  NRF_TIMER3->SHORTS = TIMER_SHORTS_COMPARE0_CLEAR_Enabled << TIMER_SHORTS_COMPARE0_CLEAR_Pos;
  NRF_TIMER3->INTENSET = TIMER_INTENSET_COMPARE0_Msk;
  // witness v9 + bench fix: HIGHEST priority — a hang that still blocks it
  // can only be PRIMASK-level masking. BUT the SoftDevice reserves specific
  // priority levels when it is enabled, and the bench (2026-10-26, rounds
  // 8-11) pinned the ACTUAL reserved set for this S140 6.1.1 to {0, 1, 4} —
  // the core's own TinyUSB port states it verbatim ("Priorities 0, 1, 4
  // (nRF52) are reserved for SoftDevice"), the stock example passes the
  // SDM's enable check with USBD at priority 2, and every failing BLE boot
  // in the hunt had an enabled interrupt at exactly 4 — including this
  // witness itself, whose 4.5.13 move to 4 (based on the WRONG "app-legal
  // = 4-7" model) blocked sd_softdevice_enable with 0x1001 on every BLE
  // boot since 4.5.10, when the BLE init moved AFTER the witness arms.
  // Priority 7 is legal under BOTH models (classic 4-7 and the confirmed
  // {0,1,4}-reserved). MASKING TRUTH (4.8.1 comment fix): a FreeRTOS
  // critical section at BASEPRI=2 DOES mask numeric priorities >= 2 — a
  // hang inside a held critical section is unwitnessed and dies on the
  // 30 s hardware DOG (pt=0) instead of the ~4 s witnessed SREQ; the
  // witness's pm=1/pm=0 split still names which class happened. What
  // priority 7 guarantees is preemption of any ordinary thread-mode hang
  // (BASEPRI = 0 there) — the witness's actual job — plus legality under
  // both priority models. USB-only boots (SD never comes up) keep priority
  // 0 for the freeze hunt — 4.9.1: the leftover-SD USB boot (the
  // bootloader-left-the-SoftDevice-up state this file seeds
  // g_softDeviceEnabled from the chip for) must NOT take priority 0: its
  // retention writes route through the SD's SVCs, and an SVC cannot
  // preempt an exception at equal priority — the hang marker would pend
  // behind the ISR's own NVIC_SystemReset() and never land, the successor
  // read pm=0/streak-cleared, and the 3-strike hang settle became an
  // unbreakable ~4 s SREQ loop (strictly worse than the 30 s DOG cycle it
  // replaces). The SD-up chip state is the decider, not the com mode.
  NVIC_SetPriority(TIMER3_IRQn, (needsInitialization && !g_bleInitPending && !g_softDeviceEnabled) ? 0 : 7);
  NVIC_ClearPendingIRQ(TIMER3_IRQn);
  NVIC_EnableIRQ(TIMER3_IRQn);
  NRF_TIMER3->TASKS_START = 1;
  g_witnessSecondsUnfed = 0;
}
extern "C" void TIMER3_IRQHandler(void) {
  NRF_TIMER3->EVENTS_COMPARE[0] = 0;
  // Counter-based hang detection (4.5.7 review — see g_witnessSecondsUnfed):
  // no millis() call, no non-volatile reads; the only loop-context writer is
  // watchdogLoop()'s reset. 4 consecutive un-fed seconds = the loop stalled
  // past 3 s with interrupts alive.
  if (!g_shutdownInProgress && g_watchdogArmed && ++g_witnessSecondsUnfed >= 4) {
    // 4.6.6: inside the Bluefruit.begin() window neither retention path is
    // safe (see lipsyncRetentionUnsafe) — skip the marker write; the reset
    // itself (SREQ) still fires and the DOG/watchdog successor boots still
    // settle the streak. A witness fire during the init window requires a
    // >3 s loop stall while begin() runs, which the init task's separate
    // stack and priority make effectively unreachable — this gate is
    // belt-and-braces so the marker can never be the MEMACC trigger.
    if (!lipsyncRetentionUnsafe()) {
      lipsyncRetentionUpdate(1, 0x1C, (uint8_t)(CONF_RETENTION_MARKER_HANG << 2));  // SD-aware marker write; trail bits preserved
    }
    NVIC_SystemReset();  // SREQ — retention survives; the next boot reports pt=/pm=
  }
}

// Live boot trail (witness v7, 4.5.7 review reconciliation) — ONE table,
// the one the stamps actually use. 3 bits, codes 1-7:
//   1  memory up                     (stamped immediately after initMemory()
//                                      returns — 4.9.0: the stamp MOVED from
//                                      the end of setup() and is now
//                                      unconditional, so a hang in the
//                                      mount/seed or beginComOpMode names
//                                      itself instead of reading pt=0)
//   2  safeModePage drawing           (LSScreen::safeModePage)
//   3  safe-mode menu registered      (LSScreen::safeModeMenu)
//   4  LED action running             (performLedAction)
//   5  softwareReset starting         (softwareReset — menu/serial/confirm resets)
//   6  usbCheckConnection running     (its entry stamp; the USB one-shot
//                                      restart resets from INSIDE this
//                                      context, so pt=6 names it truthfully
//                                      and pt=5 stays unambiguous)
//   7  serial command dispatching     (processSerialMessage — stamped when
//                                      a real message is handled, not on
//                                      every idle loop pass, so pt=7 names
//                                      an actual dispatch site)
// pt=0 means the dead boot never stamped (a pre-setup death).
void bootTrailStamp(uint8_t step) {
  writeTrailByte(step);
}

// 4.5.23 — THE FAULT DISCRIMINATOR (bench round 16: the BLE init now FULLY
// SUCCEEDS — st=5, pst=5, advertising runs — and the boot dies a few seconds
// AFTER it: ~0.3 s after the host opens the port (pt=7, serial dispatch) or
// within ~10-15 s idle (pt=4, an LED action), always rst=0x4 with pm=0. The
// remaining hunt splits on one question the stock core cannot answer: its
// HardFault_Handler is a WEAK spin-loop (.S) and the SoftDevice's assert
// path resets the chip itself — both read identically (rst=0x4, no marker).
// This override captures the fault: the class marker (retention bits 2-4 =
// 2, reading back as pm=2 — bit 3, the unused half of the marker nibble)
// names "a HARDFAULT killed the previous boot" on the next boot's wire;
// pm=1 keeps its meaning (witnessed hang); pm=0 + a dead BLE boot now means
// "SD assert / non-HardFault reset" by elimination. The capture ALSO
// encodes the faulting PC's 8 KB flash page into GPREGRET (0xC0|page —
  // values 0xC0-0xFF collide with none of the bootloader's DFU magics
// 0x4e/0x57/0xa8; the SD exposes GPREGRET set only via SVC, so the write is
// best-effort from fault context — if the SD eats it or the bootloader
// clears it, only the location is lost, never the class). The successor
// prints it as fp=0x<page-base>. A best-effort serial print of the frame
// is attempted first (usually lost — interrupts are masked in the fault)
// because a live port is exactly the death trigger the bench observed.
volatile uint32_t g_faultFramePc = 0;
volatile uint32_t g_faultFrameLr = 0;
volatile uint32_t g_faultHfsr = 0;
volatile uint32_t g_faultCfsr = 0;
uint8_t g_faultPrevPage = 0xFF;  // the PREVIOUS boot's fault PC page (0xFF = none) — consumed from GPREGRET at setup

extern "C" __attribute__((used, noinline)) void lipsyncFaultCapture(uint32_t* frame, uint32_t hfsr, uint32_t cfsr);
extern "C" __attribute__((used, noinline)) void lipsyncFaultCapture(uint32_t* frame, uint32_t hfsr, uint32_t cfsr) {
  g_faultFramePc = frame[6];  // the stacked PC — the faulting instruction
  g_faultFrameLr = frame[5];  // the stacked LR — the caller
  g_faultHfsr = hfsr;
  g_faultCfsr = cfsr;
  // class marker: retention bits 2-4 = value 2 (bit 3) — reads back as pm=2.
  // The hang witness uses value 1 (bit 2); they cannot both occur in one
  // boot (a hang needs the loop ALIVE, a fault kills it). checkResetReason
  // treats any nonzero marker as streak-worthy — correct here too: three
  // straight fault deaths SHOULD settle in safe mode.
  // RAW, deliberately (4.5.27): SVCs are impossible at fault priority, and
  // the SD's watch unit is a WATCH — the write itself completes, the
  // violation is only reported afterwards, and we reset 100 ms later anyway.
  NRF_POWER->GPREGRET2 = (NRF_POWER->GPREGRET2 & ~0x1CUL) | ((uint32_t)CONF_RETENTION_MARKER_HARDFAULT << 2);
  // location: the faulting PC's 8 KB flash page into GPREGRET (best-effort —
  // see the header note). The app's flash spans 0x26000-0x75000, so
  // (pc >> 13) fits in 6 bits across the whole nRF52840 flash. The previous
  // 4-bit mask aliased app pages 0x26000+ into the SoftDevice range and made
  // fp= point at the wrong module. 0xC0 marks the record; low 6 bits retain
  // the complete 8 KB page index.
  NRF_POWER->GPREGRET = 0xC0UL | ((g_faultFramePc >> 13) & 0x3FUL);
  // Best-effort, strictly non-blocking print. Adafruit_USBD_CDC::write()
  // otherwise yields forever when DTR is up but the host is not draining;
  // fault context must always reach the reset. The retention markers above
  // remain authoritative when the whole line does not fit immediately.
  char faultLine[80];
  int faultLen = snprintf(faultLine, sizeof(faultLine),
                          "FAULT pc=%lx lr=%lx cfsr=%lx\n",
                          (unsigned long)g_faultFramePc,
                          (unsigned long)g_faultFrameLr,
                          (unsigned long)g_faultCfsr);
  if (faultLen > 0 && faultLen < (int)sizeof(faultLine) &&
      Serial.availableForWrite() >= faultLen) {
    Serial.write((const uint8_t*)faultLine, (size_t)faultLen);
    Serial.flush();
  }
  for (volatile uint32_t i = 0; i < 2000000; i++) { }  // ~100 ms dwell for any already-buffered CDC byte to drain
  NVIC_SystemReset();  // SREQ — retention + GPREGRET survive (or the bootloader clears GPREGRET; the class marker survives regardless)
  while (1) { __WFE(); }          // never returns; do not call RTOS delay() from fault context
}

// The strong override of the core's weak (.S) spin-loop handler. Naked: the
// exception frame is still on the stack; select MSP or PSP per EXC_RETURN
// bit 2 and branch to the capture with the frame pointer in r0.
extern "C" __attribute__((naked)) void HardFault_Handler(void);
extern "C" __attribute__((naked)) void HardFault_Handler(void) {
  __asm volatile (
    "tst   lr, #4              \n"  // EXC_RETURN bit 2: 0 = main stack (ISR context), 1 = process stack (task context)
    "ite   eq                  \n"
    "mrseq r0, msp             \n"
    "mrsne r0, psp             \n"
    "ldr   r1, =0xE000ED2C     \n"  // SCB->HFSR
    "ldr   r2, =0xE000ED28     \n"  // SCB->CFSR
    "ldr   r1, [r1]            \n"
    "ldr   r2, [r2]            \n"
    "b     lipsyncFaultCapture \n"
  );
}

// 4.5.10 BENCH FIX — the BLE init task. The core's loop task (which runs
// setup() and loop()) has a hardcoded 4096-byte stack and configCHECK_FOR_
// STACK_OVERFLOW=1 (mode 1 — misses overflow-and-return), and the BLE boot's
// only-in-that-path call depth (Bluefruit.begin: SoftDevice enable, GATT
// table, HID service, advertising assembly — kilobytes) silently corrupted
// it: a delayed HardFault at ~2.6-4 s into the boot (rst=0x4, pm=0, pt=4 —
// after the boot-center LED stamps, around readyToUse and the first
// btmouse.move), instant reset, infinite BLE boot loop. The gamepad boot
// (no Bluefruit.begin) worked perfectly on the same bench session. The BLE
// init now runs on its own task with a 16 KB static stack, started at the
// end of setup; every BLE call site in the loop is guarded so the pre-init
// window is a no-op window, not a fault window.
volatile int g_bleInitStage = 0;                 // 4.5.11: init-task progress/failure stage (see LSApiDeclarations.h)
volatile int8_t g_bleSdWasEnabled = -1;          // 4.5.13: the init task's SD probe: -1 = not probed yet, 0 = the SoftDevice was down (normal), 1 = it was ALREADY enabled when the app started (bootloader leftover — see LSBLE.h)
volatile bool g_softDeviceEnabled = false;      // 4.5.27: THE SoftDevice is up (set right after Bluefruit.begin() succeeds) — every retention-register access routes through the SD SVCs while this is true; see LSApiDeclarations.h
volatile bool g_bleInitWindow = false;          // 4.6.6: the BLE init task raises this for the duration of Bluefruit.begin() — see lipsyncRetentionUnsafe() in LSApiDeclarations.h
volatile uint8_t g_bleProbeStep = 0;             // 4.5.14: the begin()-mirror probe's first failing call (0 = not run/non-BLE, 1..10 = that call failed, 11 = all passed) — see LSBLE.h
volatile uint32_t g_bleProbeCode = 0;            // 4.5.14: the failing call's SoftDevice error code (0 = none)
volatile uint32_t g_bleProbeNeed = 0;           // 4.5.14: sd_ble_enable's required app RAM base (on NO_MEM, the smoking gun vs 0x20006000)
TaskHandle_t g_loopTaskHandle = NULL;             // 4.5.26: the loop task's handle (captured at setup entry — the loop task runs setup) for the stack high-water print
volatile UBaseType_t g_loopStackHwm = 0;
bool g_bootReportWorthy = false;                  // 4.5.29: computed at setup — true only when the PREVIOUS boot ended abnormally (witness marker, captured fault page, failed BLE init, or lockup). The first-host-byte BOOT report prints only when this is set; healthy boots are SILENT (the released wire contract, restored)
bool g_comModeHealedThisBoot = false;             // 4.8.7 review: setup's gamepad+Bluetooth heal fired — the correction must reach the wire (the in-place Serial.println ran pre-attach, inside TinyUSB's pre-open-port discard window, so no host ever saw it); the first-host-byte report block emits the named line           // 4.5.26: the loop task's minimum-ever free stack (FreeRTOS words, 4 bytes each) — printed as sw= on the wire; near-zero on BLE boots = the 4 KB loop stack is overflowing into the heap
volatile uint32_t g_bleInitRc = 0;              // 4.5.19 (expert consult): the RAW err_t from the failing DIS/HID begin — sd_ble_gatts_service_add's own code on the st=2 path (0x4=NO_MEM, 0x7=INVALID_PARAM, 0xF=FORBIDDEN, 0x10=INVALID_ADDR)
volatile uint32_t g_bleIrqBad1 = 0;              // 4.5.15: pre-demotion mask of enabled IRQs 0-31 found at an SD-reserved priority (< 4) at BLE-init time (bit = IRQ number)
volatile uint32_t g_bleIrqBad2 = 0;              // 4.5.15: the same mask for IRQs 32-47
volatile uint8_t g_bleProbeDemoted = 0;          // 4.5.15: how many the sweep demoted to 4 before the enable
volatile int8_t g_blePrevSt = -1;                 // 4.5.20: the PREVIOUS BLE boot's flash-persisted init verdict (-1 = none, 0 = died DURING begin, 1..4 = failed at that stage, 5 = init fully succeeded) — read+consumed from /bleverdict.dat at boot
volatile uint16_t g_blePrevRc = 0;                // 4.5.20: that boot's DIS/HID raw error code
static volatile bool g_bleInitDone = false;       // the task finished (success or failure)

// 4.5.20/4.5.21 — BLE-VERDICT PERSISTENCE (the reset-proof capture): the
// BLE boots of rounds 13+ die faster than the host can open the port, so
// st=/rc=/pstep= were being lost with the boot itself. The verdict goes to
// the settings filesystem (which survives resets), and the next boot prints
// it as pst=/prc= and consumes the file.
//
// 4.5.21 REGRESSION FIX — THE BLE TASK NO LONGER TOUCHES THE FILESYSTEM. The
// 4.5.20 shape called bleVerdictPersist() from the init task, which opened
// LSMEMORY.h's ONE GLOBAL shared File handle concurrently with the loop
// task's settings writes — two FreeRTOS tasks sharing one stateful handle
// clobbered each other's file state and corrupted the settings file (bench
// round 14: after a CM,1:2 cycle the survivor read IN=0.00|0.00 CA=0.00|0.00
// CM=1 — the re-seed signature; the calibration was wiped and the mode
// reverted to the compiled default). The task now only raises a flag; the
// LOOP — which already owns every other FS operation, all sequential —
// performs the persist. All filesystem access is single-threaded again, and
// the verdict ride survives. The entry record still lands well before
// begin() finishes (the loop services the flag within milliseconds).
// 8-byte record with magic headers both ends: a torn write fails the magic
// check and reads as absent.
static const char* const BLE_VERDICT_FILE = "/bleverdict.dat";
static const char* const BLE_VERDICT_TMP_FILE = "/bleverdict.tmp";
volatile bool g_bleVerdictDirty = false;  // raised by the init task, serviced by the loop — the ONLY cross-task handoff (no FS access off-loop)
void bleVerdictPersist() {  // LOOP-CONTEXT ONLY (see the 4.5.21 note above)
  File verdictFile(InternalFS);  // its own handle — never the shared settings object
  InternalFS.remove(BLE_VERDICT_TMP_FILE);
  delay(1);
  if (verdictFile.open(BLE_VERDICT_TMP_FILE, FILE_O_WRITE)) {
    uint8_t rec[8] = { 0xB5,
                       (uint8_t)g_bleInitStage,
                       (uint8_t)g_bleProbeStep,
                       (uint8_t)(g_bleSdWasEnabled & 0xFF),
                       (uint8_t)(g_bleInitRc & 0xFF),
                       (uint8_t)((g_bleInitRc >> 8) & 0xFF),
                       g_bleProbeDemoted,
                       0xA5 };
    const size_t written = verdictFile.write(rec, sizeof(rec));
    delay(1);
    verdictFile.close();
    // 4.9.9 review round 3: read-back verify before the rename — the same
    // rule every settings writer carries (LSMemory verifyTempWrite: File::
    // close() returns void and swallows close-time errors, so the written
    // count alone can bless a truncated record). A torn record that passed
    // the rename would sit on /bleverdict.dat until the next boot's consume
    // — which rejects it on the magics/size and loses the verdict. The
    // verify makes the rename happen only on a byte-exact temp file; the
    // failure direction is unchanged (absent verdict = the diagnostic's
    // benign loss).
    bool verdictVerified = false;
    if (written == sizeof(rec) && verdictFile.open(BLE_VERDICT_TMP_FILE, FILE_O_READ)) {
      uint8_t verify[8];
      const size_t got = verdictFile.read(verify, sizeof(verify));
      verdictFile.close();
      verdictVerified = (got == sizeof(rec)) && (memcmp(verify, rec, sizeof(rec)) == 0);
    }
    if (verdictVerified) {
      if (!InternalFS.rename(BLE_VERDICT_TMP_FILE, BLE_VERDICT_FILE)) {
        InternalFS.remove(BLE_VERDICT_TMP_FILE);
      }
    } else {
      InternalFS.remove(BLE_VERDICT_TMP_FILE);
    }
  }
}
void bleVerdictConsume() {
  g_blePrevSt = -1;  // absent until proven present
  g_blePrevRc = 0;
  File verdictFile(InternalFS);  // its own handle — never the shared settings object (the 4.5.21 single-task-FS rule)
  if (verdictFile.open(BLE_VERDICT_FILE, FILE_O_READ)) {
    uint8_t rec[8];
    const size_t n = verdictFile.read(rec, sizeof(rec));
    verdictFile.close();
    if (n == sizeof(rec) && rec[0] == 0xB5 && rec[7] == 0xA5) {
      g_blePrevSt = (int8_t)rec[1];
      g_blePrevRc = (uint16_t)rec[4] | ((uint16_t)rec[5] << 8);
    }
    InternalFS.remove(BLE_VERDICT_FILE);  // one-shot: the verdict describes the immediately-previous boot only
  }
}
static char g_bleDeviceName[CONF_BLE_DEVICE_NAME_SZ] = {0};  // the advertising name (static: outlives setup's frame)
static StackType_t g_bleInitStack[CONF_BLE_INIT_TASK_STACK_BYTES / sizeof(StackType_t)];
static StaticTask_t g_bleInitTCB;
static volatile bool g_hostHasSpoken = false;     // 4.5.10: the repeating boot header stops at the first host byte

// Joystick module variables and structures
int acceleration = 0;
int g_scrollLevel = 0;
uint32_t g_scrollNumRuns = 0;  // unsigned wrap is defined for long-lived scroll sessions

int outputAction;
bool canOutputAction = true;
int g_outputHoldInputClass = -1;  // Input class that owns the active drag/scroll latch
// 4.5.7 bench fix: the hold duration (ms) of the input that is CURRENTLY
// dispatching, for selectMenuItem's hold-to-confirm gate on the destructive
// rows. Set fresh on every evaluateOutputAction pass (0 = no input in
// flight — a stale value can never leak into a later decision), set from
// the releasing input's elapsed right before performOutputAction, and set
// to "always pass" by the serial CH,1 path (no hold concept on the wire).
unsigned long g_menuInputHoldMs = 0;
bool g_startupCenterReset = true;
bool g_resetCenterComplete = false;  // global variable for center reset status
bool g_centerRunning = false;        // center sample buffer/timer ids are shared; serialize center and full-calibration flows
bool g_calibrationError = false;     // Global variable for error in full calibration
bool g_calibrationRunning = false;   // 4.5.7 review: a full-calibration chain is in flight — CA,0/EX reads must not overwrite the accumulating corner slots (see getJoystickCalibration)
bool g_calibrationFromApi = false;   // 4.9.9 review round 3: the ACCEPTED chain's initiator, persisted for the internal step-5 center. The center flow's own payload carries only the CENTER initiator (it is a sub-step invoked internally, so its flag is false) — the three internal-center abort sites in performJoystickCenter read THIS flag so a host CA,1 waiter resolves FAIL,3 instead of an unsolicited MANUAL line (the 4.5.2 initiator contract). Set at acceptance in setJoystickCalibration, cleared at step 6 and in abortJoystickCalibration.
bool g_calibrationCenterStep = false;  // 4.5.7 review: the calibration chain's OWN internal step-5 center is starting (synchronous bypass for the center-flow in-flight gate — both chains share the calibrationTimerId[] variables, so a concurrent center would clobber the corner reading-timer id and silently drop the corner's persistence + ack)

bool settingsEnabled = false;  // Serial input settings command mode enabled or disabled

// Input restriction state (roadmap item 11) — loaded from the stored settings
// by initRestrictions(); the serial API setters keep them live.
bool g_sapDisabled = false;        // SD — sip & puff inputs cannot fire actions
bool g_menuButtonsOnly = false;    // MA — only the hub buttons may control the menu
bool g_modeLocked = false;         // LK — inputs cannot change the operating mode
bool g_freezeCursorDuringSap = false;  // CF — cursor output freezes while a sip/puff is in progress

// Input timing windows (roadmap item 15, upstream #62/#9) — stored 0 means
// the compiled default; the getters/setters keep these live. These are the
// STORED values; effectiveWindowMs() maps them onto the action tables.
unsigned long g_inputWindowShortMs = 0;  // WS — short | long boundary
unsigned long g_inputWindowLongMs = 0;   // WL — long | very-long boundary
unsigned long g_inputWindowMaxMs = 0;    // WM — very-long boundary

// External switch action remapping (roadmap item 11's #20 follow-up,
// firmware 4.5.0): the live copy of switchActionProperty the input loop
// evaluates against. initInput() seeds it from the compiled table and
// initSwitchActions() (called from initRestrictions, with the other
// input-related stored settings) overlays any stored remaps — so a device
// with no stored mapping (every settings file written by older firmware)
// behaves byte-for-byte like the compiled table.
inputActionStruct g_switchActionTable[sizeof(switchActionProperty) / sizeof(inputActionStruct)];

// Upstream #58: live SAP action table. initSapActions() (called from
// initRestrictions, with the other input-related stored settings) seeds it
// from the compiled sapActionProperty and overlays the hard-band action
// overrides (HA/HB) — a settings file written by older firmware has no
// HA/HB keys, so the live table stays byte-identical to the compiled table
// (no behavioral change for existing users).
inputActionStruct g_sapActionTable[sizeof(sapActionProperty) / sizeof(inputActionStruct)];

// Timing Variables for Debugging
unsigned long beginMillis;
unsigned long beforeComOpMillis;
unsigned long afterComOpMillis;


// Create instances of classes
LSMemory mem;     // Create an instance of LSMemory for managing flash memory.
LSJoystick js;    // Create an instance of the LSJoystick object
LSPressure ps;    // Create an instance of the LSPressure object
LSOutput led;     // Create an instance of the LSOutput LED object
LSScreen screen;  // Create an instance of the LSScreen Object for OLED Screen
LSBuzzer buzzer;  // Create an instance of the LSBuzzer Object

LSUSBMouse usbmouse;   // Create an instance of the USB mouse object
LSBLEMouse btmouse;    // Create an instance of the BLE mouse object
LSUSBGamepad gamepad;  // Create an instance of the USB gamepad object


//***BLE INIT TASK BODY***//
// Function   : bleInitTaskBody
//
// Description: Runs the full BLE stack bring-up (btmouse.begin ->
//              initializeBluefruit: SoftDevice enable, DIS, HID, advertising)
//              on a 16 KB static stack instead of the loop task's 4 KB.
//              On failure the failing stage's BOOT line has already printed
//              (initializeBluefruit checks every begin()); needsInitialization
//              stays true and every guarded call site stays inert. The task
//              suspends itself — it never returns.
static void bleInitTaskBody(void* arg) {
  (void)arg;
  btmouse.begin(g_bleDeviceName);
  g_bleInitDone = true;               // completion flag first...
  if (needsInitialization) {          // ...then the verdict (true = a stage failed)
    if (USB_DEBUG) { Serial.println(F("BOOT: BLE task FAILED (see stage line above)")); }
  } else {
    if (USB_DEBUG) { Serial.println(F("BOOT: BLE task up")); }
  }
  vTaskSuspend(NULL);  // a FreeRTOS task must never return
}

//***MICROCONTROLLER AND PERIPHERAL CONFIGURATION***//
// Function   : setup
//
// Description: This function handles the initialization of variables, pins, methods, libraries. This function only runs once at powerup or reset.
//
// Parameters :  void
//
// Return     : void
//*********************************//
void setup() {
  g_loopTaskHandle = xTaskGetCurrentTaskHandle();  // 4.5.26: the loop task runs setup — capture its handle for the stack high-water print
  initGlobals();  //  Intialize global variables to default values
  // 4.9.8 (boot-bus fix A): the I2C bus comes up HERE, at the very top of
  // setup() — not in checkI2C() hundreds of ms later. The hub PCB carries no
  // external pull-ups (the schematic's PIN_SDA/PIN_SCL nets are just the XIAO
  // module and the two cables), so from plug-in until this begin() configures
  // the nRF52's internal pull-ups both lines FLOAT while the four slaves are
  // already powered and listening — the window in which a device can power up
  // into a non-idle state (and the longest-lead device, the display, is the
  // one the field episode stranded). Bring-up here shortens that window to
  // its practical minimum (bootloader time is out of the app's reach), and
  // the proactive bus-clear below realigns anything the floating window or
  // the PREVIOUS session's mid-transaction NVIC_SystemReset() left stuck —
  // a clean NACK never reaches the vendored Wire's timeout recovery, so
  // without this the stuck state survived every warm reset (the 2026-11-15
  // field episode: "two error beeps" boots that no number of replugs or
  // Connect restarts could heal until a lucky one-beep boot appeared).
  // No transaction happens between here and checkI2C()'s probes (LittleFS is
  // internal flash; LEDs/buzzer/buttons are GPIO), so this is bring-up only —
  // and busClear() stamps no recovery telemetry: a healthy boot's BH row must
  // still read recoveries=0/bus=1.
  Wire.begin();
  Wire.busClear();
  // 4.6.6: seed the SD-up flag from the chip itself BEFORE the first
  // retention access. checkResetReason() below writes through the SD-aware
  // helper, and on the bootloader-leftover-SD boot (the sd=1 case the 4.5.13
  // guard exists for) initializeBluefruit never runs on a USB-only boot —
  // the flag would stay false for the whole session and every stamp would
  // take the raw GPREGRET path with the SD up. sd_softdevice_is_enabled is
  // the MBR-serviced SVC that is legal in every state (LSBLE.h probes it the
  // same way); from setup's thread mode it is the canonical context.
  {
    uint8_t sdUpAtEntry = 0;
    (void) sd_softdevice_is_enabled(&sdUpAtEntry);
    g_softDeviceEnabled = (sdUpAtEntry != 0);
  }
  checkResetReason();  //  Check reason for reset and reset the reset-reason register

  // Witness v7: capture what the DEAD boot last stamped (survives the reset
  // in the retention register), then start this boot's trail.
  g_bootTrailPrev = readTrailByte();
  g_hangMarkerPrev = (lipsyncRetentionGet(1) >> 2) & 0x07;
  lipsyncRetentionUpdate(1, 0x1C, 0);  // consume the marker — one hang reports once (4.5.27: SD-aware)
  // Marker 3 is a deliberate USB-recovery reset, not an abnormal boot. Its
  // boolean guard was captured by checkResetReason(); suppress it from the
  // crash report while retaining the one-shot decision for this whole boot.
  if (g_hangMarkerPrev == CONF_RETENTION_MARKER_USB_RECOVERY) {
    g_hangMarkerPrev = 0;
  }
  // 4.5.23: consume the previous boot's HardFault PC page (written by
  // lipsyncFaultCapture into GPREGRET; 0xC0|page — see the discriminator
  // note above the handler). Absent/cleared → 0xFF = "no fault recorded".
  const uint32_t faultReg = lipsyncRetentionGet(0);
  if ((faultReg & 0xC0UL) == 0xC0UL) {
    g_faultPrevPage = (uint8_t)(faultReg & 0x3FUL);
    lipsyncRetentionUpdate(0, 0xFF, 0);  // consume — one fault reports once (4.5.27: SD-aware)
  } else {
    g_faultPrevPage = 0xFF;
  }
  writeTrailByte(0);

  // 4.5.29 — THE CONDITIONAL BOOT REPORT (release hygiene, restoring the
  // "healthy boots print nothing" wire contract the 4.5.9-4.5.12 bench
  // instruments deliberately broke "until the BLE boot is bench-cleared" —
  // it now is). The first-host-byte BOOT line prints ONLY when the previous
  // boot ended abnormally; every normal flow (power-on, reset pin, the
  // deliberate software resets of CM/OM/SR/menu/UM) is silent. The
  // abnormal classes, each covered by a surviving signal:
  //   - a witnessed loop hang or a captured HardFault → the retention
  //     marker (pm) is nonzero;
  //   - an SD assert or our fault capture → the fault page (fp) is present;
  //   - a failed BLE init → the persisted verdict (pst) is 0..4;
  //   - a LOCKUP reset → the RESETREAS lockup bit (no capture exists for
  //     this class — the bit itself is the report);
  //   - a watchdog reset → already boots safe mode → the HB line reports it.
  // If a future death class leaves none of these, it stays silent by design
  // — silence IS the contract, and the degradation that matters (a dead or
  // broken boot) always has the HB line or this report.
  g_bootReportWorthy = (g_hangMarkerPrev != 0)
                     || (g_faultPrevPage != 0xFF)
                     || (g_blePrevSt >= 0 && g_blePrevSt < 5)
                     || ((g_lastRebootReason & NRF_POWER_RESETREAS_LOCKUP_MASK) == NRF_POWER_RESETREAS_LOCKUP_MASK);

  beginMillis = millis();  // Intialize timer

  // Keep the bus dark until the composite descriptor is complete. The core
  // pulls D+ (so the host can start enumerating) before setup() runs, and
  // the slow parts of boot (LittleFS mount, settings load) leave a long
  // window where only the CDC interface is registered: a host that is
  // actively hunting for the post-flash port can enumerate that CDC-only
  // device and never re-enumerate, leaving the HID interface down for the
  // whole boot (bench 2026-10-16: BH showed usbMounted=1, hidReady=0,
  // attempts climbing, successes=0 until a manual restart). Detaching here
  // makes every premature enumeration attempt fail; beginComOpMode()
  // attaches once the full descriptor exists.
  USBDevice.detach();

  Serial.begin(115200);

  // BOOT TRACE (4.5.9 bench round 3) — 4.5.29 RELEASE HYGIENE: the
  // unconditional announcement is retired with the bench hunt it carried
  // ("until the BLE boot is bench-cleared" — cleared at 4.5.27). The line
  // now prints only when the previous boot ended abnormally (see
  // g_bootReportWorthy above); the milestone prints below are gated behind
  // USB_DEBUG. Unprefixed lines remain app-tolerated (proven across many
  // sessions; dropped as undecodable, no waiter false-match possible).
  if (USB_DEBUG || g_bootReportWorthy) {
    Serial.print(F("BOOT: "));
    Serial.print(CONF_LIPSYNC_VERSION_STRING);
    Serial.print(F(" rst=0x"));
    Serial.print(g_lastRebootReason, HEX);
    Serial.print(F(" pt="));
    Serial.print(g_bootTrailPrev);
    Serial.print(F(" pm="));
    Serial.println(g_hangMarkerPrev);
  }

  // Arm the hardware watchdog BEFORE the filesystem and third-party device
  // code runs (4.8.7 review: the arm used to sit after checkSafeMode, so the
  // historically demonstrated hang phase — the LittleFS mount + settings
  // seed + persisted-verdict write inside initMemory(), the exact phase the
  // 4.5.22 incident needed a custom RECOVER build for — was unrescued: a
  // hang there got no DOG reset, no safe-mode settling, and a power cycle
  // cleared the streak). The arm decision keys on state computed in
  // checkResetReason() above, so the earlier arm is decision-identical;
  // checkSafeMode() below still runs under the same armed (or inherited)
  // watchdog, and the pinned Adafruit pressure drivers' unbounded
  // software-reset-bit loops stay covered exactly as before: on an I2C
  // failure their BusIO read returns all ones, which those loops interpret
  // as "still resetting" forever. A normal boot can now lose at most one
  // watchdog interval, and its watchdog-safe successor skips the suspect
  // sensor initialization below and remains recoverable over CDC.
  if (CONF_ENABLE_WATCHDOG && g_watchdogBootCount < CONF_WATCHDOG_BOOT_RETRY_LIMIT) {
    initWatchdog();
  } else if (NRF_WDT->RUNSTATUS != 0) {
    // nRF52 WDT cannot be stopped once started and survives warm resets.
    // The settled safe boot (or a developer build that disables future WDT
    // starts) must keep feeding an inherited instance even though it does not
    // arm another hang-witness cycle.
    g_watchdogArmed = true;
    watchdogLoop();
  }

  initMemory();  // Initialize Memory
  // (4.9.0 review; 4.9.1 HONEST BOUNDS) the trail's mid-boot milestone:
  // writeTrailByte(0) means "pre-setup death", so a NON-hang death inside
  // initMemory or beginComOpMode — a fault-capture SREQ, the classes that
  // preserve GPREGRET2 — now names its phase as pt=1 instead of pt=0.
  // A HANG in that window still reads pt=0/pm=0 on the successor: the 30 s
  // hardware DOG catches it (the arm above covers the phase — this is the
  // fix that matters operationally), and a DOG reset wipes the retention
  // register wholesale (the witness-v8 fact), stamp included. pt=1 therefore
  // reads "memory up" for every death class the trail can observe; it does
  // NOT claim hang forensics for the mount/seed window — the DOG -> g_watchdogReset
  // -> safe-mode settle is that hang's recovery path. Trail codes 0-7 are all
  // assigned (v7), so this milestone REUSES code 1 with the narrowed meaning,
  // stamped unconditionally (the old stamp sat behind the witness gate, so a
  // settled safe boot never stamped anything either). Deaths after this
  // point are loop-phase as before.
  bootTrailStamp(1);

  // bleVerdictConsume() runs inside initMemory(), so only now can a failed
  // previous BLE initialization contribute to the abnormal-boot report.
  // The pre-filesystem calculation above still covers fault/retention data
  // for the early setup print.
  if (g_blePrevSt >= 0 && g_blePrevSt < 5) {
    g_bootReportWorthy = true;
  }

  //initUID(); // Intilize unique identifier
  getDeviceID(false, false);       // Retrieve Device ID from memory
  getVersionNumber(false, false);  // Retrieve version number from memory

  initLed();  // Initialize LED Feedback

  initBuzzer();  // Initialize Buzzer

  initInput();  // Initialize input buttons and input switches

  initRestrictions();  // Load the input restriction settings (roadmap item 11) before any input can fire

  // Safe-mode decision BEFORE any interface begins (4.5.7 review): the
  // decision half of checkSafeMode (button debounce + reset reason + the
  // hang-witness settling below) has no side effects on timers or the
  // screen — those live in toggleSafeMode, still called at its original
  // place below. Deciding first lets beginComOpMode skip the mode HID
  // interface and BLE on a safe boot, making the documented "safe mode
  // comes up CDC-only: serial recovery is the whole point" actually true
  // (4.5.6 shipped with the interfaces registered BEFORE the flip — an
  // inert-but-present mouse HID on a safe boot and BLE advertising on a
  // CM=2 safe boot).
  checkSafeMode();

  // Missing required hardware is also a safe-mode DECISION and must land
  // before beginComOpMode() registers HID or defers a BLE initialization
  // task. The old order probed I2C afterwards, so a degraded CM=BLE boot
  // still attached and started the SoftDevice task before calling itself
  // safe. Every safe boot's recovery surface is CDC-only, regardless of the
  // reason that selected it.
  checkI2C();  // Check that I2C devices are connected

  if (!g_displayConnected || !g_mouthpiecePressureSensorConnected
      || !g_ambientPressureSensorConnected || !g_joystickSensorConnected) {
    g_safeModeEnabled = true;
    g_safeModeReason = CONF_SAFE_MODE_REASON_HARDWARE;
    g_operatingMode = CONF_OPERATING_MODE_SAFE;
  }

  // Initialize every detected device before committing to an HID/BLE
  // interface. An address scan can ACK while the driver's configuration
  // still fails; the begin verdicts below update the same connection globals
  // used by the hardware-safe decision.
  if (g_displayConnected) {
    initScreen();
  }
  if (!g_safeModeEnabled && g_mouthpiecePressureSensorConnected && g_ambientPressureSensorConnected) {
    initSipAndPuff();
  }
  if (!g_safeModeEnabled && g_joystickSensorConnected) {
    initJoystick();
  }
  initAcceleration();  // Load the stored cursor acceleration level (roadmap item 9)

  if (!g_displayConnected || !g_mouthpiecePressureSensorConnected
      || !g_ambientPressureSensorConnected || !g_joystickSensorConnected) {
    g_safeModeEnabled = true;
    g_safeModeReason = CONF_SAFE_MODE_REASON_HARDWARE;
    g_operatingMode = CONF_OPERATING_MODE_SAFE;
  }

  beforeComOpMillis = millis() - beginMillis;  // Note time before USB/BT connection
  beginComOpMode();                            // Initialize Operating Mode, Communication Mode, and start instance of mouse or gamepad
  afterComOpMillis = millis() - beginMillis;   // Note time after USB/BT connection

  if (USB_DEBUG) {
    unsigned long startSerialWaitTime = millis();
    unsigned long currentSerialWaitTime = millis();
    const unsigned long SERIAL_WAIT_TIMEOUT = 30000;
    if (g_displayConnected && !Serial) {
      screen.print4LineString("Waiting", "for serial", "connection", "...");
    }
    while (!Serial) {  //wait for serial connection to establish
      if (g_watchdogArmed) watchdogLoop();
      delay(1);
      currentSerialWaitTime = millis();
      if (currentSerialWaitTime - startSerialWaitTime > SERIAL_WAIT_TIMEOUT){
        break;
      }
    }
    Serial.println("USBDEBUG: Serial Connected");
    if (g_displayConnected) {
      screen.print4LineString(" ", "Serial", "connected.", " ");
    }
  }

  if (g_displayConnected) {
    screen.splashScreen();
  }

  startupFeedback();  // Startup LED Feedback

  if (USB_DEBUG) { Serial.println("USBDEBUG: Initialize timers."); }
  // Configure poll timer to perform each feature as a separate loop
  pollTimerId[CONF_TIMER_JOYSTICK] = pollTimer.setInterval(CONF_JOYSTICK_POLL_RATE, 0, joystickLoop);  // poll rate, start delay, function
  pollTimerId[CONF_TIMER_PRESSURE] = pollTimer.setInterval(CONF_PRESSURE_POLL_RATE, 0, pressureLoop);
  pollTimerId[CONF_TIMER_INPUT] = pollTimer.setInterval(CONF_INPUT_POLL_RATE, 0, inputLoop);
  pollTimerId[CONF_TIMER_BLUETOOTH] = pollTimer.setInterval(CONF_BT_FEEDBACK_POLL_RATE, 0, btFeedbackLoop);
  pollTimerId[CONF_TIMER_DEBUG] = pollTimer.setInterval(CONF_DEBUG_POLL_RATE, 0, debugLoop);
  pollTimerId[CONF_TIMER_SCROLL] = pollTimer.setInterval(CONF_SCROLL_POLL_RATE, 0, joystickLoop);
  pollTimerId[CONF_TIMER_SCREEN] = pollTimer.setInterval(CONF_SCREEN_POLL_RATE, 0, screenLoop);
  pollTimerId[CONF_TIMER_USB] = pollTimer.setInterval(CONF_USB_POLL_RATE, 0, usbConnectionLoop);
  pollTimerId[CONF_TIMER_WATCHDOG] = pollTimer.setInterval(CONF_WATCHDOG_POLL_RATE, 0, watchdogLoop);

  // Boot-time registration audit (bench 2026-10-18, pool hygiene): a refused
  // registration returns -1 and every caller used to ignore it — a
  // "registered" loop that silently never ran is how a pool death hides
  // (the LSTimer now refuses loudly and counts, but the ids must be checked
  // at least once at the place they're captured). With the pool raised to
  // 16 this cannot fire today; if a future feature exhausts it, this line
  // names the dead feature at boot instead of leaving it a mystery.
  for (int timerIdx = 0; timerIdx < CONF_TIMER_NUM; timerIdx++) {
    if (pollTimerId[timerIdx] < 0) {
      String timerError = "ERROR: poll timer ";
      timerError += String(timerIdx);
      timerError += " failed to register — that loop WILL NOT RUN";
      serialTxEnqueueDiagLine(timerError);
    }
  }


  pollTimer.disable(pollTimerId[CONF_TIMER_USB]); // TODO 2025-Feb-21 Disable usbConnectionLoop until implemented
  // If USB is not connected, try to reconnect
  if (g_comMode == CONF_COM_MODE_USB) {
    usbConnectRearm(g_usbConnectDelay);  // 4.6.6: delete-before-arm (first arm — the id holder starts at -1)
  }


  // (enablePoll(true) — removed 4.8.1 with the function; setup's explicit
  // per-poll registration/enable below is the single source of truth.)

  ledActionEnabled = true;

  // (ledReadyFeedback() — removed 4.8.1 with the function; the ready cue is
  // the buzzer's playReadySound plus the LED defaults.)

  if (g_displayConnected) {
    pollTimer.enable(pollTimerId[CONF_TIMER_SCREEN]);
  } else {
    pollTimer.disable(pollTimerId[CONF_TIMER_SCREEN]);
  }

  if (g_mouthpiecePressureSensorConnected && g_ambientPressureSensorConnected) {
    pollTimer.enable(pollTimerId[CONF_TIMER_PRESSURE]);
    if (USB_DEBUG) { Serial.println("USBDEBUG: Pressure timer started."); }
  } else {
    pollTimer.disable(pollTimerId[CONF_TIMER_PRESSURE]);
    if (USB_DEBUG) { Serial.println("USBDEBUG: Pressure timer NOT started."); }
  }

  if (g_joystickSensorConnected) {
    pollTimer.enable(pollTimerId[CONF_TIMER_JOYSTICK]);
    pollTimer.enable(pollTimerId[CONF_TIMER_SCROLL]);
  } else {
    pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);
    pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);
  }

  // Timer IDs are valid only after registration. Running initDebug before
  // this point made every enable/disable target slot 0 from zero-initialized
  // storage, while the real debug timer subsequently started enabled.
  initDebug();

  // If any devices are not connected, handle error
  if (!g_displayConnected || !g_mouthpiecePressureSensorConnected || !g_ambientPressureSensorConnected || !g_joystickSensorConnected) {
    hardwareErrorCheck();
  }

  // THE FREEZE FIX, round 2 (bench 2026-10-23, the correlation that closed the
  // hunt): ledWaitFeedback used to run BEFORE checkI2C, allocating the LED
  // brightness channels on the shared HwPWM instance; hardwareErrorCheck's
  // playErrorSound then called tone(), and the Seeed core's tone() CLAIMS
  // THAT SAME PWM PERIPHERAL (Tone.cpp hard-codes PWM2) and rewrites its
  // sequence/loop configuration under the live LED channels — the first
  // note plays, the peripheral is left in a conflicted state, and the loop
  // froze 0.9-8.6 s later on 15/15 boots whose joystick sensor was absent
  // (the only boots that ever play the error sound; all-sensor safe boots
  // and healthy boots never froze). The two PWM users are now SEQUENCED:
  // the error sound plays first (with no LED channels allocated), releases
  // the peripheral via noTone(), and the all-LEDs-on feedback runs here —
  // after any sound, on every boot. Same cues for the user, no overlap.
  ledWaitFeedback();  // Turn on all LEDS (moved from before checkI2C — see above)

  // (handleHardwareErrors() — removed 4.8.1 with the empty function; the
  // real hardware-error handling is checkI2C + checkSafeMode + BH.)

  toggleSafeMode(g_safeModeEnabled);

  // The hardware WDT was armed before device-driver initialization above.
  // Arm its TIMER3 hang witness only while the crash budget remains. On the
  // settled safe boot an inherited (unstoppable) WDT is still fed, but no new
  // witness SREQ is allowed to extend the reset chain.
  if (CONF_ENABLE_WATCHDOG && g_watchdogArmed && g_watchdogBootCount < CONF_WATCHDOG_BOOT_RETRY_LIMIT) {
    initHangWitness();  // witness v8: the TIMER3 hang witness — converts a loop hang into an SREQ that preserves the trail
    // (4.9.0 review: the pt=1 trail stamp moved to immediately after
    // initMemory() and is unconditional there — see the milestone comment.
    // This gate now arms only the witness.)
  }

  // 4.5.10: the BLE init task starts LAST — after every sensor, screen and
  // timer init has completed on the loop task's stack, so the two never
  // contend for stack and the loop's guarded BLE calls stay inert until the
  // stack is up (needsInitialization is the gate).
  if (g_bleInitPending) {
    if (USB_DEBUG) { Serial.println(F("BOOT: BLE task create")); }
    TaskHandle_t bleTask = xTaskCreateStatic(bleInitTaskBody, "bleInit",
                                             CONF_BLE_INIT_TASK_STACK_BYTES / sizeof(StackType_t),
                                             NULL, CONF_BLE_INIT_TASK_PRIORITY,
                                             g_bleInitStack, &g_bleInitTCB);
    if (bleTask == NULL) {
      g_bleInitStage = 1;
      g_bleInitDone = true;
      g_bleVerdictDirty = true;
      if (USB_DEBUG) { Serial.println(F("BOOT: BLE FAILED to create init task")); }
    }
  }

  if (USB_DEBUG) { Serial.print("USBDEBUG: lastRebootReason: "); Serial.println(g_lastRebootReason); }
  if (USB_DEBUG) { Serial.println("USBDEBUG: Setup complete."); }

  if (USB_DEBUG) { Serial.println(F("BOOT: setup done")); }

}  // end setup


//***START OF MAIN LOOP***//
// Function   : loop
//
// Description: This function loops consecutively and responses to changes.
//
// Parameters :  void
//
// Return     : void
//*********************************//
void loop() {
  serialTxService();
  bool bootReportPendingThisPass = false;
  // 4.5.10: any host byte stops the repeating boot header (below) — the
  // app's connect sends SETTINGS within milliseconds of opening the port,
  // so a connected session falls silent after one extra line at most.
  static bool finalBootLinePrinted = false;
  if (Serial.available() > 0) {
    // 4.5.12: the FIRST host byte also prints the header one final time —
    // the repeating ticks all fall inside TinyUSB's DTR-gated discard
    // window (writes before the host opens the port are dropped), which
    // is how three BLE boots' worth of st= data was lost. This line lands
    // in every session log right after connect, carrying the BLE verdict.
    if (!g_hostHasSpoken && !finalBootLinePrinted) {
      finalBootLinePrinted = true;
      // 4.5.29: the report prints ONLY when the previous boot ended
      // abnormally (g_bootReportWorthy — see setup). Healthy boots stay
      // SILENT on the wire: the released contract ("healthy boots print
      // nothing") is restored now that the BLE boot is bench-cleared. The
      // 4.5.12 "bulletproof capture" served its hunt; the abnormal-boot
      // classes keep it — each one leaves a marker, a fault page, a failed
      // verdict, or a lockup bit, and this line still carries the full
      // forensics for exactly those boots.
      bootReportPendingThisPass = g_bootReportWorthy;
    }
    g_hostHasSpoken = true;
  }

  // REPEATING BOOT HEADER — RETIRED (4.5.29): the 1 s × 30 s repeat lived
  // for the TinyUSB CDC discard window (pre-open-port writes are dropped),
  // so a dying boot could still be caught on a serial monitor mid-loop.
  // The hunt it served is closed and the conditional first-host-byte report
  // above carries every abnormal class — healthy boots are silent again.

  // Feed the hardware watchdog directly from the live loop (bench
  // 2026-10-18, the unbreakable safe-mode reset cycle): the heartbeat
  // witness proved that in a safe-mode boot the feed's soft timer on the
  // shared pollTimer pool stops firing — feed= froze at 4428 ms while
  // mode=3 safe=1 wdt=1 and the loop printed heartbearts for another
  // minute — so the armed 30 s watchdog starved, reset the device, whose
  // watchdog flag booted it into safe mode again, where the feed died
  // again: a 30 s reset cycle unbreakable until the cable was re-seated.
  // The loop itself demonstrably stays alive, so feed here on every pass:
  // the feed no longer depends on any timer machinery, and the watchdog
  // keeps its true job — catching a genuinely dead loop. The 5 s
  // pollTimer registration stays as a harmless second feeder.
  if (g_watchdogArmed) {
    watchdogLoop();
  }

  // Button/click transitions must not depend on a later joystick movement
  // report to reach the host (joystick debug mode deliberately disables that
  // poll). This service is non-blocking and sends only when HID is ready.
  usbmouse.service();
  btmouse.service();
  gamepad.service();

  // 4.9.9 review round 3: the TinyUSB mount/unmount debug events, emitted
  // from THIS task (the hooks only record them — see tud_mount_cb).
  usbEventDrain();

  // 4.8.1: the mouse's unmount cleanup raised its take-and-clear flag — the
  // USB host went away while click/drag state was held. End the DRAG mode
  // latch the same way btFeedbackLoop does for a BLE host change ("never
  // carry a drag/scroll latch across hosts"): usbCheckConnection's not-ready
  // branch misses a fast unmount->remount between its checks, and without
  // this the latch survived with the wire button already cleared. No
  // action-bearing event is emitted — the hold simply ends. (The scroll
  // latch is deliberately NOT ended here: a scroll hold carries no wire
  // button state — see LSUSBMouse::service's unmount comment — and ends at
  // the input release as usual.)
  // 4.9.0: routed through cancelSapOutputHold() — the mirror paths (the
  // sensor-fault hold-cancel, the hold-cancel branch) pair the release with
  // setLedDefault(), and the USB-bounce consumer used to leave the hold's
  // window color on the LEDs until the next input event repainted.
  if (usbmouse.takeUnmountedWithButtonState()
      && (outputAction == CONF_ACTION_DRAG || outputAction == CONF_ACTION_SCROLL)) {
    cancelSapOutputHold();
  }

  // 4.9.0: the exact BLE mirror — a drop→sub-second-reconnect inside
  // btFeedbackLoop's 1 s disconnected-observation (bench 4.8.14: macOS
  // reclaims the link sub-second) left the DRAG latch alive with the wire
  // button already cleared by LSBLEMouse::service's disconnect cleanup.
  // The flag bridges the gap; same scroll-latch caveat and same
  // no-action-bearing-event rule as the USB twin above.
  if (btmouse.takeDisconnectedWithButtonState()
      && (outputAction == CONF_ACTION_DRAG || outputAction == CONF_ACTION_SCROLL)) {
    cancelSapOutputHold();
  }

  // Degraded-state heartbeat (bench 2026-10-18, boot-with-unseated-cable
  // forensics): a 4.5.0 boot with the interface cable unseated reset at an
  // exact 30 s cadence — the app connected into the window, loaded ~19
  // settings, then the device vanished ("connection lost"), cycle after
  // cycle, unrecoverable until the cable was re-seated. Every static
  // suspect is ruled out (the vendored Wire bounds every transaction at
  // 50 ms and recovers wedges; the joystick/pressure/screen paths back
  // off; the safe-mode path leaves the watchdog timer enabled; the API
  // table is not filtered by safe mode) — so the freeze mechanism needs a
  // witness that survives it. A degraded or safe-mode boot prints one line
  // every 5 s; a healthy boot prints nothing. The line's very existence
  // proves the main loop is alive, and the three numbers split the
  // remaining hypotheses: feed= growing past 30 s while lines keep
  // printing = the feed timer died while the loop lives; lines stopping =
  // the loop froze; wdt=1 feed=never = the watchdog was armed but its
  // timer never registered (the LSTimer pool has shown "No free timers").
  static unsigned long lastHeartbeatMs = 0;
  // 4.5.12: a BLE boot whose init FAILED is degraded — the heartbeat now
  // carries the verdict (ble=/st=) for the whole session, so a connected
  // app sees the failure state repeatedly instead of a silent unpairable
  // device. A successful BLE boot (needsInitialization false) is healthy.
  const bool bleInitFailed = (g_bleInitPending && g_bleInitDone && needsInitialization);
  const bool degradedNow = g_safeModeEnabled || !g_displayConnected || !g_joystickSensorConnected
                         || !g_mouthpiecePressureSensorConnected || !g_ambientPressureSensorConnected
                         || bleInitFailed;
  // RELEASED BEHAVIOR (4.5.7 review): the bench's 2026-10-23 "witness
  // window" (every boot printing at 250 ms/1 s cadence for the first 90 s)
  // shipped in the V4.5.6 tag even though its own comment called it "a
  // diagnostic patch, not the release behavior" and CHANGES.txt claimed
  // "healthy boots still print nothing" — ~105 unsolicited HB lines
  // interleaved into every app connect + settings load, the exact
  // wire-noise class 4.5.2/4.5.5 eliminated. The released contract stands
  // again: degraded/safe boots print one line every 5 s (the freeze-hunt
  // forensics endpoint — rst/pt/pm/trail/bus/recov/sns all ride the line),
  // healthy boots print nothing. Bench instrumentation belongs in bench
  // builds, not the tag.
  const unsigned long heartbeatIntervalMs = 5000;
  if (degradedNow && (millis() - lastHeartbeatMs >= heartbeatIntervalMs)) {
    lastHeartbeatMs = millis();
    static char diagnosticLine[512];  // Static: do not consume the loop task's 4 KB stack
    char feedText[24];
    if (g_watchdogLastFeedMs == 0) snprintf(feedText, sizeof(feedText), "never");
    else snprintf(feedText, sizeof(feedText), "%lums", (unsigned long)(millis() - g_watchdogLastFeedMs));
    char faultText[16];
    if (g_faultPrevPage == 0xFF) snprintf(faultText, sizeof(faultText), "none");
    else snprintf(faultText, sizeof(faultText), "%lX", (unsigned long)(((uint32_t)g_faultPrevPage) << 13));
    int diagnosticLen;
    if (bleInitFailed) {
      diagnosticLen = snprintf(diagnosticLine, sizeof(diagnosticLine),
        "HB: ms=%lu mode=%d safe=%d wdt=%d feed=%s rst=0x%lX pt=%u pm=%u trail=%u bus=%d recov=%lu sns=%d%d%d%d vdd=%dmV ble=3 st=%d sd=%d pstep=%u pcode=0x%lX need=0x%lX bad1=0x%lX bad2=0x%lX dem=%u rc=0x%lX pst=%d prc=0x%X fp=0x%s sw=%lu",
        (unsigned long)millis(), g_operatingMode, g_safeModeEnabled ? 1 : 0,
        g_watchdogArmed ? 1 : 0, feedText, (unsigned long)g_lastRebootReason,
        g_bootTrailPrev, g_hangMarkerPrev, readTrailByte(), Wire.busHealthy() ? 1 : 0,
        (unsigned long)Wire.recoveryCount(), g_joystickSensorConnected ? 1 : 0,
        g_mouthpiecePressureSensorConnected ? 1 : 0, g_ambientPressureSensorConnected ? 1 : 0,
        g_displayConnected ? 1 : 0, readVddMillivolts(), g_bleInitStage, (int)g_bleSdWasEnabled,
        g_bleProbeStep, (unsigned long)g_bleProbeCode, (unsigned long)g_bleProbeNeed,
        (unsigned long)g_bleIrqBad1, (unsigned long)g_bleIrqBad2, g_bleProbeDemoted,
        (unsigned long)g_bleInitRc, (int)g_blePrevSt, (unsigned int)g_blePrevRc,
        faultText, (unsigned long)(g_loopTaskHandle ? uxTaskGetStackHighWaterMark(g_loopTaskHandle) : 0));
    } else {
      diagnosticLen = snprintf(diagnosticLine, sizeof(diagnosticLine),
        "HB: ms=%lu mode=%d safe=%d wdt=%d feed=%s rst=0x%lX pt=%u pm=%u trail=%u bus=%d recov=%lu sns=%d%d%d%d vdd=%dmV",
        (unsigned long)millis(), g_operatingMode, g_safeModeEnabled ? 1 : 0,
        g_watchdogArmed ? 1 : 0, feedText, (unsigned long)g_lastRebootReason,
        g_bootTrailPrev, g_hangMarkerPrev, readTrailByte(), Wire.busHealthy() ? 1 : 0,
        (unsigned long)Wire.recoveryCount(), g_joystickSensorConnected ? 1 : 0,
        g_mouthpiecePressureSensorConnected ? 1 : 0, g_ambientPressureSensorConnected ? 1 : 0,
        g_displayConnected ? 1 : 0, readVddMillivolts());
    }
    if (diagnosticLen > 0 && diagnosticLen < (int)sizeof(diagnosticLine)) {
      serialTxEnqueueLine(diagnosticLine, (size_t)diagnosticLen);
    }
  }

  // 4.5.21: the verdict-persist service point — the BLE init task raises the
  // flag, the loop (sole owner of all filesystem access) performs the write.
  // Runs within milliseconds of the flag, well before begin() completes.
  if (g_bleVerdictDirty) {
    // Atomic take-and-clear across the higher-priority BLE init task. Without
    // the critical section, that task could set dirty between this loop's
    // test and clear, and the clear would erase the final stage-5 verdict.
    bool persistVerdict = false;
    taskENTER_CRITICAL();
    persistVerdict = g_bleVerdictDirty;
    g_bleVerdictDirty = false;
    taskEXIT_CRITICAL();
    if (persistVerdict) bleVerdictPersist();
  }

  ledStateTimer.run();  // Timer for lights
  
  usbConnectTimer.run();
  

  if (g_joystickSensorConnected) {
    calibrationTimer.run();  // Timer for calibration measurements
  }
  

  if (g_operatingMode == CONF_OPERATING_MODE_GAMEPAD) {
    actionTimer.run();  
  }

  pollTimer.run();  // Timer for normal joystick functions

  buzzer.update();  // Fire queued buzzer notes (non-blocking sound sequencing)

  settingsEnabled = serialSettings(settingsEnabled);  // Process Serial API commands
  if (bootReportPendingThisPass) {
    static char bootLine[384];  // Static: keep the diagnostic off the loop task stack
    char faultText[16];
    if (g_faultPrevPage == 0xFF) snprintf(faultText, sizeof(faultText), "none");
    else snprintf(faultText, sizeof(faultText), "%lX", (unsigned long)(((uint32_t)g_faultPrevPage) << 13));
    int bleStateFinal = 0;
    if (g_bleInitPending) bleStateFinal = g_bleInitDone ? (needsInitialization ? 3 : 2) : 1;
    int bootLen = snprintf(bootLine, sizeof(bootLine),
      "BOOT: %s rst=0x%lX pt=%u pm=%u ble=%d st=%d sd=%d pstep=%u pcode=0x%lX need=0x%lX bad1=0x%lX bad2=0x%lX dem=%u rc=0x%lX pst=%d prc=0x%X fp=0x%s sw=%lu",
      CONF_LIPSYNC_VERSION_STRING.c_str(), (unsigned long)g_lastRebootReason,
      g_bootTrailPrev, g_hangMarkerPrev, bleStateFinal, g_bleInitStage,
      (int)g_bleSdWasEnabled, g_bleProbeStep, (unsigned long)g_bleProbeCode,
      (unsigned long)g_bleProbeNeed, (unsigned long)g_bleIrqBad1,
      (unsigned long)g_bleIrqBad2, g_bleProbeDemoted, (unsigned long)g_bleInitRc,
      (int)g_blePrevSt, (unsigned int)g_blePrevRc, faultText,
      (unsigned long)(g_loopTaskHandle ? uxTaskGetStackHighWaterMark(g_loopTaskHandle) : 0));
    if (bootLen > 0 && bootLen < (int)sizeof(bootLine)) {
      serialTxEnqueueLine(bootLine, (size_t)bootLen);
    }
    // 4.8.7 review: setup's gamepad+Bluetooth heal fired — name the
    // correction here, post-attach, where a host can actually read it (the
    // heal's own println ran in the pre-attach discard window).
    if (g_comModeHealedThisBoot) {
      serialTxEnqueueLine("ERROR: stored gamepad+Bluetooth is not a supported combination -- communication mode reset to USB");
    }
  }
  serialTxService();

  // Multi-host switch window (upstream #16, 4.8.8): the directed advertise
  // self-terminates about every second (high-duty directed spec limit), so
  // the window needs millisecond-granularity re-arms — the 1 s btFeedbackLoop
  // tick alone left the target's background scan too sparse a duty cycle.
  // This service is a no-op unless a window is open; single-threaded with
  // every other window path (all on the loop task).
  lsHostServiceSwitchWindow();

  //yield();
}


//***INITIALIZE GLOBALS FUNCTION***//
// Function   : initGlobals
//
// Description: This function initializes global variables to default values
//
// Parameters : void
//
// Return     : void
//****************************************//
void initGlobals() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initGlobals()"); } //  Won't display as function called before serial established

  g_lastRebootReason = 0;
  g_ambientPressureSensorConnected = false;
  g_mouthpiecePressureSensorConnected = false;
  g_joystickSensorConnected = false;
  g_displayConnected = false;
  g_btIsConnected = false;
  g_errorCode = 0;
  g_debugMode = 0;
  g_usbNotReadySinceMs = 0;
  g_usbReenumCount = 0;
  //g_lightMode = 1;  //  Currently unused
  //g_soundMode = 1; //  Currently unused
  g_operatingMode = 1;
  g_comMode = 1;
  //g_firstLoop = true;

  g_watchdogReset = false;
  g_watchdogBootCount = 0;
  g_safeModeEnabled = false;
  g_safeModeReason = 0;

  g_sapDisabled = false;
  g_menuButtonsOnly = false;
  g_modeLocked = false;
  g_freezeCursorDuringSap = false;

  g_inputWindowShortMs = 0;
  g_inputWindowLongMs = 0;
  g_inputWindowMaxMs = 0;

  g_centerRunning = false;
  g_calibrationRunning = false;
  g_calibrationCenterStep = false;

}


//***HARDWARE ERROR CHECK FUNCTION***//
// Function   : hardwareErrorCheck
//
// Description: This function checks for errors with the LipSync hardware
//
// Parameters : void
//
// Return     : void
//****************************************//
void hardwareErrorCheck(void) {
  if (USB_DEBUG) { Serial.println("USBDEBUG: hardwareErrorCheck()"); }

  // I2C Connection Errors (Display, Joystick, Mouthpiece Pressure, Ambient Pressure)
  if (!g_displayConnected) {
    // Display not connected / detected
    buzzer.playErrorSound();
    static const char displayError[] = "ERROR: Display not detected";
    serialTxEnqueueDiagLine(displayError, sizeof(displayError) - 1);
    ledError(3);
    g_safeModeEnabled = true;
    g_safeModeReason = CONF_SAFE_MODE_REASON_HARDWARE;
  }

  if (!g_joystickSensorConnected && !g_mouthpiecePressureSensorConnected && !g_ambientPressureSensorConnected) {
    // All joystick sensors not detected
    buzzer.playErrorSound();
    static const char cableError[] = "ERROR: No sensors detected in joystick. Check interface cable.";
    serialTxEnqueueDiagLine(cableError, sizeof(cableError) - 1);
    g_safeModeEnabled = true;
    g_safeModeReason = CONF_SAFE_MODE_REASON_HARDWARE;
    
  } else if (!g_joystickSensorConnected || !g_mouthpiecePressureSensorConnected || !g_ambientPressureSensorConnected) {
    // One or more sensors but not all
    
    g_safeModeEnabled = true;
    g_safeModeReason = CONF_SAFE_MODE_REASON_HARDWARE;
    
    buzzer.playErrorSound();
    if (!g_joystickSensorConnected) {
      static const char joystickError[] = "ERROR: Joystick sensor not detected.";
      serialTxEnqueueDiagLine(joystickError, sizeof(joystickError) - 1);
    }
    if (!g_mouthpiecePressureSensorConnected) {
      static const char mouthpieceError[] = "ERROR: Mouthpiece Pressure Sensor not detected.";
      serialTxEnqueueDiagLine(mouthpieceError, sizeof(mouthpieceError) - 1);
    }
    if (!g_ambientPressureSensorConnected) {
      static const char ambientError[] = "ERROR: Ambient Pressure Sensor not detected.";
      serialTxEnqueueDiagLine(ambientError, sizeof(ambientError) - 1);
    }
    
  }


}


// (handleHardwareErrors REMOVED — 4.8.1 review: an empty body whose only
// call was commented out ("Currently not implemented"). The real hardware
// error handling is checkI2C + checkSafeMode + the BH health fields.)


//***ERROR CHECK FUNCTION***//
// Function   : errorCheck
//
// Description: This function checks for errors with the LipSync device
//
// Parameters : void
//
// Return     : void
//****************************************//
void errorCheck(void) {
  if (USB_DEBUG) { Serial.println("USBDEBUG: errorCheck()"); }

  if ((g_operatingMode == CONF_OPERATING_MODE_MOUSE) && (g_comMode == CONF_COM_MODE_USB)
      && (!usbmouse.isReady() || usbmouse.usbRetrying || usbmouse.timedOut)) {
    g_errorCode = CONF_ERROR_USB;
  } else if ((g_operatingMode == CONF_OPERATING_MODE_GAMEPAD) && !gamepad.isReady()) {
    g_errorCode = CONF_ERROR_USB;
  } else {
    g_errorCode = CONF_ERROR_NONE;  // 0
  }

  if (USB_DEBUG) { Serial.print("USBDEBUG: errorCode: "); Serial.println(g_errorCode); }
  // Add if cases for other errors
}


//***ERROR SCREEN FUNCTION***//
// Function   : errorScreen
//
// Description: This function calls the corresponding error screen function
//
// Parameters : void
//
// Return     : void
//****************************************//
void errorScreen(void) {
  if (USB_DEBUG) { Serial.println("USBDEBUG: errorScreen()"); }
  errorCheck();

  if (!screen.isMenuActive()) {
    if (g_errorCode == CONF_ERROR_USB) {
      // Only draw when there is a display on an answerable bus — a draw against
      // held I2C hardware costs seconds of bounded timeouts (see usbCheckConnection)
      if (g_displayConnected && Wire.busHealthy()) {
        screen.noUsbPage();
      }
    }
  }
}


//***CHECK SAFE MODE FUNCTION***//
// Function   : checkSafeMode
//
// Description: Checks if both hub buttons are pressed on startup in order to enter safe boot mode.
//
// Parameters : void
//
// Return     : void
//****************************************//
void checkSafeMode(void) {

  if (USB_DEBUG) { Serial.println("USBDEBUG: checkSafeMode()"); }

  // Read Hub button values
  int buttonSelectState1 = !digitalRead(CONF_BUTTON1_PIN);
  int buttonNextState1 =   !digitalRead(CONF_BUTTON2_PIN);

  delay(50);

  // Read Hub button values again
  int buttonSelectState2 = !digitalRead(CONF_BUTTON1_PIN);
  int buttonNextState2 =   !digitalRead(CONF_BUTTON2_PIN);

  if (buttonSelectState1 == HIGH && buttonSelectState2 == HIGH && buttonNextState1 == HIGH && buttonNextState2 == HIGH) {
    g_safeModeEnabled = true;
    g_safeModeReason = CONF_SAFE_MODE_REASON_INPUT;  //  Both hub buttons pushed on startup

  } else if (g_watchdogReset && CONF_ENABLE_WATCHDOG) {
    g_safeModeEnabled = true;
    g_safeModeReason = CONF_SAFE_MODE_REASON_WATCHDOG;

  } else if (g_hangBootStreak >= CONF_WATCHDOG_BOOT_RETRY_LIMIT) {
    // Hang-witness settling (4.5.7 review): the previous three-or-more
    // consecutive boots each died in a TIMER3-witnessed loop hang (an
    // interrupts-alive stall — the SREQ resets PRESERVE the retention
    // register, so unlike the watchdog-reset budget this streak actually
    // accumulates). Rest this boot in safe mode: the safe-mode loop is the
    // minimal machinery, and TIMER3 is not re-armed (an inherited hardware
    // WDT remains fed; the streak feeds g_watchdogBootCount in setup()) — the
    // documented "after N straight crash boots, the device settles in
    // safe mode instead of resetting forever" contract, finally
    // functional on the path that can actually count.
    g_safeModeEnabled = true;
    g_safeModeReason = CONF_SAFE_MODE_REASON_HANG;
    static const char hangWarning[] = "WARNING: SAFE MODE ENABLED - Repeated witnessed loop hangs";
    serialTxEnqueueDiagLine(hangWarning, sizeof(hangWarning) - 1);

  } else {
    g_safeModeEnabled = false;
  }

  if (g_safeModeEnabled) {
    g_operatingMode = CONF_OPERATING_MODE_SAFE; // Change operating mode to safe mode
  }


}

//***TOGGLE SAFE MODE FUNCTION***//
// Function   : toggleSafeMode
//
// Description: Checks if both hub buttons are pressed on startup in order to enter safe boot mode.
//
// Parameters : bool : safeModeEnabled : Whether safe mode is enabled or disabled
//
// Return     : void
//****************************************//
void toggleSafeMode(bool safeModeEnabled) {
  
  if (safeModeEnabled) {
    // Prevent mouse and gamepad outputs from being sent
    
    // Provide feedback based on reason for activating safe mode
    switch(g_safeModeReason) {
      case CONF_SAFE_MODE_REASON_INPUT:
      {
        static const char inputWarning[] = "WARNING: SAFE MODE ENABLED - Hub Buttons";
        serialTxEnqueueDiagLine(inputWarning, sizeof(inputWarning) - 1);
        break;
      }
      case CONF_SAFE_MODE_REASON_WATCHDOG:
      {
        static const char watchdogWarning[] = "WARNING: SAFE MODE ENABLED - Watchdog";
        serialTxEnqueueDiagLine(watchdogWarning, sizeof(watchdogWarning) - 1);
        break;
      }
      case CONF_SAFE_MODE_REASON_HARDWARE:
      {
        // 4.9.8 (boot-bus fix E): name WHICH hardware is missing, in the
        // heartbeat's own sns= encoding (LSI2CScan.h — joystick, mouthpiece,
        // ambient, display). The bare line forced every field reader to
        // re-derive the missing set from a BH probe; the 2026-11-15 "two
        // error beeps" mystery was a full sns=0000 hiding behind a generic
        // string, and the one-beep boots were sns=0111. toggleSafeMode runs
        // after checkI2C's final verdicts, so the flags are the scan's.
        static char hardwareWarning[LSI2C_SAFE_MODE_HARDWARE_WARNING_BUF];
        const int hardwareWarningLen = lsi2cSafeModeHardwareWarning(
            hardwareWarning, sizeof(hardwareWarning),
            g_joystickSensorConnected, g_mouthpiecePressureSensorConnected,
            g_ambientPressureSensorConnected, g_displayConnected);
        if (hardwareWarningLen > 0) {
          serialTxEnqueueDiagLine(hardwareWarning, (size_t)hardwareWarningLen);
        } else {
          static const char hardwareWarningFallback[] = "WARNING: SAFE MODE ENABLED - Hardware";
          serialTxEnqueueDiagLine(hardwareWarningFallback, sizeof(hardwareWarningFallback) - 1);
        }
        break;
      }
      default:
      {
        static const char safeWarning[] = "WARNING: SAFE MODE ENABLED";
        serialTxEnqueueDiagLine(safeWarning, sizeof(safeWarning) - 1);
        break;
      }
         
    }

    g_operatingMode = CONF_OPERATING_MODE_SAFE; // Set working operating mode to safe mode to prevent unwanted input in case of hardware error

    // activate safe boot mode screen on display
    screen.safeModePage(g_safeModeReason);
    screen.disableTimeout();
    screen.update();

      
    // Disable poll timers
    //pollTimer.disable(pollTimerId[CONF_TIMER_SCREEN]);
    pollTimer.disable(pollTimerId[CONF_TIMER_PRESSURE]);
    pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);
    pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);
    pollTimer.disable(pollTimerId[CONF_TIMER_DEBUG]);
    pollTimer.disable(pollTimerId[CONF_TIMER_BLUETOOTH]);

    } else {
    

  }


}



//***READY TO USE FUNCTION***//
// Function   : readyToUse
//
// Description: This function checks for errors and startup conditions, and then displays the Ready To Use screen.
//              If errors are present, the error screen function is called.
//
// Parameters : void
//
// Return     : void
//****************************************//
void readyToUse(void) {
  if (USB_DEBUG) { Serial.println("USBDEBUG: readyToUse()"); }

  errorCheck();  // Check for errors

  if (readyToUseFirstTime && g_resetCenterComplete && !g_safeModeEnabled) {

    if (g_errorCode == CONF_ERROR_NONE) {
      buzzer.playReadySound();
      screen.splashScreen2();
      readyToUseFirstTime = false;
    } else {
      buzzer.playErrorSound();
      errorScreen();
    }

    if (SHOW_CONNECTION_TIME) {
      screen.connectionTimingPage(beforeComOpMillis, afterComOpMillis);
      Serial.print("Time until before com op mode: ");
      Serial.println(beforeComOpMillis);
      Serial.print("Time until after com op mode: ");
      Serial.println(afterComOpMillis);
    }
  }
}

// (enablePoll REMOVED — 4.8.1 review: its only call site was the removed
// dead ledIBMEffect (plus a commented-out one). It force-enabled
// PRESSURE/INPUT/BLUETOOTH polls with no safe-mode or debug-mode gate — the
// exact wrong-re-enable class the poll restore paths now gate individually.
// Safe mode and setDebugState own the poll enables.)

//*********************************//
// Memory Functions
//*********************************//

//***INITIALIZE MEMORY FUNCTION***//
// Function   : initMemory
//
// Description: This function initializes flash memory to store settings
//
// Parameters : void
//
// Return     : void
//****************************************//
void initMemory() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initMemory()"); }
#if CONF_FS_FORMAT_ON_BOOT
  // 4.5.22 RESCUE PATH (see LSConfig.h): a fresh format before the mount
  // heals a filesystem torn by the 4.5.20 race + mid-write witness kills —
  // the class of corruption that hangs/crash-loops the boot at the FIRST FS
  // operation, before any tone, screen, or serial protocol. Runs on the
  // RECOVER build only; mem.begin() below mounts the fresh filesystem.
  InternalFS.format();
  delay(2);
#endif
  mem.begin();  // Begin memory
  // (4.9.0 review) orphaned temp files: every writer pre-removes its temp
  // before writing, so a power cut between that remove and the rename leaves
  // /settings.tmp (and /bleverdict.tmp) on flash until that module's next
  // successful write. Nothing reads a stale temp as settings (the writers
  // own the tmp name), but a unit that crashes mid-write and never writes
  // again carried the orphaned block indefinitely — sweep both at boot.
  InternalFS.remove(CONF_SETTINGS_TMP_FILE);
  InternalFS.remove(BLE_VERDICT_TMP_FILE);
  bleVerdictConsume();  // 4.5.20: consume the previous BLE boot's flash-persisted verdict (pst=/prc= on the wire) — after the FS is up, before any header prints it
  
  // Open settings file (CONF_SETTINGS_FILE) from flash memory.
  // If not present, create file based on defaults in CONF_SETTINGS_JSON
  mem.initialize(CONF_SETTINGS_FILE, CONF_SETTINGS_JSON);
  // Upstream #58: the second settings file (hard sip/puff keys HS/HP/HA/HB).
  // Same seed-on-missing contract as the main file, its own budget (see
  // LSMemory::budgetFor) — a file 4.1.0 never touches, so the main file's
  // downgrade cliff is unaffected.
  mem.initialize(CONF_SETTINGS2_FILE, CONF_SETTINGS2_JSON);
}

//***RESET MEMORY FUNCTION***//
// Function   : resetMemory
//
// Description: This function formats and removes existing text files in flash memory.
//              It initializes flash memory to store settings after formatting.
//
// Parameters : void
//
// Return     : void
//****************************************//
bool resetMemory() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: resetMemory()"); }
  mem.format();  // Format and remove existing text files in flash memory
  // Write the complete default document once. The old factory-reset path
  // followed initialization with ~22 read/modify/write cycles, multiplying
  // flash wear and exposing many intermediate states for no benefit—the next
  // boot reloads this document anyway.
  bool mainOk = mem.writeAll(CONF_SETTINGS_FILE, CONF_SETTINGS_JSON);
  // Upstream #58: the hard-band file gets the same treatment. Both files are
  // re-seeded from compiled defaults, so FR also restores the hard sip/puff
  // thresholds and actions (this is also what makes a downgrade-then-4.1.0-FR
  // orphan harmless: the orphaned /settings2.dat would be re-adopted by the
  // re-upgrade — but after an FR on our firmware the values are factory).
  bool hardOk = mem.writeAll(CONF_SETTINGS2_FILE, CONF_SETTINGS2_JSON);
  return mainOk && hardOk;
}

//***Read UID FUNCTION***//
// Function   : readUID
//
// Description: This function reads the device's unique ID from the microcontroller
//
// Parameters : void
//
// Return     : const char* : deviceIDString : 8 hexadecimal string UID from board
//****************************************//
const char* readUID() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: readUID()"); }

  static char deviceIDString[9];
  uint32_t deviceID = 0;

  //#ifdef NRF52480_XXAA
  deviceID = NRF_FICR->DEVICEID[0];  // First part of Device ID for NRF52840 boards
  //#endif

  // The wire and BLE-name contract is exactly eight hexadecimal characters.
  // itoa() dropped leading zeroes, producing variable-length identifiers.
  snprintf(deviceIDString, sizeof(deviceIDString), "%08lx", (unsigned long)deviceID);

  return deviceIDString;
}


//*********************************//
// Screen Functions
//*********************************//

//***INITIALIZE SCREEN FUNCTION***//
// Function   : initScreen
//
// Description: This function initializes the screen
//
// Parameters : void
//
// Return     : void
//****************************************//
void initScreen() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initScreen()"); }
  screen.begin();         // Begin screen module
  //screen.splashScreen();  // Show splash screen
}

// (4.5.5 audit follow-up) The free closeMenu()/clearSplashScreen() wrappers
// that used to live here are gone: closeMenu had no callers (the serial
// CH,1:4 close and the STOP_MENU input action now call the freeze-aware
// LSScreen::closeMenu), and clearSplashScreen's body moved into
// LSScreen::finishSplashClear — a member so the continuation can reset
// _screenStateTimerId when it fires (the free function could not, which
// left the id naming a freed pool slot).

//***SCREEN TRANSITION CONTINUATION FUNCTIONS***//
// Free-function continuations for LSScreen::scheduleTransition() — the
// non-blocking replacements for the delay() calls that used to freeze the
// main loop while informational pages were shown. The screen timer calls
// these when a page's dwell time ends.
//
// Function   : screen transition continuations
//
// Description: Each hands the follow-up action to the matching LSScreen
//              method, which also clears the pending-transition state.
//
// Parameters : void
//
// Return     : void
//****************************************//
void screenExitTransitionDone() {
  screen.finishExitMenu();
}

void screenScrollTransitionDone() {
  screen.beginLongTextScroll();
}

void screenChangeModeTransitionDone() {
  screen.finishChangeMode();
}

void screenReturnToMenuTransitionDone() {
  screen.returnToMenu();
}

void screenFullCalibConfirmTransitionDone() {
  screen.fullCalibrationConfirmMenu();
}

void screenFactoryResetConfirm2TransitionDone() {
  screen.factoryResetConfirm2Menu();
}

void screenModeLockedTransitionDone() {
  screen.finishModeLocked();
}

// Destructive hold-gate note continuation (bench 2026-11-06): redraw the page
// the too-short hold came from (see finishHoldConfirmNote's dispatch).
void screenHoldConfirmNoteTransitionDone() {
  screen.finishHoldConfirmNote();
}

// Upstream #16: the Bluetooth host pages' dwell continuations (the switch
// EXECUTES at the end of its dwell — the CHANGING_MODE_PAGE pattern).
void screenBtSwitchTransitionDone() {
  screen.finishBtSwitch();
}

void screenBtNoteTransitionDone() {
  screen.finishBtNote();
}

//***SHOW CENTER RESET COMPLETE PAGE SCREEN FUNCTION***//
// Function   : showCenterResetComplete
//
// Description: This function shows the center reset complete page
//
// Parameters : void
//
// Return     : void
//****************************************//
void showCenterResetComplete() {
  // Show center reset complete page once center reset is done
  screen.centerResetCompletePage();
}

//***SCREEN LOOP FUNCTION***//
// Function   : screenLoop
//
// Description: This function handles updates to the screen.
//
// Parameters : void
//
// Return     : void
//****************************************//
void screenLoop() {
  //if (USB_DEBUG) { Serial.println("USBDEBUG: screenLoop"); }

  screen.update();  // Update the menu and screen

  //if (USB_DEBUG) { Serial.println("USBDEBUG: end of screenLoop"); }
}

//*********************************//
// Buzzer Functions
//*********************************//

//***INITIALIZE BUZZER FUNCTION***//
// Function   : initBuzzer
//
// Description: This function initializes the Buzzer as feedback method.
//
// Parameters : void
//
// Return     : void
//****************************************//
void initBuzzer() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: Initializing Buzzer"); }

  buzzer.begin();             // Initialize buzzer for sound feedback
  buzzer.playStartupSound();  // Play a sound to indicate power-up
}

//***BUZZER ERROR CUE FUNCTION***//
// Function : buzzerErrorCue
//
// Description: One short, non-blocking error tone for refused interactions
//              (e.g. selecting a mode while the mode lock is on, roadmap
//              item 11) — "that input is locked", not "the device is
//              broken". Forwards to LSBuzzer::playErrorCue (4.5.7 review:
//              this used to call the ~1 s blocking playErrorSound, freezing
//              the whole loop on every refused press).
//
// Parameters : void
//
// Return : void
//****************************************//
void buzzerErrorCue() {
  buzzer.playErrorCue();
}


//*********************************//
// Acceleration Functions
//*********************************//

//***INITIALIZE ACCELERATION FUNCTION***//
// Function   : initAcceleration
//
// Description: This function loads the stored cursor acceleration level into
//              the live global the joystick output path reads (roadmap item
//              9 — the level is a stored setting since v4.0; the output
//              curve now actually applies it).
//
// Parameters : void
//
// Return     : void
//****************************************//
void initAcceleration() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initAcceleration()"); }
  acceleration = getJoystickAcceleration(false, false);
}

//*********************************//
// Communication Mode Functions
//*********************************//

//***INITIALIZE COMMUNICATION FUNCTION***//
// Function   : initCommunicationMode
//
// Description: This function initializes communication mode or configures communication mode
//              based on stored settings in the flash memory (0 = None , 1 = USB , 2 = Wireless)
//
// Parameters : void
//
// Return     : void
//****************************************//
void initCommunicationMode() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initCommunicationMode()"); }

  g_comMode = getCommunicationMode(false, false);

  if (USB_DEBUG) {
    Serial.print("USBDEBUG: g_comMode: ");
    Serial.println(g_comMode);
  }
}


//***USB CONNECTION LOOP FUNCTION***//
// Function   : usbConnectionLoop
//
// Description: This function checks status of USB connection
//
// Parameters : void
//
// Return     : void
//****************************************//
void usbConnectionLoop() {
  // Parked since 2025-Feb-21 (upstream TODO: "Disable usbConnectionLoop
  // until implemented"): the USB connection state it computed had no
  // consumer — errorCheck/usbCheckConnection read usbmouse.isReady()
  // directly — and the write-only global it fed is gone. The registration
  // below stays: the boot pool's nine registrations (including this one)
  // are what the app-repo lstimer-test harness models, and the slot stays
  // reserved for the feature. Disabled at boot; never runs.
}


//***USB CHECK CONNECTION FUNCTION***//
// Function   : usbConnectRearm
//
// Description: 4.6.6: the one-shot re-arm with delete-before-arm. Overwriting
//              usbConnectTimerId[0] while a predecessor one-shot is still
//              pending ORPHANED it — a direct call into usbCheckConnection
//              (the mouse busy-latch path can invoke it while a timer-fired
//              check is mid-episode) then left two pending one-shots that
//              each re-arm on fire, so the population stabilizes at 2: the
//              effective retry cadence doubles and g_usbConnectDelay grows
//              twice per period, defeating the documented 10 s backoff cap.
//              The id holder starts at -1 and deleteTimer(-1) is a no-op, so
//              delete-first is safe on every path including the first arm.
//
// Parameters : delayMs : unsigned long : delay before the next check
//
// Return     : void
//****************************************//
static void usbConnectRearm(unsigned long delayMs) {
  if (usbConnectTimerId[0] >= 0) usbConnectTimer.deleteTimer(usbConnectTimerId[0]);
  usbConnectTimerId[0] = usbConnectTimer.setTimeout(delayMs, usbCheckConnection);
}

// Function   : usbCheckConnection
//
// Description: This function checks if the USB connection is attempting to retry mounting, not ready, or timed out
//              In this case an error screen is shown, and the function is called again after a set time.
//              If the USB connection has not been made, it calls another instance of usb.begin.
//
// Parameters : void
//
// Return     : void
//****************************************//
void usbCheckConnection(void) {
  if (USB_DEBUG) { Serial.println("USBDEBUG: usbCheckConnection()"); }
  bootTrailStamp(6);  // witness v7: the USB connection check is running

  // Self-healing re-enumeration (bench 2026-10-16, second stuck-boot capture):
  // twice now a post-flash 4.5.0 boot came up CONFIGURED but permanently
  // HID-less — serial alive (the host completed SET_CONFIGURATION; TinyUSB's
  // tud_mounted() is cfg_num != 0 in this stack), every mouse report refused
  // (attempts climbing, successes 0) until a manual restart, and the
  // detach-until-descriptor-complete boot order did not prevent it. Whatever
  // the host's exact misstep (locking in a HID-less configuration, or wedging
  // the interrupt endpoint), it does not recover on its own, so the device
  // must force the issue: after CONF_USB_REENUM_AFTER_MS of continuous
  // not-ready, drop and re-raise the bus once — a fresh enumeration rebuilds
  // both the host's configuration and TinyUSB's endpoint state. Bounded at
  // CONF_USB_REENUM_MAX per episode, tracked only in the modes where a USB
  // HID interface is expected (BLE mouse and safe mode legitimately have
  // none). The detach drops the CDC session with it — but a device in this
  // state is already unusable, and on the post-flash boots where it strikes
  // the cycle lands within seconds of boot, before the app reconnects.
  bool usbHidExpected = ((g_operatingMode == CONF_OPERATING_MODE_MOUSE) && (g_comMode == CONF_COM_MODE_USB))
                      || (g_operatingMode == CONF_OPERATING_MODE_GAMEPAD);
  bool usbEpisodeJustStarted = false;
  if (usbHidExpected) {
    bool hidReadyNow = ((g_operatingMode == CONF_OPERATING_MODE_MOUSE) && usbmouse.isReady())
                    || ((g_operatingMode == CONF_OPERATING_MODE_GAMEPAD) && gamepad.isReady());
    if (hidReadyNow) {
      if (g_usbReenumCount > 0) {
        if (USB_DEBUG) {
          Serial.print("USB recovered after forced re-enumeration #");
          Serial.println(g_usbReenumCount);
        }
      }
      g_usbNotReadySinceMs = 0;  // Episode over
      g_usbReenumCount = 0;
      g_usbConnectDelay = CONF_USB_HID_INIT_DELAY;  // A later outage starts with the fast recovery cadence
      // The once-guard now lives in the reset reason itself: this healthy
      // boot will end in whatever reset ends it, and the auto-restart only
      // ever fires on boots that did NOT begin with a software reset.
    } else {
      if (outputAction == CONF_ACTION_DRAG || outputAction == CONF_ACTION_SCROLL) {
        releaseOutputAction();  // A disconnected host must not inherit a held mode on reconnect
      }
      if (g_usbNotReadySinceMs == 0) {
        g_usbNotReadySinceMs = millis();  // Episode begins
        usbEpisodeJustStarted = true;
      } else if ((millis() - g_usbNotReadySinceMs >= CONF_USB_REENUM_AFTER_MS) && (g_usbReenumCount < CONF_USB_REENUM_MAX)) {
        g_usbReenumCount++;
        if (USB_DEBUG) {
          Serial.print("USB forced re-enumeration #");
          Serial.print(g_usbReenumCount);
          Serial.print(" at ");
          Serial.println(millis());
        }
        USBDevice.detach();
        delay(CONF_USB_REENUM_DWELL_MS);  // Dark long enough for the host to tear the old configuration down
        USBDevice.attach();
        g_usbConnectDelay = CONF_USB_HID_INIT_DELAY;  // Resume fast checks while the fresh enumeration settles
        g_usbNotReadySinceMs = millis();              // Fresh budget for the fresh enumeration
      } else if ((millis() - g_usbNotReadySinceMs >= CONF_USB_REENUM_AFTER_MS) && (g_usbReenumCount >= CONF_USB_REENUM_MAX)
                 && !g_usbRecoveryRestartedPrev) {
        // The re-enumeration budget is spent and the HID interface is still
        // dead while serial lives — the host is not recovering this
        // composite, and no bus-level cycle left will change that (bench
        // 2026-10-17: a wedge survived three forced cycles). A full device
        // restart has cleared every such boot on the bench — fresh USB
        // peripheral, fresh address, seconds of bus darkness — so spend the
        // one auto-restart this recovery chain allows. The next boot wins the
        // enumeration the way every restart boot has; if it somehow wedges
        // again, the dedicated retained marker keeps this branch from firing and the
        // page + retry ticks carry on for the app/user to see honestly.
        // (4.5.7 review: the bootTrailStamp(5) that used to live here is
        // GONE — pt=5 is softwareReset's code, and double-booking it made
        // a post-mortem unable to tell a deliberate user/menu reset from
        // this USB-recovery restart. The stamp(6) at this function's entry
        // already names the true death context.)
        if (USB_DEBUG) {
          Serial.print("USB restarting device to recover the HID interface at ");
          Serial.println(millis());
        }
        screen.restartPage();
        delay(500);  // Bounded: drain the serial line and let the framebuffer push complete (bounded by Wire)
        // 4.6.6: skip the marker inside the Bluefruit.begin() window (neither
        // retention path is safe there — see lipsyncRetentionUnsafe). The
        // restart itself still fires; the only cost is the next boot treating
        // the reset as unattributed instead of USB-recovery, and a USB
        // recovery episode cannot even run on a BLE boot before its deferred
        // USB attach — this gate is symmetry with the other diagnostic writes.
        if (!lipsyncRetentionUnsafe()) {
          lipsyncRetentionUpdate(1, 0x1C, (uint8_t)(CONF_RETENTION_MARKER_USB_RECOVERY << 2));
        }
        NVIC_SystemReset();
      }
    }
  } else {
    g_usbNotReadySinceMs = 0;
    g_usbReenumCount = 0;
  }

  // Normal host enumeration is asynchronous and commonly outlives the first
  // few 20 ms report ticks. On the first observation, arm a quiet check and
  // return—do not draw an error page or call begin() again while the host is
  // still completing a healthy enumeration. Persistent outages re-enter the
  // normal ladder on that timeout.
  if (usbEpisodeJustStarted) {
    usbConnectRearm(CONF_USB_HID_INIT_DELAY);  // 4.6.6: delete-before-arm (was the one site that already deleted first)
    return;
  }


  if (usbmouse.usbRetrying || gamepad.usbRetrying) {

    if (usbmouse.usbRetrying) {
      if (USB_DEBUG) {
        Serial.print("Reattempting USB Mouse ");
        Serial.println(millis());
      }

      usbmouse.begin();
    } else if (gamepad.usbRetrying) {
      if (USB_DEBUG) {
        Serial.print("Reattempting USB Gamepad ");
        Serial.println(millis());
      }

      gamepad.begin();
    }

    screen.drawUsbErrorPageOnce();  // Draw at most once per episode (LSScreen gates display/bus health)

    // increase variable g_usbConnectDelay. Capped at 10 s (bench-observed
    // 2026-10-15): the ×1.2 growth used to run to 120 s to space an EXPENSIVE
    // tick — the old retry branch re-ran begin() and redrew the full
    // framebuffer every time (the 4.2.0 amplifier). Today's tick is cheap
    // (isReady reads, at most one draw), so a long backoff only delays the
    // ready screen behind actual host recovery: after a post-flash boot the
    // first ticks land before the host finishes configuring the composite
    // device, and by the time it is ready the next tick can be ~40 s out —
    // the No-USB page lingers on a device that is already working.
  if (g_usbConnectDelay < 10000) {
      unsigned int nextDelay = (unsigned int)(g_usbConnectDelay * 1.2f);
      g_usbConnectDelay = (nextDelay > 10000U) ? 10000U : nextDelay;
    }

    usbConnectRearm(g_usbConnectDelay);  // 4.6.6: delete-before-arm — keep retrying connection until USB connection is made

  } else if (((g_operatingMode == CONF_OPERATING_MODE_MOUSE) && (g_comMode == CONF_COM_MODE_USB) && (!usbmouse.isReady()))  // in usb mouse mode and usb mouse is not ready
      || ((g_operatingMode == CONF_OPERATING_MODE_GAMEPAD) && !gamepad.isReady())){                                         // in usb gamepad mode and usb gamepad is not ready

    screen.drawUsbErrorPageOnce();

    usbConnectRearm(g_usbConnectDelay);  // 4.6.6: delete-before-arm — keep retrying connection until USB connection is made


  } else if (usbmouse.timedOut && !usbmouse.isReady()) {
    // A report was attempted and the interface is genuinely still down —
    // keep the page and keep checking. A latched timedOut with a READY
    // interface (mouse reports suspended in gamepad/debug mode never clear
    // the latch themselves) falls through to the healthy branch instead of
    // parking here forever.
    screen.drawUsbErrorPageOnce();
    usbConnectRearm(g_usbConnectDelay);  // 4.6.6: delete-before-arm — keep retrying connection until USB connection is made
  } else {
    usbmouse.timedOut = false;  // Stale latch: the interface is ready, the episode is over
    usbmouse.consecutiveSkips = 0;  // 4.5.7 review: the skip counter must reset with the latch, or the first transient not-ready tick after recovery re-latches after ONE skip instead of three
    gamepad.timedOut = false;
    g_usbConnectDelay = CONF_USB_HID_INIT_DELAY;

    // Connection healthy. The page clear used to be one-shot — this branch
    // never re-armed — and resetUsbErrorPage cleared the episode latch even
    // when its draw was gated off, so a single tick landing while the bus
    // sat in its post-recovery window stranded the No-USB page on the OLED
    // for the rest of the boot (bench 2026-10-16, twice: stuck until a
    // manual restart on a device whose serial session worked the whole
    // time). The clear now reports success only when the ready page actually
    // landed; while it has not, re-arm and try again. The retry is cheap
    // (a gate check, at most one draw) and ends for good once the page
    // clears or there was never anything painted.
    if (screen.resetUsbErrorPage()) {
      readyToUse();
    } else {
      usbConnectRearm(1000);  // 4.6.6: delete-before-arm
    }
  }
}

//***TINYUSB MOUNT/UNMOUNT WITNESS CALLBACKS***//
// Function   : tud_mount_cb / tud_umount_cb
//
// Description: TinyUSB calls tud_mount_cb once the host has completed
//              SET_CONFIGURATION (in this stack tud_mounted() is cfg_num != 0)
//              and tud_umount_cb when the bus resets away from that state.
//              These hooks print one line per event so an exported session log
//              carries the host's configure/unconfigure timeline — the missing
//              witness in the post-flash stuck-boot forensics (bench
//              2026-10-16: BH showed "configured but HID never ready" with no
//              way to see WHEN the host configured or whether it ever tried
//              twice). extern "C" is required: TinyUSB looks for these as C
//              symbols and the sketch compiles as C++.
//
// Parameters : void
//
// Return     : void
//****************************************//
// 4.9.9 review round 3: the hooks record the event; the LOOP task emits the
// line (usbEventDrain, called from loop()). TinyUSB runs these callbacks in
// its own FreeRTOS task — a direct Serial.print here interleaved with
// serialTxService()'s chunked writes from the loop task at chunk granularity
// (the exact line-corruption class the TX queue was built to eliminate).
// Single aligned volatile stores from the USB task, taken-and-cleared by the
// loop task: an event landing mid-drain re-raises its bit.
volatile uint8_t g_usbEventPending = 0;  // bit0 = configured, bit1 = unconfigured
volatile unsigned long g_usbEventConfiguredMs = 0;
volatile unsigned long g_usbEventUnconfiguredMs = 0;

extern "C" void tud_mount_cb(void) {
  if (!USB_DEBUG) return;
  g_usbEventConfiguredMs = millis();
  g_usbEventPending |= 0x1;
}

extern "C" void tud_umount_cb(void) {
  if (!USB_DEBUG) return;
  g_usbEventUnconfiguredMs = millis();
  g_usbEventPending |= 0x2;
}

void usbEventDrain() {
  if (g_usbEventPending == 0) return;
  const uint8_t pending = g_usbEventPending;
  // 4.9.9 review round 4 (lossy-clear fix): clear only the bits being
  // drained — an event raised in the TinyUSB task between the read and the
  // clear must survive (a whole-word store would erase it).
  g_usbEventPending &= (uint8_t)~pending;
  if (pending & 0x1) {
    Serial.print("USB-EVT: configured at ");
    Serial.println(g_usbEventConfiguredMs);
  }
  if (pending & 0x2) {
    Serial.print("USB-EVT: unconfigured at ");
    Serial.println(g_usbEventUnconfiguredMs);
  }
}



//*********************************//
// Operating Mode Functions
//*********************************//



//***INITIALIZE OPERATING MODE FUNCTION***//
// Function   : initOperatingMode
//
// Description: This function initializes the operating mode from the stored
//              settings in flash memory (1 = Mouse, 2 = Gamepad; SAFE (3) is
//              a runtime-only state and never a valid stored value — see the
//              clamp below)
//
// Parameters : void
//
// Return     : void
//****************************************//
void initOperatingMode() {

  //g_operatingMode = getOperatingMode(false,false);
  g_operatingMode = mem.readInt(CONF_SETTINGS_FILE, "OM"); // retrieve operating mode from memory
  // Boot-load clamp (4.5.7 review): mode 0 has no beginComOpMode case and no
  // sender (the API now rejects it, CONF_OPERATING_MODE_MIN is 1) — but a
  // stored 0 from an old/hand-edited file booted a device whose BLE-poll
  // switch then hammered an uninitialized SoftDevice with a 1 s stall per
  // tick. Out of range falls back to the default mouse mode.
  if ((g_operatingMode < CONF_OPERATING_MODE_MIN) || (g_operatingMode > CONF_OPERATING_MODE_SETTABLE_MAX)) {
    g_operatingMode = CONF_OPERATING_MODE_DEFAULT;  // also catches a stored SAFE(3) — not a valid boot mode (4.5.7 review)
    if (mem.isLastReadOk()) {  // boot-path heal: a transient failed read is 0 too — never rewrite the stored mode from it (the getModelNumber pattern; the getOperatingMode fix's boot-side twin)
      mem.writeInt(CONF_SETTINGS_FILE, "OM", g_operatingMode);
    }
  }

}

//***CHANGE OPERATING MODE FUNCTION***//
// Function   : changeOperatingMode
//
// Description: Applies an operating-mode change by restarting the device —
//              the interfaces are re-begun for the stored mode on the next
//              boot. 4.9.1 (dead-store removal): persistence happens in the
//              CALLERS before this call (OM/CM store the pair, the menu's
//              finishChangeMode runs storeModePair), and softwareReset()
//              only returns when it REFUSED — 4.9.9 review round 4: the BLE
//              init-window gate can bail out (named on the wire) without
//              touching anything, so the trailing g_operatingMode assignment
//              this function used to carry must STAY gone (the assignment
//              would flip the global AFTER usbmouse.end()/btmouse.end() ran
//              on the accepted path — the 4.5.7 "live mode claims a mode the
//              interfaces never entered" bug, recreated — and on the refused
//              path it would claim a mode whose interfaces were never
//              begun at all). The serial OM endpoint gates the reset BEFORE
//              its store/ack, so a refusal leaves the stored value as the
//              only forward effect (it lands at the next boot).
//
// Parameters : inputOperatingMode : int : The operating mode to change to
//
// Return     : void
//****************************************//
void changeOperatingMode(int inputOperatingState) {
  if (inputOperatingState != g_operatingMode) {
    // 4.9.9 review round 4: softwareReset() returns without resetting when
    // the BLE init window is still open (refused, named on the wire) — but
    // the OM endpoint's gate has already run before this call, so this site
    // can only observe an instant, always-reset gate.
    softwareReset();
  }
}


//***INITIALIZE OPERATING MODE FUNCTION***//
// Function   : beginComOpMode                  // TODO: rename this?
//
// Description: This function calls functions to initialize communication mode and operating mode
//              and begins instance of either USB mouse, Bluetooth mouse, or USB Gamepad
//
// Parameters : void
//
// Return     : void
//****************************************//
void beginComOpMode() {

  // Safe mode comes up CDC-only (4.5.7 review): checkSafeMode() runs BEFORE
  // this function now, so the decision is already made. Attach the bus for
  // serial recovery, but read NEITHER the stored operating mode (which would
  // overwrite the SAFE that checkSafeMode set) NOR the stored communication
  // mode (a stored BLE mode must not initialize the SoftDevice on a safe
  // boot), and begin NO mode interface. usbCheckConnection's episode
  // machinery already excludes safe mode from its HID-expected modes.
  if (g_safeModeEnabled) {
    if (USB_DEBUG) { Serial.println("USBDEBUG: beginComOpMode: Safe Mode (CDC-only)"); }
    USBDevice.attach();
    return;
  }

  initCommunicationMode();  // Retrieve communication mode from memory (None, USB, Bluetooth)
  initOperatingMode();      // Retrieve operating mode from memory (USB Mouse, Bluetooth Mouse, Gamepad)

  if (USB_DEBUG) {
    Serial.print(F("BOOT: com-op om="));
    Serial.print(g_operatingMode);
    Serial.print(F(" cm="));
    Serial.println(g_comMode);
  }

  // Cross-validate the loaded pair (4.5.7 review): the setters reject
  // gamepad+BLE, but the boot loaders clamp each value to its own range
  // only — a hand-edited/old settings file with OM=2+CM=2 booted a device
  // whose btFeedbackLoop then hammered the UNINITIALIZED SoftDevice for a
  // full second per poll (the bench-documented 1 s stall), and whose USB
  // recovery ladder never armed (it keys on the com mode, and the gamepad
  // paths never call usbCheckConnection themselves). Force the com mode to
  // USB, mirroring the setter contract, and persist the correction so the
  // file heals.
  if ((g_operatingMode == CONF_OPERATING_MODE_GAMEPAD) && (g_comMode == CONF_COM_MODE_BLE)) {
    g_comMode = CONF_COM_MODE_USB;
    mem.writeInt(CONF_SETTINGS_FILE, "CM", CONF_COM_MODE_USB);
    // 4.8.7 review: this in-place Serial.println ran BEFORE the USB attach —
    // inside TinyUSB's pre-open-port discard window — so the correction was
    // invisible to every host. The first-host-byte report block (which the
    // flag below arms) now carries the named line instead.
    g_comModeHealedThisBoot = true;
    g_bootReportWorthy = true;
  }

  // Bus up only after the selected interface is registered: setup() detached
  // at the top, CDC registered at Serial.begin(), and USB mouse/gamepad add
  // HID while still detached. This structurally closes the old CDC-only
  // descriptor race instead of relying on a host taking longer than the
  // attach->begin call gap to fetch descriptors. BLE/safe boots intentionally
  // attach CDC-only.
  switch (g_operatingMode) {
    case CONF_OPERATING_MODE_MOUSE:
      switch (g_comMode) {
        case CONF_COM_MODE_USB:  // USB Mouse
          usbmouse.begin();
          USBDevice.attach();
          break;
        case CONF_COM_MODE_BLE:  // Bluetooth Mouse
          {
            // 4.5.10: the name is copied to a STATIC buffer and the init is
            // DEFERRED to the 16 KB task (started at the end of setup) —
            // the loop task's 4 KB stack must not carry Bluefruit.begin.
            // 4.5.18: the USB attach is RESTORED TO THE STOCK ORDER —
            // enumerated BEFORE the SoftDevice comes up, exactly like the
            // stock blehid_mouse example and 4.1.0. The 4.5.11 deferral
            // was built on a since-RETRACTED claim (the core's USB/SD
            // coexistence hooks DO exist and begin() runs them itself),
            // and it left our boot attaching into a live SoftDevice — a
            // deviation no working recipe performs.
            USBDevice.attach();
            snprintf(g_bleDeviceName, sizeof(g_bleDeviceName), "LS_%s", g_deviceUID.c_str());
            g_bleInitPending = true;
            if (USB_DEBUG) { Serial.println(F("BOOT: BLE deferred to 16KB task")); }
          }
          break;
      }
      break;
    case CONF_OPERATING_MODE_GAMEPAD:  // USB Gamepad
      gamepad.begin();
      USBDevice.attach();
      break;
      // default: (SAFE is handled by the early return above)
  }
  if (USB_DEBUG) { Serial.println(F("BOOT: interfaces up")); }


  if (USB_DEBUG) {
    Serial.print("USBDEBUG: g_operatingMode: ");
    Serial.println(g_operatingMode);
  }

}  // end beginComOpMode

//*********************************//
// Input Functions
//*********************************//


//***INITIALIZE INPUTS FUNCTION***//
// Function   : initInput
//
// Description: This function initializes inputs including input buttons and input switches.
//
// Parameters : void
//
// Return     : void
//****************************************//
void initInput() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: Initializing Input"); }
  
  // Hub Input Buttons
  ib.begin();                                                                      // Begin input buttons
  buttonActionSize = sizeof(buttonActionProperty) / sizeof(inputActionStruct);     // Size of total available input button actions
  buttonActionMaxTime = getActionMaxTime(buttonActionSize, buttonActionProperty);  // Maximum button action end time

  // Hub External Switch Inputs
  is.begin();                                                                      // Begin input switches
  switchActionSize = sizeof(switchActionProperty) / sizeof(inputActionStruct);     // Size of total available switch input actions
  switchActionMaxTime = getActionMaxTime(switchActionSize, switchActionProperty);  // Maximum switch action end time
  // Seed the live switch action table from the compiled one — remappable
  // cells (roadmap item 11's #20 follow-up) are overlaid by initSwitchActions()
  memcpy(g_switchActionTable, switchActionProperty, sizeof(switchActionProperty));
}

//***INITIALIZE RESTRICTIONS FUNCTION***//
// Function   : initRestrictions
//
// Description: Loads the input restriction settings (roadmap item 11) from
//              flash memory into the live gates. Runs before any input can
//              fire, so a locked-down configuration is in force from the
//              first tick of the input timers.
//
// Parameters : void
//
// Return     : void
//****************************************//
void initRestrictions() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initRestrictions()"); }
  getSapDisabled(false, false);
  getMenuButtonsOnly(false, false);
  getModeLocked(false, false);
  getCursorHoldDuringSap(false, false);
  // Input timing windows (roadmap item 15) load with the same stroke so the
  // first tick of the input timers already sees the user's windows.
  getInputWindowShort(false, false);
  getInputWindowLong(false, false);
  getInputWindowMax(false, false);
  sanitizeInputWindows();
  // External switch action remaps (#20) join the same stroke — the getters
  // apply any stored mapping onto the live table before the first tick.
  initSwitchActions();
  // Upstream #58: the hard-band action overrides (HA/HB) are applied onto the
  // live SAP table before the first input tick. A device without stored
  // HA/HB (any settings file written by older firmware) keeps the compiled
  // table byte-for-byte.
  initSapActions();
}

//***SANITIZE INPUT WINDOWS FUNCTION***//
// Function   : sanitizeInputWindows
//
// Description: Boot-load validation for the input timing windows (4.5.7
//              review): the getters apply whatever the settings file holds
//              with no range or ordering checks — asymmetric with the
//              switch-remap load path, which validates against its
//              allowlist. A hand-edited, corrupted, or foreign file could
//              load inverted windows (a quick puff firing the MAX row) or
//              out-of-range values. An offending stored value falls back to
//              the compiled default (0) IN MEMORY ONLY — the stored value
//              is healed to 0 (the compiled default) so a later API getter
//              cannot reload the bad value and undo the boot sanitizer.
//
// Parameters : void
//
// Return     : void
//****************************************//
void sanitizeInputWindows() {
  unsigned long shortEff = (g_inputWindowShortMs > 0) ? g_inputWindowShortMs : CONF_INPUT_WINDOW_SHORT_DEFAULT_MS;
  if (g_inputWindowShortMs > 0
      && (g_inputWindowShortMs < CONF_INPUT_WINDOW_SHORT_MIN_MS || g_inputWindowShortMs > CONF_INPUT_WINDOW_SHORT_MAX_MS
          || shortEff >= ((g_inputWindowLongMs > 0) ? g_inputWindowLongMs : CONF_INPUT_WINDOW_LONG_DEFAULT_MS))) {
    g_inputWindowShortMs = 0;
    mem.writeInt(CONF_SETTINGS_FILE, "WS", 0);
  }
  unsigned long longEff = (g_inputWindowLongMs > 0) ? g_inputWindowLongMs : CONF_INPUT_WINDOW_LONG_DEFAULT_MS;
  shortEff = (g_inputWindowShortMs > 0) ? g_inputWindowShortMs : CONF_INPUT_WINDOW_SHORT_DEFAULT_MS;
  if (g_inputWindowLongMs > 0
      && (g_inputWindowLongMs < CONF_INPUT_WINDOW_LONG_MIN_MS || g_inputWindowLongMs > CONF_INPUT_WINDOW_LONG_MAX_MS
          || longEff <= shortEff || longEff >= ((g_inputWindowMaxMs > 0) ? g_inputWindowMaxMs : CONF_INPUT_WINDOW_MAX_DEFAULT_MS))) {
    g_inputWindowLongMs = 0;
    mem.writeInt(CONF_SETTINGS_FILE, "WL", 0);
  }
  unsigned long maxEff = (g_inputWindowMaxMs > 0) ? g_inputWindowMaxMs : CONF_INPUT_WINDOW_MAX_DEFAULT_MS;
  longEff = (g_inputWindowLongMs > 0) ? g_inputWindowLongMs : CONF_INPUT_WINDOW_LONG_DEFAULT_MS;
  if (g_inputWindowMaxMs > 0
      && (g_inputWindowMaxMs < CONF_INPUT_WINDOW_MAX_MIN_MS || g_inputWindowMaxMs > CONF_INPUT_WINDOW_MAX_MAX_MS
          || maxEff <= longEff)) {
    g_inputWindowMaxMs = 0;
    mem.writeInt(CONF_SETTINGS_FILE, "WM", 0);
  }
}

//***INITIALIZE SWITCH ACTIONS FUNCTION***//
// Function   : initSwitchActions
//
// Description: Loads the external-switch action remaps (roadmap item 11's
//              #20 follow-up, firmware 4.5.0) from flash memory onto the
//              live switch action table. Reads go through the SA/SB/SC/GA/
//              GB/GC getters so the boot path and the serial API share one
//              apply implementation; a device with no stored mapping keeps
//              the compiled table exactly.
//
// Parameters : void
//
// Return     : void
//****************************************//
void initSwitchActions() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initSwitchActions()"); }
  getSwitchAction(false, false, "SA");
  getSwitchAction(false, false, "SB");
  getSwitchAction(false, false, "SC");
  getSwitchAction(false, false, "GA");
  getSwitchAction(false, false, "GB");
  getSwitchAction(false, false, "GC");
}

//***INITIALIZE SAP ACTIONS FUNCTION***//
// Function   : initSapActions
//
// Description: Seeds g_sapActionTable from the compiled sapActionProperty and
//              overlays the hard-band action overrides (HA/HB from
//              /settings2.dat) — upstream #58. Runs with the other
//              input-related stored settings in initRestrictions(), so the
//              live table is in force from the first input tick. The seed
//              document ships WITH HA/HB (4.7.0), so a normal store leaves
//              the table byte-identical to the compiled one; the one accepted
//              edge is a PARSEABLE settings2 that lacks the keys (hand-edited
//              only) — readInt yields 0 = NOTHING, which is allowlisted, so
//              the hard band goes INERT (the fail-safe direction), re-armed
//              by the first HA/HB SET, which applies live.
//
// Parameters : void
//
// Return     : void
//*********************************//
void initSapActions() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initSapActions()"); }
  // Self-contained seed: initRestrictions() runs BEFORE initSipAndPuff() in
  // setup(), so this function cannot rely on anyone else having seeded the
  // live table (and a later seed would wipe the overrides).
  memcpy(g_sapActionTable, sapActionProperty, sizeof(sapActionProperty));
  applyHardBandActionOverrides();
}

//***SWITCH REMAP HELPER FUNCTIONS***//
// Function   : switchRemapAllowed / switchRemapApplyCell
//
// Description: The validation and apply helpers shared by every remap
//              endpoint. switchRemapAllowed pins a cell value to the
//              caregiver-safe allowlist (LSConfig.h — one accidental switch
//              press must never be able to reset or factory-reset the
//              device), and is COLUMN-AWARE (4.5.7 review): the gamepad
//              columns additionally reject CONF_ACTION_DRAG/SCROLL — mouse
//              hold modes that wedge the whole input path in gamepad mode
//              (see CONF_SWITCH_REMAP_GAMEPAD_FORBIDDEN).
//              switchRemapApplyCell writes one remapped cell into
//              the live table; the jack index runs 0-2, the window index
//              0-2 (short/long/max), gamepad selects the action column.
//
// Parameters : actionNumber : int : an output action number
//              gamepad : bool : true = gamepad-mode column
//              jack / window : int : cell coordinates
//
// Return     : bool : allowlist membership
//              void : (apply)
//****************************************//
bool switchRemapAllowed(int actionNumber, bool gamepad) {
  bool allowed = false;
  for (unsigned int i = 0; i < CONF_SWITCH_REMAP_ALLOWED_NUM; i++) {
    if (CONF_SWITCH_REMAP_ALLOWED[i] == actionNumber) { allowed = true; break; }
  }
  if (allowed && gamepad) {
    for (unsigned int i = 0; i < CONF_SWITCH_REMAP_GAMEPAD_FORBIDDEN_NUM; i++) {
      if (CONF_SWITCH_REMAP_GAMEPAD_FORBIDDEN[i] == actionNumber) { allowed = false; break; }
    }
  }
  return allowed;
}

void switchRemapApplyCell(int jack, int window, bool gamepad, int actionNumber) {
  int row = CONF_SWITCH_REMAP_FIRST_ROW + jack * CONF_SWITCH_REMAP_ROWS_PER_JACK + window;
  if (row < 0 || row >= (int)(sizeof(switchActionProperty) / sizeof(inputActionStruct))) return;
  if (gamepad) {
    g_switchActionTable[row].gamepadOutputActionNumber = (uint8_t)actionNumber;
  } else {
    g_switchActionTable[row].mouseOutputActionNumber = (uint8_t)actionNumber;
  }
}

// Upstream #58: apply the HA/HB hard-band action overrides into the live SAP
// table. The stored value IS the effective value (no sentinel: the seed
// document carries the real compiled defaults — 5 = SCROLL for hard sip,
// 4 = DRAG for hard puff — and CONF_ACTION_NOTHING is a legal remap target,
// so 0 must stay a real mapping). A stored value that fails the caregiver
// allowlist falls back to the compiled row — the table already holds the
// compiled values, so "no change" is the compiled default (same
// defense-in-depth as the switch-remap load path).
void applyHardBandActionOverrides() {
  int hardSipRow = -1, hardPuffRow = -1;
  for (int i = 0; i < (int)(sizeof(sapActionProperty) / sizeof(inputActionStruct)); i++) {
    if (sapActionProperty[i].inputActionState == PRESS_SAP_MAIN_STATE_HARD_SIP) hardSipRow = i;
    if (sapActionProperty[i].inputActionState == PRESS_SAP_MAIN_STATE_HARD_PUFF) hardPuffRow = i;
  }
  int ha = mem.readInt(CONF_SETTINGS2_FILE, "HA");
  const bool haReadOk = mem.isLastReadOk();  // a failed read yields 0 = NOTHING, which is allowlisted — applying it would silence the band while the file still holds the real action (and the setter just acked SUCCESS: the live-apply path must not act on a failed read)
  int hb = mem.readInt(CONF_SETTINGS2_FILE, "HB");
  const bool hbReadOk = mem.isLastReadOk();
  if (hardSipRow >= 0 && haReadOk && switchRemapAllowed(ha, false)) {
    g_sapActionTable[hardSipRow].mouseOutputActionNumber = (uint8_t)ha;
  }
  if (hardPuffRow >= 0 && hbReadOk && switchRemapAllowed(hb, false)) {
    g_sapActionTable[hardPuffRow].mouseOutputActionNumber = (uint8_t)hb;
  }
}

int switchRemapDefaultCell(int jack, int window, bool gamepad) {
  int row = CONF_SWITCH_REMAP_FIRST_ROW + jack * CONF_SWITCH_REMAP_ROWS_PER_JACK + window;
  if (row < 0 || row >= (int)(sizeof(switchActionProperty) / sizeof(inputActionStruct))) return 0;
  if (gamepad) return (int)switchActionProperty[row].gamepadOutputActionNumber;
  return (int)switchActionProperty[row].mouseOutputActionNumber;
}

// 4.9.1 (read-truth doctrine): the LIVE cell — what the device actually
// fires — for the switch-remap getters' failed-read answer. The getter
// must neither rewrite the live table from a failed read (the stored-0
// path would apply the compiled defaults over the user's remap) nor
// answer a value that is not in force.
int switchRemapLiveCell(int jack, int window, bool gamepad) {
  int row = CONF_SWITCH_REMAP_FIRST_ROW + jack * CONF_SWITCH_REMAP_ROWS_PER_JACK + window;
  if (row < 0 || row >= (int)(sizeof(switchActionProperty) / sizeof(inputActionStruct))) return 0;
  if (gamepad) return (int)g_switchActionTable[row].gamepadOutputActionNumber;
  return (int)g_switchActionTable[row].mouseOutputActionNumber;
}

// 4.9.1 (read-truth doctrine): the LIVE hard-band action — the row the
// classifier actually fires — for the HA/HB getters' failed-read answer
// (a failed read yields 0 = NOTHING, which is in vocabulary and
// allowlisted, so the old shape answered NOTHING with SUCCESS while the
// live row kept the real action).
int hardBandLiveAction(bool hardSip) {
  for (int i = 0; i < (int)(sizeof(sapActionProperty) / sizeof(inputActionStruct)); i++) {
    if (sapActionProperty[i].inputActionState == (hardSip ? PRESS_SAP_MAIN_STATE_HARD_SIP : PRESS_SAP_MAIN_STATE_HARD_PUFF)) {
      return (int)g_sapActionTable[i].mouseOutputActionNumber;
    }
  }
  return CONF_ACTION_NOTHING;
}

//***EFFECTIVE WINDOW FUNCTION***//
// Function   : effectiveWindowMs
//
// Description: Maps an action-table row's compiled window boundary
//              (1000 / 3000 / 8000 ms — the shorts/longs/very-longs the
//              tables are written against) onto the user's stored input
//              timing windows (roadmap item 15, upstream #62): a stored 0
//              is the compiled default, so the factory feel is exact.
//              Any other boundary value passes through unchanged.
//
// Parameters : defaultWindowMs : unsigned long : The compiled boundary value
//
// Return     : unsigned long : The boundary in force
//****************************************//
unsigned long effectiveWindowMs(unsigned long defaultWindowMs) {
  switch (defaultWindowMs) {
    case CONF_INPUT_WINDOW_SHORT_DEFAULT_MS:
      return (g_inputWindowShortMs > 0) ? g_inputWindowShortMs : CONF_INPUT_WINDOW_SHORT_DEFAULT_MS;
    case CONF_INPUT_WINDOW_LONG_DEFAULT_MS:
      return (g_inputWindowLongMs > 0) ? g_inputWindowLongMs : CONF_INPUT_WINDOW_LONG_DEFAULT_MS;
    case CONF_INPUT_WINDOW_MAX_DEFAULT_MS:
      return (g_inputWindowMaxMs > 0) ? g_inputWindowMaxMs : CONF_INPUT_WINDOW_MAX_DEFAULT_MS;
    default:
      return defaultWindowMs;  // 0 (row inert) or any custom boundary passes through
  }
}

//***FILL USB HID DIAGNOSTICS FUNCTION***//
// Function   : fillUsbHidDiagnostics
//
// Description: HID-layer telemetry for the BH,0:0 bus-health line (bench
//              2026-10-16: the cursor stopped moving on 4.5.0 while the
//              ready page showed, the joystick read fine and serial kept
//              working — the ready page only draws when isReady() held, so
//              the failure hides between "mouseReport never called",
//              "called and refused by TinyUSB" and "accepted but ignored by
//              the host". These seven numbers split exactly those cases).
//
//              The values describe the ACTIVE mode's HID interface (bench
//              2026-10-18, gamepad-mode validation): mouse mode reads
//              usbmouse and gamepad mode reads the gamepad — the old
//              unconditional mouse read made BH report hidReady=0 and
//              attempts=0 forever on a healthy gamepad boot, so health
//              checks and stuck-boot forensics lied exactly when they
//              mattered (LSUSBGamepad now carries the same counters as
//              LSUSBMouse, filled at the same choke points).
//
// Parameters : out : int[9] : filled with [usbMounted, hidReady, hidRetrying,
//              hidTimedOut, centerComplete, reportAttempts, reportSuccesses,
//              nonzeroReports, maxAbsReport]
//
// Return     : void
//****************************************//
void fillUsbHidDiagnostics(int out[9]) {
  const bool gamepadMode = (g_operatingMode == CONF_OPERATING_MODE_GAMEPAD);
  out[0] = USBDevice.mounted() ? 1 : 0;
  out[1] = (gamepadMode ? gamepad.isReady() : usbmouse.isReady()) ? 1 : 0;
  out[2] = (gamepadMode ? gamepad.usbRetrying : usbmouse.usbRetrying) ? 1 : 0;
  out[3] = (gamepadMode ? gamepad.timedOut : usbmouse.timedOut) ? 1 : 0;
  out[4] = g_resetCenterComplete ? 1 : 0;
  // Wrap-safe reads of boot-long counters (the raw uint32 would overflow int)
  out[5] = (int)((gamepadMode ? gamepad.reportAttempts : usbmouse.reportAttempts) % 1000000007);
  out[6] = (int)((gamepadMode ? gamepad.reportSuccesses : usbmouse.reportSuccesses) % 1000000007);
  out[7] = (int)((gamepadMode ? gamepad.nonzeroReports : usbmouse.nonzeroReports) % 1000000007);
  out[8] = gamepadMode ? gamepad.maxAbsReport : usbmouse.maxAbsReport;
}

//***FILL JOYSTICK PIPELINE DIAGNOSTICS FUNCTION***//
// Function   : fillJoystickPipelineDiagnostics
//
// Description: Free-function bridge for LSJoystick::fillPipelineDiagnostics
//              (the .ino cannot call private members directly, but the
//              merged-TU free function in LSApiDeclarations.h's pattern
//              needs a callable from LSAPI.ino's BH handler).
//
// Parameters : out : int[14] : the live pipeline internals
//
// Return     : void
//****************************************//
void fillJoystickPipelineDiagnostics(int out[14]) {
  js.fillPipelineDiagnostics(out);
}

//***PRESSURE THRESHOLD LEVEL HELPERS***//
// Function   : pressThresholdLevelUp / pressThresholdLevelDown / pressThresholdLevelFor
//
// Description: The coarse 10-level threshold scale (roadmap item 15,
//              upstream #22): the Hub menu's Increase/Decrease step through
//              PRESS_THRESHOLD_LEVEL_TABLE instead of ±1 hPa, so a
//              mouthpiece-driven adjustment is practical. At the top/bottom
//              of the scale the step is a no-op (the re-read shows the
//              unchanged value).
//
// Return     : the stepped threshold in hPa (level index for the display)
//****************************************//
float pressThresholdLevelUp(float currentThreshold) {
  for (int level = 0; level < PRESS_THRESHOLD_LEVEL_NUM; level++) {
    if (PRESS_THRESHOLD_LEVEL_TABLE[level] > currentThreshold + 0.01f) return PRESS_THRESHOLD_LEVEL_TABLE[level];
  }
  return currentThreshold;  // already at the top level
}

float pressThresholdLevelDown(float currentThreshold) {
  for (int level = PRESS_THRESHOLD_LEVEL_NUM - 1; level >= 0; level--) {
    if (PRESS_THRESHOLD_LEVEL_TABLE[level] < currentThreshold - 0.01f) return PRESS_THRESHOLD_LEVEL_TABLE[level];
  }
  return currentThreshold;  // already at the bottom level
}

int pressThresholdLevelFor(float currentThreshold) {
  for (int level = 0; level < PRESS_THRESHOLD_LEVEL_NUM; level++) {
    if (PRESS_THRESHOLD_LEVEL_TABLE[level] >= currentThreshold - 0.01f) return level + 1;
  }
  return PRESS_THRESHOLD_LEVEL_NUM;
}

//***APPLY INPUT RESTRICTIONS FUNCTION***//
// Function   : applyInputRestrictions
//
// Description: The single seam where a resolved input action meets the
//              restriction settings (roadmap item 11 — the 4.2.0
//              sensor-health gating occupies the same place in spirit: a
//              gate between "an input happened" and "the device acts").
//              Gated actions become CONF_ACTION_NOTHING, which the caller
//              already treats as "no feedback, no output" — a phantom or
//              forbidden input produces nothing at all, not a half-action.
//
// Parameters : actionIndex : int : The resolved output action number
//              inputClass : int : INPUT_CLASS_SAP / _BUTTON / _SWITCH
//
// Return     : int : The action to actually perform (CONF_ACTION_NOTHING when restricted)
//****************************************//
int applyInputRestrictions(int actionIndex, int inputClass) {
  if (actionIndex == CONF_ACTION_NOTHING) return actionIndex;

  // Mode lock: no input path may change the operating mode. The serial API
  // stays open on purpose — a caregiver must be able to unlock or adjust the
  // device through LipSync Connect even while the device user cannot.
  if (g_modeLocked && actionIndex == CONF_ACTION_CHANGE_MODE) return CONF_ACTION_NOTHING;

  // Menu restricted to hub buttons: sip & puff and external switches can
  // neither open/close the menu nor navigate it. Only the hub buttons
  // (inputClass BUTTON) keep menu control.
  if (g_menuButtonsOnly && inputClass != INPUT_CLASS_BUTTON) {
    switch (actionIndex) {
      case CONF_ACTION_START_MENU:
      case CONF_ACTION_STOP_MENU:
      case CONF_ACTION_NEXT_MENU_ITEM:
      case CONF_ACTION_SELECT_MENU_ITEM:
        return CONF_ACTION_NOTHING;
    }
  }

  return actionIndex;
}

//***INPUT LOOP FUNCTION***//
// Function   : inputLoop
//
// Description: This function handles input button and input switch actions.
//
// Parameters : void
//
// Return     : void
//****************************************//
void inputLoop() {

  //if (USB_DEBUG) { Serial.println("USBDEBUG: inputLoop"); }
  // Read new values
  ib.update();  // update buttons
  is.update();  // update external assistive switch inputs

  // Get the last state change
  buttonState = ib.getInputState();
  switchState = is.getInputState();

  // Evaluate Output Actions
  evaluateOutputAction(buttonState, buttonActionMaxTime, buttonActionSize, buttonActionProperty, INPUT_CLASS_BUTTON);
  evaluateOutputAction(switchState, switchActionMaxTime, switchActionSize, g_switchActionTable, INPUT_CLASS_SWITCH);

}

//*********************************//
// Sip and Puff Functions
//*********************************//

//***INITIALIZE SIP AND PUFF FUNCTION***//
// Function   : initSipAndPuff
//
// Description: This function initializes sip and puff as inputs.
//
// Parameters : void
//
// Return     : void
//****************************************//
void initSipAndPuff() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: Initializing Sip and Puff"); }
  ps.begin();                                                             // Begin sip and puff
  getSipPressureThreshold(false, false);                                  // Get sip  pressure thresholds stored in flash memory
  getPuffPressureThreshold(false, false);                                 // Get puff pressure thresholds stored in flash memory
  // Upstream #58: the hard thresholds load after the regular ones (the heal
  // below compares against them). Each getter range-checks its own value and
  // applies it to ps; a stored hard value that sits below regular + margin
  // (a hand-edited or foreign settings2) is healed up to the margin floor —
  // the hard band must stay a clearly distinct gesture (LSPressure.h). A
  // floor above CONF_PRESS_MAX_THRESHOLD leaves the live value untouched and
  // the hard band simply inert (the classifier's fail-safe).
  // 4.8.7 review: the heal must never fire from a FABRICATED value. On a
  // failed settings2 read the getter returns the compiled default (10.0)
  // without writing — but the old shape fed that default straight into the
  // floor comparison, so one transient LittleFS failure on a user whose
  // regular threshold is ≥ 10 hPa (menu levels 6-10: 10/15/22/32/45 hPa)
  // silently PERSISTED ST+1.0 over their stored hard threshold — a real,
  // permanent settings change with no wire trace (both response flags are
  // false here). Each read verdict is captured before the next read clobbers
  // the shared flag; a failed read keeps the compiled default for the
  // session only and persists nothing.
  float storedHardSip = getHardSipPressureThreshold(false, false);
  const bool hsReadOk = mem.isLastReadOk();
  float storedHardPuff = getHardPuffPressureThreshold(false, false);
  const bool hpReadOk = mem.isLastReadOk();
  float sipFloor = ps.getSipPressureThreshold() + CONF_PRESS_HARD_MARGIN_HPA;
  float puffFloor = ps.getPuffPressureThreshold() + CONF_PRESS_HARD_MARGIN_HPA;
  if (hsReadOk && storedHardSip < sipFloor) {
    setHardSipPressureThreshold(false, false, sipFloor);
  }
  if (hpReadOk && storedHardPuff < puffFloor) {
    setHardPuffPressureThreshold(false, false, puffFloor);
  }
  sapActionSize = sizeof(sapActionProperty) / sizeof(inputActionStruct);  // Size of total available sip and puff actions
  sapActionMaxTime = getActionMaxTime(sapActionSize, sapActionProperty);  // Maximum end action time
}


//***GET ACTION MAX TIME FUNCTION***//
// Function   : getActionMaxTime
//
// Description: This function finds the maximum end action time
//
// Parameters : actionSize : int : size of available actions
//              actionProperty : const inputActionStruct : array of all possible actions
//
// Return     : actionMaxTime : unsigned long : maximum end action time
//****************************************//
unsigned long getActionMaxTime(int actionSize, const inputActionStruct actionProperty[]) {
  unsigned long actionMaxTime = 0;
  // Loop over all possible outputs
  for (int actionIndex = 0; actionIndex < actionSize; actionIndex++) {
    if (actionMaxTime < actionProperty[actionIndex].inputActionEndTime) {
      actionMaxTime = actionProperty[actionIndex].inputActionEndTime;
    }
  }
  return actionMaxTime;
}

//***PRESSURE LOOP FUNCTION***//
// Function   : pressureLoop
//
// Description: This function handles pressure polling, sip and puff state evaluation.
//
// Parameters : void
//
// Return     : void
//****************************************//
void pressureLoop() {
  //if (USB_DEBUG) { Serial.println("USBDEBUG: pressureLoop()"); }
  ps.update();  // Request new pressure difference from sensor and push it to array

  // A fault that interrupted an ACTIVE hold settled the state machine to
  // idle without a RELEASED event — end the engaged drag/scroll latch here
  // (4.6.6: the latch otherwise strands the held mouse button and blocks
  // every later action dispatch until a hub-button press or a post-recovery
  // re-puff). Must run before evaluateOutputAction: getState() below now
  // reads the settled {NONE, WAITING}, which alone cannot release anything.
  // 4.9.1 (ownership gate): the cancel exists for a hold the PRESSURE input
  // owned — its RELEASED was never emitted. A hold owned by a hub button or
  // an external switch has its own release path; a mouthpiece-sensor fault
  // must not destroy a drag the user is actively steering with a button (the
  // direction is fail-safe — releasing — but it is still a wrong-ownership
  // teardown). -1 = no latch (defensive; nothing to protect).
  if (ps.takeHoldCancelPending()) {
    if (g_outputHoldInputClass == INPUT_CLASS_SAP || g_outputHoldInputClass == -1) {
      cancelSapOutputHold();
    }
  }

  //pressureValues = ps.getAllPressure();  // Read the pressure object (can be last value from array, average or other algorithms)

  // Get the last state change
  sapActionState = ps.getState();

  // Output action logic — INPUT_CLASS_SAP lets the restriction gates tell a
  // mouthpiece input from a button/switch one (roadmap item 11).
  evaluateOutputAction(sapActionState, sapActionMaxTime, sapActionSize, g_sapActionTable, INPUT_CLASS_SAP);
}

//***RELEASE OUTPUT FUNCTION***//
// Function   : releaseOutputAction
//
// Description: This function handles release of usbmouse hold actions.
//
// Parameters : void
//
// Return     : void
//****************************************//
void releaseOutputAction() {
  // Release left click if it's in drag mode and left mouse button is pressed.
  if (outputAction == CONF_ACTION_DRAG && (usbmouse.isPressed(MOUSE_LEFT) || btmouse.isPressed(MOUSE_LEFT))) {
    usbmouse.release(MOUSE_LEFT);
    btmouse.release(MOUSE_LEFT);
  }
  // Set new state of current output action
  outputAction = CONF_ACTION_NOTHING;
  canOutputAction = true;
  g_outputHoldInputClass = -1;
}

//***CANCEL OUTPUT HOLD FUNCTION***//
// Function   : cancelSapOutputHold
//
// Description: Ends an engaged DRAG/SCROLL hold WITHOUT emitting an input
//              event. This is the exact bookkeeping of evaluateOutputAction's
//              hold-release branch (setLedDefault + releaseOutputAction),
//              minus the action dispatch — for holds that ended without a
//              RELEASED event: the sensor-fault path settles the pressure
//              state machine to idle while a hold is ACTIVE (no phantom
//              action may fire from a fault), so the latch would otherwise
//              strand the held mouse button and block every later action
//              (the release match keys on RELEASED, which the fault path
//              never produces). The scroll-poll swap self-corrects on the
//              next tick once outputAction is NOTHING.
//
// Parameters : void
//
// Return     : void
//****************************************//
void cancelSapOutputHold() {
  setLedDefault();        // Set default led feedback (the hold's window color was showing)
  releaseOutputAction();  // Release the drag button / clear the hold latch
}

//***EVALUATE OUTPUT ACTION FUNCTION***//
// Function   : evaluateOutputAction
//
// Description: This function evaluates and performs output action
//
// Parameters : actionState : inputStateStruct : Current input state
//              actionMaxEndTime : unsigned long : maximum end action time
//              actionSize : int : size of available actions
//              actionProperty : const inputActionStruct : array of all possible actions
//              inputClass : int : INPUT_CLASS_SAP / _BUTTON / _SWITCH — which
//                          physical input the state came from (restriction
//                          gates, roadmap item 11)
//
// Return     : void
//****************************************//
void evaluateOutputAction(inputStateStruct actionState, unsigned long actionMaxEndTime, int actionSize, const inputActionStruct actionProperty[], int inputClass) {
  g_menuInputHoldMs = 0;  // fresh per pass — see the global's comment
  // Sip & puff disabled (SD): no new sap action may fire. The hold-release
  // and timer bookkeeping below still runs, so a drag/scroll engaged before
  // the restriction was applied still ends cleanly instead of sticking.
  bool canEvaluateAction = (inputClass != INPUT_CLASS_SAP || !g_sapDisabled);

  // Output action logic
  int tempActionIndex = 0;

  // Handle input action when it's in hold state (scroll mode or drag mode)
  if ((actionState.secondaryState == INPUT_SEC_STATE_RELEASED)
      && (outputAction == CONF_ACTION_SCROLL || outputAction == CONF_ACTION_DRAG)
      // Preserve the legacy "any input cancels a hold" affordance, except a
      // disabled sip/puff must truly have no effect on a button/switch-owned
      // hold. A sip hold already active when SD is enabled may still clean
      // itself up through its owner-class release.
      && (inputClass == g_outputHoldInputClass || !(inputClass == INPUT_CLASS_SAP && g_sapDisabled))) {
    setLedDefault();  // Set default led feedback
    // Set new state of current output action
    releaseOutputAction();
    canEvaluateAction = false;
  }  // Detected input release after defined time limits.
  else if (actionState.secondaryState == INPUT_SEC_STATE_RELEASED
           && (actionState.elapsedTime > effectiveWindowMs(actionMaxEndTime)
               || actionState.elapsedTime > effectiveWindowMs(CONF_INPUT_WINDOW_MAX_DEFAULT_MS))) {
    // Set Led color to default
    // 4.9.9 review round 3: the second bound covers the dead zone upstream
    // #58 opened. sapActionMaxTime is the whole SAP table's max — the hard
    // rows' 60000 — so the old single bound delayed this reset from the
    // regular windows' ceiling (8 s, mapped) to 60 s: a regular hold
    // released between the last regular window and a minute matched no row
    // (no action, no LED there) and never reached this reset either, so the
    // STARTED hold paint (solid color, or the LM=3 window fill — a static
    // paint with no idle repaint anywhere) stayed up until the user's next
    // gesture. For the button/switch tables this bound equals
    // actionMaxEndTime (their rows end at the same 8000), so their behavior
    // is unchanged; for SAP the mapped regular ceiling is the honest
    // "nothing more will fire" point — a hard hold that already fired its
    // row repaints the action LED right after this reset in the row loop
    // below, exactly as its release always has.
    setLedDefault();
  }

  // Code to switch between joystick controlled scroll and joystick controlled cursor movement
  // 4.5.7 review: the swap is gated on !g_safeModeEnabled — the unconditional
  // form re-enabled the JOYSTICK poll timer toggleSafeMode had deliberately
  // shut down on EVERY sensorful safe boot (the first input tick's
  // outputAction == NOTHING takes the enable-joystick branch), restoring
  // exactly the 20 ms I2C-against-degraded-hardware traffic safe mode
  // exists to avoid. Safe-mode action columns never resolve to
  // SCROLL/DRAG, so there is nothing for the swap to do there.
  // 4.6.6: also gated on joystick debug mode. setDebugState(DM=1) disables
  // the joystick and scroll polls so the debug stream is the only consumer,
  // but this swap (inputLoop runs it every 20 ms with outputAction ==
  // NOTHING) re-enabled the joystick poll within one tick — the debug
  // contract silently didn't hold and the sensor was double-polled. The
  // debug-mode poll state is setDebugState's business; DM=0/DM=2..5 restore
  // it there.
  if(g_joystickSensorConnected && !g_safeModeEnabled && g_debugMode != CONF_DEBUG_MODE_JOYSTICK){
    if (outputAction == CONF_ACTION_SCROLL) {
      pollTimer.enable(pollTimerId[CONF_TIMER_SCROLL]);
      pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);
    } else if (outputAction != CONF_ACTION_SCROLL) {
      pollTimer.enable(pollTimerId[CONF_TIMER_JOYSTICK]);
      pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);
    }
  }

  // Loop over all possible outputs
  for (int actionIndex = 0; actionIndex < actionSize && canEvaluateAction && canOutputAction; actionIndex++) {
    // Detected input release in defined time limits. Perform output action based on action index
    if (actionState.mainState == actionProperty[actionIndex].inputActionState
        && actionState.secondaryState == INPUT_SEC_STATE_RELEASED
        && actionState.elapsedTime >= effectiveWindowMs(actionProperty[actionIndex].inputActionStartTime)
        && actionState.elapsedTime < effectiveWindowMs(actionProperty[actionIndex].inputActionEndTime)) {
      
      // Get action index
      if (screen.isMenuActive()) {
        tempActionIndex = actionProperty[actionIndex].menuOutputActionNumber;
      } else {
        switch (g_operatingMode) {
          case CONF_OPERATING_MODE_MOUSE:
            tempActionIndex = actionProperty[actionIndex].mouseOutputActionNumber;
            break;
          case CONF_OPERATING_MODE_GAMEPAD:
            tempActionIndex = actionProperty[actionIndex].gamepadOutputActionNumber;
            break;
          case CONF_OPERATING_MODE_SAFE:
            tempActionIndex = actionProperty[actionIndex].safeModeOutputActionNumber;
            break;
        }
      }

      // Restriction gates (roadmap item 11): a forbidden action resolves to
      // NOTHING here — no LED feedback, no output, no trace of the input.
      tempActionIndex = applyInputRestrictions(tempActionIndex, inputClass);

      // Input-state LED mode (LM=3, roadmap item 16 / upstream #43): the
      // window the hold was in already showed on the LEDs while it was
      // held; the release restores the default LEDs instead of blinking
      // the action — the window was the message. The action itself still
      // fires; a gated (restricted) input shows nothing at all.
      bool inputStateLeds = (tempActionIndex != CONF_ACTION_NOTHING && g_lightMode == CONF_LIGHT_MODE_STATE);

      if (inputStateLeds) {
        setLedDefault();
      } else {
        // Set Led color to default
        //setLedDefault();
        // Set Led state
        setLedState(ledActionProperty[tempActionIndex].ledEndAction,
                    ledActionProperty[tempActionIndex].ledEndColor,
                    ledActionProperty[tempActionIndex].ledNumber,
                    CONF_INPUT_LED_BLINK,
                    CONF_INPUT_LED_DELAY,
                    led.getLedBrightness());
      }
      outputAction = tempActionIndex;

      // Engagement cue for the two hold modes (roadmap item 16, upstream
      // #61): one short tone when scroll or drag takes, so the mode change
      // is audible, not just visible on the LEDs.
      if (tempActionIndex == CONF_ACTION_SCROLL || tempActionIndex == CONF_ACTION_DRAG) {
        buzzer.modeEngageTone(tempActionIndex == CONF_ACTION_SCROLL);
      }

      // Perform led action
      if (!inputStateLeds) {
        performLedAction(ledCurrentState);
      }

      // Perform output action — but NEVER for a restriction-gated NOTHING
      // (4.5.7 review): performOutputAction's gamepad NOTHING case releases
      // all buttons, an observable output that violates the gate's "no
      // output, no trace" contract (bench-visible as a "Released all"
      // burst and a killed in-flight pulse on every LK/MA/SD-refused
      // press). A genuine compiled NOTHING cell also skips: "nothing"
      // means nothing, and the actionTimer's scheduled releaseAll already
      // cleans up gamepad pulses.
      if (tempActionIndex != CONF_ACTION_NOTHING) {
        g_menuInputHoldMs = actionState.elapsedTime;  // the hold-to-confirm gate reads this (see selectMenuItem)
        if (tempActionIndex == CONF_ACTION_SCROLL || tempActionIndex == CONF_ACTION_DRAG) {
          g_outputHoldInputClass = inputClass;
        }
        // Physical input actions travel over HID and historically left no
        // serial witness. Emit one low-rate MANUAL event per resolved release:
        // input class, raw input state, output action, measured hold ms.
        // This makes spontaneous clicks diagnosable without a 10 Hz stream.
        int inputActionEvent[4] = { inputClass,
                                    actionState.mainState,
                                    tempActionIndex,
                                    (int)actionState.elapsedTime };
        printResponseIntArray(true, false, true, 0, "IA,0", true, "", 4, ',', inputActionEvent);
        performOutputAction(tempActionIndex);
      }

      break;
    }  // Detected input start in defined time limits. Perform led action based on action index
    else if (actionState.mainState == actionProperty[actionIndex].inputActionState
             && actionState.secondaryState == INPUT_SEC_STATE_STARTED
             && actionState.elapsedTime >= effectiveWindowMs(actionProperty[actionIndex].inputActionStartTime)
             && actionState.elapsedTime < effectiveWindowMs(actionProperty[actionIndex].inputActionEndTime)) {
      // Get action index
      if (screen.isMenuActive()) {
        tempActionIndex = actionProperty[actionIndex].menuOutputActionNumber;
      } else {
        switch (g_operatingMode) {
          case CONF_OPERATING_MODE_MOUSE:
            tempActionIndex = actionProperty[actionIndex].mouseOutputActionNumber;
            break;
          case CONF_OPERATING_MODE_GAMEPAD:
            tempActionIndex = actionProperty[actionIndex].gamepadOutputActionNumber;
            break;
          case CONF_OPERATING_MODE_SAFE:
            tempActionIndex = actionProperty[actionIndex].safeModeOutputActionNumber;
            break;
        }
      }

      // Restriction gates (roadmap item 11): the started-phase LED cue is
      // suppressed too — a forbidden input must not light anything up.
      tempActionIndex = applyInputRestrictions(tempActionIndex, inputClass);

      // Input-state LED mode (LM=3, roadmap item 16 / upstream #43): the
      // LEDs show the window the hold is in — a DUAL channel (bench design
      // 2026-10-19): the three face LEDs FILL 1 -> 2 -> 3 as the hold
      // crosses each window boundary (they are physically single-color, so
      // a count is the one message they can carry), and the micro LED next
      // to the USB-C port shows the window's COLOR. Actions are not
      // one-to-one with inputs (#43), so the window is the honest signal,
      // and the fill previews what a release will do without memorizing
      // any mapping. Re-evaluated every tick, so the LEDs step up through
      // the windows as the hold crosses each boundary; a gated (restricted)
      // input still shows nothing at all.
      if (tempActionIndex != CONF_ACTION_NOTHING && g_lightMode == CONF_LIGHT_MODE_STATE) {
        unsigned long holdMs = actionState.elapsedTime;
        int stateColor;
        int windowCount;
        if (holdMs < effectiveWindowMs(CONF_INPUT_WINDOW_SHORT_DEFAULT_MS)) {
          stateColor = CONF_INPUT_STATE_LED_SHORT_COLOR;  // green
          windowCount = 1;
        } else if (holdMs < effectiveWindowMs(CONF_INPUT_WINDOW_LONG_DEFAULT_MS)) {
          stateColor = CONF_INPUT_STATE_LED_LONG_COLOR;  // yellow
          windowCount = 2;
        } else {
          stateColor = CONF_INPUT_STATE_LED_MAX_COLOR;  // red
          windowCount = 3;
        }
        led.setInputStateLeds(windowCount, stateColor, led.getLedBrightness());
        break;
      }

      // Set Led color to default
      //setLedDefault();
      // Set Led state
      setLedState(LED_ACTION_ON,
                  ledActionProperty[tempActionIndex].ledStartColor,
                  ledActionProperty[tempActionIndex].ledNumber,
                  0,                     // number of blinks
                  0,                     // blink time
                  led.getLedBrightness());  // brightness
      // Perform led action
      performLedAction(ledCurrentState);

      break;
    }
  }
}

//***PERFORM OUTPUT ACTION FUNCTION***//
// Function   : performOutputAction
//
// Description: This function performs output action
//
// Parameters : action : int : action index number
//
// Return     : void
//****************************************//
void performOutputAction(int action) {
  if (action < CONF_ACTION_NOTHING || action > CONF_ACTION_FACTORY_RESET) return;
  switch (action) {
    case CONF_ACTION_NOTHING:
      {
        // A matched NOTHING cell in gamepad mode still clears any in-flight
        // button pulse (the actionTimer auto-release below also covers it;
        // this is the immediate path). The debug print is gone (4.5.7
        // review): it fired from loop context on the wire for every
        // matched nothing-cell — and for every LK/MA/SD-gated input, which
        // is why the restriction gates now skip performOutputAction
        // entirely for gated actions (see evaluateOutputAction).
        if (g_operatingMode == CONF_OPERATING_MODE_GAMEPAD) {
          gamepadButtonReleaseAll();
        }
        break;
      }
    case CONF_ACTION_LEFT_CLICK:
      {
        cursorLeftClick();
        break;
      }
    case CONF_ACTION_RIGHT_CLICK:
      {
        cursorRightClick();
        break;
      }
    case CONF_ACTION_DRAG:
      {
        cursorDrag();
        break;
      }
    case CONF_ACTION_SCROLL:
      {
        cursorScroll();  // Enter Scroll mode
        break;
      }
    case CONF_ACTION_CURSOR_CENTER:
      {
        screen.centerResetPage();  // Perform cursor center
        //setJoystickInitialization(true,false);
        break;
      }
    case CONF_ACTION_CURSOR_CALIBRATION:
      {
        setJoystickCalibration(true, false);
        break;
      }
    case CONF_ACTION_MIDDLE_CLICK:
      {
        cursorMiddleClick();  // Perform cursor middle click
        break;
      }
    case CONF_ACTION_DEC_SPEED:
      {
        decreaseCursorSpeed(true, false);  // Decrease cursor speed
        break;
      }
    case CONF_ACTION_INC_SPEED:
      {
        increaseCursorSpeed(true, false);  // Increase cursor speed
        break;
      }
    case CONF_ACTION_CHANGE_MODE:
      {
        // Change communication mode
        toggleCommunicationMode(true, false);
        break;
      }
    case CONF_ACTION_START_MENU:
      {
        screen.activateMenu();  // Activate Menu
        break;
      }
    case CONF_ACTION_STOP_MENU:
      {
        screen.closeMenu();  // Deactivate Menu (freeze-aware: see LSScreen::closeMenu)
        break;
      }
    case CONF_ACTION_B1_PRESS:
      {
        gamepadButtonPress(1);
        break;
      }
    case CONF_ACTION_B2_PRESS:
      {
        gamepadButtonPress(2);
        break;
      }
    case CONF_ACTION_B3_PRESS:
      {
        gamepadButtonPress(3);
        break;
      }
    case CONF_ACTION_B4_PRESS:
      {
        gamepadButtonPress(4);
        break;
      }
    case CONF_ACTION_B5_PRESS:
      {
        gamepadButtonPress(5);
        break;
      }
    case CONF_ACTION_B6_PRESS:
      {
        gamepadButtonPress(6);
        break;
      }
    case CONF_ACTION_B7_PRESS:
      {
        gamepadButtonPress(7);
        break;
      }
    case CONF_ACTION_B8_PRESS:
      {
        gamepadButtonPress(8);
        break;
      }
    case CONF_ACTION_NEXT_MENU_ITEM:
      {
        screen.nextMenuItem();  // Move to next menu item
        break;
      }
    case CONF_ACTION_SELECT_MENU_ITEM:
      {
        screen.selectMenuItem();  // Move to next menu item
        break;
      }
    case CONF_ACTION_RESET:
      {
        softwareReset();
        break;
      }
    case CONF_ACTION_FACTORY_RESET:
      {
        doFactoryReset(true, false);  // Perform Factory Reset
        break;
      }
  }
  if (g_operatingMode == CONF_OPERATING_MODE_GAMEPAD) {
    // B1-B8 arm their own release timers in gamepadButtonPress(). Do not
    // schedule a shared release-all here: an older pulse timeout otherwise
    // cuts a newer button press short, and two switches cannot overlap.
    outputAction = CONF_ACTION_NOTHING;
  }

  // Hold-mode bookkeeping (4.5.7 review hardening): the mouse's drag/scroll
  // hold tracker only arms OUTSIDE gamepad mode — in gamepad mode the branch
  // above has already clobbered outputAction to NOTHING, so arming the
  // canOutputAction=false latch here could NEVER be released again (the
  // release match keys on outputAction == DRAG/SCROLL): one rogue gamepad
  // DRAG/SCROLL mapping (now allowlist-blocked twice over) used to wedge
  // every input on the device until a reboot or a serial center flow.
  if ((action == CONF_ACTION_DRAG || action == CONF_ACTION_SCROLL) && g_operatingMode != CONF_OPERATING_MODE_GAMEPAD) {
    canOutputAction = false;
  } else {
    outputAction = CONF_ACTION_NOTHING;
    canOutputAction = true;
  }
}


//*********************************//
// Mouse Functions
//*********************************//

//***CURSOR LEFT CLICK FUNCTION***//
// Function   : cursorLeftClick
//
// Description: This function performs cursor left click action.
//
// Parameters : void
//
// Return     : void
//****************************************//
void cursorLeftClick(void) {
  if (g_comMode == CONF_COM_MODE_USB) {
    usbmouse.click(MOUSE_LEFT);  // USB Mouse left click
  } else if (g_comMode == CONF_COM_MODE_BLE) {
    btmouse.click(MOUSE_LEFT);  // Bluetooth mouse left click
  }
}

//***CURSOR RIGHT CLICK FUNCTION***//
// Function   : cursorRightClick
//
// Description: This function performs cursor right click action.
//
// Parameters : void
//
// Return     : void
//****************************************//
void cursorRightClick(void) {
  if (g_comMode == CONF_COM_MODE_USB) {
    usbmouse.click(MOUSE_RIGHT);  // USB Mouse right click
  } else if (g_comMode == CONF_COM_MODE_BLE) {
    btmouse.click(MOUSE_RIGHT);  // Bluetooth mouse right click
  }
}

//***CURSOR MIDDLE CLICK FUNCTION***//
// Function   : cursorMiddleClick
//
// Description: This function performs cursor middle click action.
//
// Parameters : void
//
// Return     : void
//****************************************//
void cursorMiddleClick(void) {
  if (g_comMode == CONF_COM_MODE_USB) {
    usbmouse.click(MOUSE_MIDDLE);  // USB Mouse Middle click
  } else if (g_comMode == CONF_COM_MODE_BLE) {
    btmouse.click(MOUSE_MIDDLE);  // Bluetooth mouse middle click
  }
}

//***DRAG FUNCTION***//
// Function   : cursorDrag
//
// Description: This function performs cursor drag action.
//
// Parameters : void
//
// Return     : void
//********************//
void cursorDrag(void) {
  if (g_comMode == CONF_COM_MODE_USB) {
    usbmouse.press(MOUSE_LEFT);  // USB Mouse press left
  } else if (g_comMode == CONF_COM_MODE_BLE) {
    btmouse.press(MOUSE_LEFT);  // Bluetooth Mouse press left
  }
}
//***CURSOR SCROLL FUNCTION***//
// Function   : cursorScroll
//
// Description: This function is an operating mode that enables scrolling action.
//
// Parameters : void
//
// Return     : void
//****************************************//
void cursorScroll(void) {
  outputAction = CONF_ACTION_SCROLL;
  g_scrollNumRuns = 0;
}


//*********************************//
// Gamepad Functions
//*********************************//

//***GAMEPAD BUTTON PRESS FUNCTION***//
// Function   : gamepadButtonPress
//
// Description: This function performs button press action.
//
// Parameters : int : buttonNumber
//
// Return     : void
//****************************************//
void gamepadButtonPress(int buttonNumber) {
  if (buttonNumber > 0 && buttonNumber <= 8) {
    const int buttonIndex = buttonNumber - 1;
    // Re-pressing the same logical button extends its pulse. Other button
    // timers remain independent, so simultaneous assistive-switch inputs can
    // produce simultaneous gamepad buttons without one timeout clearing all.
    if (actionTimerId[buttonIndex] >= 0) {
      actionTimer.deleteTimer(actionTimerId[buttonIndex]);
      actionTimerId[buttonIndex] = -1;
    }
    gamepad.press(buttonIndex);
    gamepad.send();  // Gamepad button press
    actionTimerId[buttonIndex] = actionTimer.setTimeout(CONF_BUTTON_PRESS_DELAY, gamepadButtonRelease, (int*)buttonNumber);
    if (actionTimerId[buttonIndex] < 0) {
      // A refused release timer must fail safe without disturbing another
      // button whose independent pulse is still in flight.
      gamepad.release(buttonIndex);
      gamepad.send();
    }
  }
}

// (gamepadButtonClick REMOVED — 4.8.1 review: dead code, no callers; it
// only forwarded to gamepadButtonPress, a second name for the same entry
// point waiting to drift.)

//***GAMEPAD BUTTON RELEASE FUNCTION***//
// Function   : gamepadButtonRelease
//
// Description: This function performs button release action.
//
// Parameters : int* : args
//
// Return     : void
//****************************************//
void gamepadButtonRelease(int* args) {
  int buttonNumber = (int)args;
  if (buttonNumber > 0 && buttonNumber <= 8) {
    const int buttonIndex = buttonNumber - 1;
    gamepad.release(buttonIndex);
    gamepad.send();
    actionTimerId[buttonIndex] = -1;
  }
}


//***GAMEPAD BUTTON RELEASE ALL FUNCTION***//
// Function   : gamepadButtonReleaseAll
//
// Description: This function performs button release action.
//
// Parameters : void
//
// Return     : void
//****************************************//
void gamepadButtonReleaseAll() {
  gamepad.releaseAll();  // Release all gamepad buttons
  gamepad.send();
}



//*********************************//
// Joystick Functions
//*********************************//

//***INITIALIZE JOYSTICK FUNCTION***//
// Function   : initJoystick
//
// Description: This function initializes joystick as input.
//
// Parameters : void
//
// Return     : void
//****************************************//
void initJoystick() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initJoystick()"); }
  if (!js.begin()) {                                                    // Begin joystick and honor the driver's real init verdict
    g_joystickSensorConnected = false;
    return;
  }
  js.setMagnetDirection(JOY_DIRECTION_DEFAULT, JOY_DIRECTION_INVERSE);  // Set x and y magnet direction
  getJoystickInnerDeadzone(true, false);                               // Get joystick deadzone stored in flash memory
  getJoystickOuterDeadzone(true, false);                                     // Get joystick deadzone stored in flash memory
  getCursorSpeed(true, false);                                          // Get joystick cursor speed stored in flash memory
  g_scrollLevel = getScrollLevel(true, false);                            // Get scroll level stored in flash memory
  setJoystickInitialization(true, false);                               // Perform joystick center initialization
  getJoystickCalibration(true, false);                                  // Get joystick calibration points stored in flash memory
}

//***PERFORM JOYSTICK CENTER FUNCTION***//
// Function   : performJoystickCenter
//
// Description: This function performs joystick center point initialization.
//
// Parameters : * args : int : pointer of step number
//
// Return     : void
//****************************************//
void performJoystickCenter(int* args) {
  // The timer payload carries this chain's initiator alongside the step
  // number (CONF_CENTER_INIT_API_FLAG, 4.5.4): SUCCESS only for a center
  // the HOST requested over the serial API (IN,1:1); MANUAL for every
  // device-initiated center (the boot auto-center, the Hub-menu Center
  // Reset, the calibration's internal step 5) — an unsolicited SUCCESS on
  // the wire is a lie a command waiter can false-match (the bench caught a
  // boot straggler landing between the VN request and its response); MANUAL
  // carries the same data and matches no waiter. Riding the payload
  // instead of the 4.5.2 global means each in-flight chain owns its own
  // initiator: two overlapping centers (an app IN,1:1 racing the boot
  // auto-center) each ack with their own correct prefix instead of sharing
  // one flag that whichever-fires-first consumes.
  bool centerInitFromApi = ((int)args & CONF_CENTER_INIT_API_FLAG) != 0;
  int stepNumber = (int)args & ~CONF_CENTER_INIT_API_FLAG;
  if (USB_DEBUG) { Serial.print("USBDEBUG: performJoystickCenter("); Serial.print(stepNumber); Serial.println(")"); }

  g_resetCenterComplete = false;  // Reset the global flag

  

  // Duration of the center point readings (500 milliseconds)
  unsigned long readingDuration = CONF_JOY_INIT_READING_DELAY * CONF_JOY_INIT_READING_NUMBER;

  // (500 + 150*3) - time until start of current reading.
  unsigned long currentReadingStart = CONF_JOY_INIT_START_DELAY + (CONF_JOY_INIT_STEP_BLINK_DELAY * ((CONF_JOY_INIT_STEP_BLINK * 2) + 1));

  // Time until start of next step. (milliseconds: readingDelay x readings)
  unsigned long nextStepStart = currentReadingStart + readingDuration;

  pointFloatType centerPoint;

  if (stepNumber == 0)  // STEP 0: Joystick Compensation Center Point
  {
    if (ledActionEnabled) {
      setLedState(LED_ACTION_BLINK, CONF_JOY_INIT_STEP_BLINK_COLOR, CONF_JOY_INIT_LED_NUMBER, CONF_JOY_INIT_STEP_BLINK, CONF_JOY_INIT_STEP_BLINK_DELAY, led.getLedBrightness());
      performLedAction(ledCurrentState);  // LED Feedback to show start of performJoystickCalibrationStep
    }
    // Start timer to get 5 reading every 100 ms. A refused registration
    // (pool full — the failure the 4.5.1 audit made loud) must not leave the
    // cursor output dead: without the reading timer the completion timeout
    // below would still fire and average an empty center buffer, so bail
    // out honestly instead — restore the output-enabled state and keep the
    // previous center (4.5.7 review; unreachable with 16 slots, but the
    // guard is one check).
    // Each center attempt owns a fresh sample window. Reusing the circular
    // buffer's old length let a failed attempt with only 1-4 new readings
    // appear complete and average stale samples from the previous center.
    js.resetInputCenterBuffer();
    calibrationTimerId[1] = calibrationTimer.setTimer(CONF_JOY_INIT_READING_DELAY, currentReadingStart, CONF_JOY_INIT_READING_NUMBER, performJoystickCenterStep, (int*)args);
    if (calibrationTimerId[1] < 0) {
      static const char centerReadError[] = "ERROR: center-reset reading timer refused -- keeping previous center";
      serialTxEnqueueLine(centerReadError, sizeof(centerReadError) - 1);
      setLedDefault();
      canOutputAction = true;
      g_resetCenterComplete = true;
      g_centerRunning = false;
      if (screen.showCenterResetComplete) screen.centerResetFailedPage();
      printResponseInt(true, centerInitFromApi, false, 3, "IN,1", true, 1);
      // 4.9.9 review round 3: the enclosing chain's initiator (persisted at
      // acceptance), not the center sub-step's own false — a host CA,1 must
      // receive its FAIL,3 even when the failure fires inside the center.
      if (g_calibrationRunning) abortJoystickCalibration(g_calibrationFromApi, "center reading timer refused");
      if (g_startupCenterReset) {
        g_startupCenterReset = false;
        readyToUse();
      }
      return;
    }
    // Carry the initiator into the completion step
    int payload = (stepNumber + 1) | (centerInitFromApi ? CONF_CENTER_INIT_API_FLAG : 0);
    // Start exit step
    calibrationTimerId[0] = calibrationTimer.setTimeout(nextStepStart, performJoystickCenter, (int*)payload);
    if (calibrationTimerId[0] < 0) {
      calibrationTimer.deleteTimer(calibrationTimerId[1]);
      static const char centerCompletionError[] = "ERROR: center-reset completion timer refused -- keeping previous center";
      serialTxEnqueueLine(centerCompletionError, sizeof(centerCompletionError) - 1);
      setLedDefault();
      canOutputAction = true;
      g_resetCenterComplete = true;
      g_centerRunning = false;
      if (screen.showCenterResetComplete) screen.centerResetFailedPage();
      printResponseInt(true, centerInitFromApi, false, 3, "IN,1", true, 1);
      if (g_calibrationRunning) abortJoystickCalibration(g_calibrationFromApi, "center completion timer refused");  // 4.9.9 round 3: the chain's persisted initiator, not the sub-step's false
      if (g_startupCenterReset) {
        g_startupCenterReset = false;
        readyToUse();
      }
    }
  } else {
    bool centerUpdated = js.evaluateInputCenter();  // Requires five valid samples from THIS attempt
    if (centerUpdated) {
      js.setMinimumRadius();            // Update minimum radius of operation
      js.reprocessLastReading();        // Apply the new center even while the raw field is stationary
    }
    centerPoint = js.getInputCenter();  // Get the new center for API output
    printResponseFloatPoint(true, centerInitFromApi, centerUpdated, centerUpdated ? 0 : 3, "IN,1", true, centerPoint);
    // No deleteTimer here (4.5.4): the fired RUN_ONCE timeout already
    // deleted itself, and the old blind deleteTimer(0) could kill a LIVE
    // timer — slot 0 is the lowest free slot handed to the next
    // registration, which in an overlapping-centers race is exactly the
    // OTHER flow's pending timeout (a host IN,1:1 arriving during the
    // boot auto-center's reading phase took slot 0 and was silently
    // eaten). Overlapping chains now both complete, each with their own
    // correct ack.
    setLedDefault();                  // Set default led feedback
    // A standalone center is done here, but the full calibration's internal
    // step-5 center is only a sub-step. Keep all output locked until the
    // enclosing flow reaches step 6; the old unconditional true opened a
    // ~3.5 s window where Hub/switch actions could fire mid-calibration.
    canOutputAction = !g_calibrationRunning;
    g_resetCenterComplete = true;
    g_centerRunning = false;

    if (!centerUpdated && g_calibrationRunning) {
      // 4.9.9 review round 3: the enclosing chain's initiator (persisted at
      // acceptance), not the center sub-step's own false — this is the most
      // reachable internal-center abort (any flaky-bus class that costs one
      // of the five valid samples) and a host CA,1 waiter must resolve
      // FAIL,3, not time out against an unsolicited MANUAL line.
      abortJoystickCalibration(g_calibrationFromApi, "center did not collect five valid samples");
      return;
    }

    if (g_startupCenterReset) {  // Checks variable to only play sound and show splash screen on startup
      readyToUse();              // TODO JDMc 2025-Jan-24 Probably want sound to play after every calibration to indicate joystick is ready to be used again.
    }
    if (screen.showCenterResetComplete) {  // Checks variable so center reset result only shows if accessed from menu, not on startup or during full calibration
      if (centerUpdated) screen.centerResetCompletePage();
      else screen.centerResetFailedPage();
    }
    g_startupCenterReset = false;
  }
}

//***PERFORM JOYSTICK CENTER STEP FUNCTION***//
// Function   : performJoystickCenterStep
//
// Description: This function performs the actual joystick center point initialization step.
//
// Parameters : * args : int : pointer of step number
//
// Return     : void
//****************************************//
void performJoystickCenterStep(int* args) {

  // Turn on and set the second led to orange to indicate start of the process
  if (calibrationTimer.getNumRuns(calibrationTimerId[1]) == 1 && ledActionEnabled) {  // Turn LED's ON when timer is running for first time
    setLedState(LED_ACTION_ON, CONF_JOY_INIT_LED_COLOR, CONF_JOY_INIT_LED_NUMBER, 0, 0, led.getLedBrightness());
    performLedAction(ledCurrentState);
  }
  // Push new center values to be evaluated at the end of the process
  js.updateInputCenterBuffer();

  // Turn off the second led to orange to indicate end of the process
  if (calibrationTimer.getNumRuns(calibrationTimerId[1]) == CONF_JOY_INIT_READING_NUMBER && ledActionEnabled) {  // Turn LED's OFF when timer is running for last time
    setLedState(LED_ACTION_OFF, LED_CLR_NONE, CONF_JOY_INIT_LED_NUMBER, 0, 0, led.getLedBrightness());
    performLedAction(ledCurrentState);
  }
}

// Restore a usable device if any full-calibration timer registration is
// refused. The calibration pool is deliberately roomy, but exhaustion must
// degrade to the last persisted calibration rather than leaving polling and
// all output disabled for the rest of the boot.
void abortJoystickCalibration(bool calibFromApi, const char* reason) {
  String calibrationError = "ERROR: calibration aborted: ";
  calibrationError += reason;
  serialTxEnqueueLine(calibrationError);
  g_calibrationRunning = false;
  g_calibrationFromApi = false;  // 4.9.9 round 3: cleared AFTER the ack below consumed the caller's copy of it
  g_calibrationCenterStep = false;

  // A corner may have been zeroed before the refusal. Reload all persisted
  // corners now that the in-flight read gate is down.
  getJoystickCalibration(false, false);

  pollTimer.enable(pollTimerId[CONF_TIMER_INPUT]);
  if (!g_safeModeEnabled) {
    screen.enableTimeout();
    // 4.9.9 review round 4: the debug poll comes back (step 0 paused it for
    // the flow — see performJoystickCalibrationStep). Safe mode never
    // reaches this branch's restore, matching its deliberate shutdown.
    pollTimer.enable(pollTimerId[CONF_TIMER_DEBUG]);
    // Restore the swap with the same debug gate the swap itself uses (the
    // 4.6.6 DM=1 contract): a DM=1 debug stream owns the joystick poll, so
    // the calibration must not silently re-enable it alongside the debug
    // poll (the double-polled sensor + surprise cursor output class).
    if (outputAction == CONF_ACTION_SCROLL && g_debugMode != CONF_DEBUG_MODE_JOYSTICK) {
      pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);
      pollTimer.enable(pollTimerId[CONF_TIMER_SCROLL]);
    } else if (g_debugMode != CONF_DEBUG_MODE_JOYSTICK) {
      pollTimer.enable(pollTimerId[CONF_TIMER_JOYSTICK]);
      pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);
    }
    pollTimer.enable(pollTimerId[CONF_TIMER_PRESSURE]);
  }
  screen.calibrationAbortedPage();
  setLedDefault();
  if (!g_centerRunning) {
    canOutputAction = true;
    g_resetCenterComplete = true;
  }
  printResponseInt(true, calibFromApi, false, 3, "CA,1", true, 1);
}

//***PERFORM JOYSTICK CALIBRATION FUNCTION***//
// Function   : performJoystickCalibration
//
// Description: This function performs joystick maximum point calibration in a recursive fashion.
//
// Parameters : * args : int : pointer of step number
//
// Return     : void
//****************************************//
void performJoystickCalibration(int* args) {
  // A failed timer/center step may leave already-scheduled callbacks in the
  // pool. abortJoystickCalibration drops the run gate; stale continuations
  // must become no-ops rather than reviving a failed flow and announcing
  // success later.
  if (!g_calibrationRunning) return;
  g_resetCenterComplete = false;
  g_calibrationError = false;
  // The initiator rides the chain's payload (CONF_CALIB_API_FLAG, 4.5.4
  // audit follow-up): the per-corner CA,n lines print SUCCESS only for a
  // calibration the HOST requested over the serial API (CA,1:1); a
  // Hub-menu-initiated run prints MANUAL with the same data — the 4.5.2
  // initiator contract (an unsolicited SUCCESS on the wire can falsely
  // resolve a pending command waiter).
  bool calibFromApi = ((int)args & CONF_CALIB_API_FLAG) != 0;
  int stepNumber = (int)args & ~CONF_CALIB_API_FLAG;

  // Duration of the max corner reading ( 2 seconds )
  unsigned long readingDuration = CONF_JOY_CALIB_READING_DELAY * CONF_JOY_CALIB_READING_NUMBER;

  // Time until start of current reading
  unsigned long currentReadingStart = CONF_JOY_CALIB_STEP_DELAY + (CONF_JOY_CALIB_STEP_BLINK_DELAY * ((CONF_JOY_CALIB_STEP_BLINK * 2) + 1));

  // Time until start of next step (milliseconds: currentReadingStart + readingDuration + CONF_JOY_CALIB_START_DELAY)
  unsigned long nextStepStart = currentReadingStart + readingDuration + CONF_JOY_CALIB_START_DELAY;  // Time until start of next step (ms)

  if (stepNumber == 0) {                     // STEP 0: Calibration started
    // (g_calibrationRunning was set at chain acceptance — see setJoystickCalibration)
    pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);  // Temporarily disable joystick data polling timer
    pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);    // 4.5.7 review: scroll mode is a latch that survives release — without this, a scroll-latched device kept running joystickLoop through the scroll tick for the whole calibration (sensor I2C traffic during the shutdown, and live scroll events after the step-5 center re-enabled output). Step 6 already re-enables it (normal boots only).
    // 4.9.9 review round 4 (the symmetric direction of the DM,1 mid-flow
    // refusal): a DM=1..5 debug stream accepted BEFORE the flow is a second
    // live sensor consumer — debugLoop's 100 ms js.update() (DM=1) or
    // pressure/button samplers run straight through the corner/center
    // reading windows, the exact double-consumer class the flow-owns-the-
    // sensor doctrine closes. The flow pauses the debug poll for its
    // duration; step 6 and abortJoystickCalibration restore it (safe mode's
    // deliberate shutdown stays untouched — see their guards).
    pollTimer.disable(pollTimerId[CONF_TIMER_DEBUG]);
    if (!g_safeModeEnabled) {
      // 4.5.7 review: safe mode never shuts the INPUT poll down (it is the
      // only hardware input there — how the safe menu is navigable), so the
      // calibration must not disable it either: step 6's safe-mode guard
      // skips the re-enable, and the asymmetry left every button/switch
      // dead for the rest of the boot after a CA,1:1 on a sensorful safe
      // unit. The sensor timers are already off in safe mode; disabling
      // them again is a harmless no-op.
      pollTimer.disable(pollTimerId[CONF_TIMER_INPUT]);
    }
    pollTimer.disable(pollTimerId[CONF_TIMER_PRESSURE]);
    // A menu-driven calibration is user-paced at each corner and can exceed
    // the 5-minute menu timeout (4.5.7 review): a mid-run deactivateMenu()
    // blanked the OLED between the step prompts. Safe mode already disables
    // the timeout (toggleSafeMode); the run re-enables it at completion.
    screen.disableTimeout();
    setLedState(LED_ACTION_BLINK, CONF_JOY_CALIB_START_LED_COLOR, CONF_JOY_CALIB_LED_NUMBER, CONF_JOY_CALIB_STEP_BLINK, CONF_JOY_CALIB_STEP_BLINK_DELAY, led.getLedBrightness());
    performLedAction(ledCurrentState);
    ++stepNumber;
    calibrationTimerId[0] = calibrationTimer.setTimeout(currentReadingStart, performJoystickCalibration, (int*)(stepNumber | (calibFromApi ? CONF_CALIB_API_FLAG : 0)));  // Start next step
    if (calibrationTimerId[0] < 0) {
      abortJoystickCalibration(calibFromApi, "first-corner timer refused");
      return;
    }
  } else if (stepNumber < 5) {                                                                                               // STEP 1-4: Joystick Calibration Corner Points
    screen.fullCalibrationPrompt(stepNumber);
    buzzer.calibCornerTone();
    setLedState(LED_ACTION_BLINK, CONF_JOY_CALIB_STEP_BLINK_COLOR, CONF_JOY_CALIB_LED_NUMBER, CONF_JOY_CALIB_STEP_BLINK, CONF_JOY_CALIB_STEP_BLINK_DELAY, led.getLedBrightness());
    performLedAction(ledCurrentState);  // LED Feedback to show start of performJoystickCalibrationStep
    js.zeroInputMax(stepNumber);        // Clear the existing calibration value

    calibrationTimerId[1] = calibrationTimer.setTimer(CONF_JOY_CALIB_READING_DELAY, currentReadingStart, CONF_JOY_CALIB_READING_NUMBER, performJoystickCalibrationStep, (int*)(stepNumber | (calibFromApi ? CONF_CALIB_API_FLAG : 0)));
    if (calibrationTimerId[1] < 0) {
      abortJoystickCalibration(calibFromApi, "corner-reading timer refused");
      return;
    }
    ++stepNumber;
    // Set LED's feedback to show step is already started and get the max reading for the quadrant/step

    calibrationTimerId[0] = calibrationTimer.setTimeout(nextStepStart, performJoystickCalibration, (int*)(stepNumber | (calibFromApi ? CONF_CALIB_API_FLAG : 0)));  // Start next step
    if (calibrationTimerId[0] < 0) {
      calibrationTimer.deleteTimer(calibrationTimerId[1]);
      abortJoystickCalibration(calibFromApi, "next-corner timer refused");
      return;
    }
  } else if (stepNumber == 5) {                                                                                        // STEP 5 : Joystick center point initialization
    screen.fullCalibrationPrompt(stepNumber);
    buzzer.calibCenterTone();
    g_calibrationCenterStep = true;   // The chain's own internal center — bypass the in-flight gate (synchronous: no timer fires between set and clear)
    setJoystickInitialization(false, false);
    g_calibrationCenterStep = false;
    if (!g_centerRunning) {
      abortJoystickCalibration(calibFromApi, "center step refused");
      return;
    }
    ++stepNumber;
    calibrationTimerId[0] = calibrationTimer.setTimeout(nextStepStart, performJoystickCalibration, (int*)(stepNumber | (calibFromApi ? CONF_CALIB_API_FLAG : 0)));  // Start next step
    if (calibrationTimerId[0] < 0) {
      abortJoystickCalibration(calibFromApi, "completion timer refused");
      return;
    }
  }

  else  // STEP 6: Calibration ended
  {
    g_calibrationRunning = false;
    g_calibrationFromApi = false;  // 4.9.9 round 3: the chain's initiator dies with the chain
    setLedState(LED_ACTION_BLINK, CONF_JOY_CALIB_START_LED_COLOR, CONF_JOY_CALIB_LED_NUMBER, CONF_JOY_CALIB_STEP_BLINK, CONF_JOY_CALIB_STEP_BLINK_DELAY, led.getLedBrightness());  // Turn off Led's
    performLedAction(ledCurrentState);
    js.setMinimumRadius();  // Update the minimum cursor operating radius
    js.reprocessLastReading();  // Apply the new radius even while the stick is stationary
    setLedDefault();
    canOutputAction = true;
    g_resetCenterComplete = true;
    // The INPUT poll comes back unconditionally (4.5.7 review): safe mode
    // never disabled it (see step 0), and it is the only hardware input a
    // safe boot has.
    pollTimer.enable(pollTimerId[CONF_TIMER_INPUT]);
    if (!g_safeModeEnabled) {
      // The sensor poll timers and the menu timeout stay inside the
      // safe-mode guard: the API is not filtered by safe mode, and
      // re-enabling these on a safe boot would run 20 ms I2C traffic
      // against whatever hardware toggleSafeMode shut down, and re-arm the
      // 5-minute timeout the safe menu deliberately disables.
      screen.enableTimeout();  // The run may have been menu-driven — see step 0
      // 4.9.9 review round 4: the debug poll comes back (step 0 paused it
      // for the flow — the symmetric direction of the DM,1 mid-flow
      // refusal). g_debugMode cannot have changed mid-flow (the DM,1 setter
      // now refuses while a flow runs), so this restores exactly the state
      // step 0 paused.
      pollTimer.enable(pollTimerId[CONF_TIMER_DEBUG]);
      // Restore the swap with the same debug gate the swap itself uses (the
      // 4.6.6 DM=1 contract — see abortJoystickCalibration's matching fix).
      if (outputAction == CONF_ACTION_SCROLL && g_debugMode != CONF_DEBUG_MODE_JOYSTICK) {
        pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);
        pollTimer.enable(pollTimerId[CONF_TIMER_SCROLL]);
      } else if (g_debugMode != CONF_DEBUG_MODE_JOYSTICK) {
        pollTimer.enable(pollTimerId[CONF_TIMER_JOYSTICK]);
        pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);
      }
      pollTimer.enable(pollTimerId[CONF_TIMER_PRESSURE]);
    }
    screen.fullCalibrationPrompt(stepNumber);  // update
    g_calibrationError = false;
  }
}
//***PERFORM JOYSTICK CALIBRATION STEP FUNCTION***//
// Function   : performJoystickCalibrationStep
//
// Description: This function performs the actual joystick maximum point calibration step in a recursive fashion.
//
// Parameters : * args : int : pointer of step number
//
// Return     : void
//****************************************//
void performJoystickCalibrationStep(int* args) {
  // The run gate its chain driver has (the abortJoystickCalibration comment):
  // a stale corner callback must become a no-op rather than revive a failed
  // flow — this body persists a corner, acks it on the wire, and can abort
  // the chain, none of which may happen for an already-aborted calibration.
  if (!g_calibrationRunning) return;
  // See performJoystickCalibration(): the payload carries this chain's
  // initiator alongside the step number — the corner line is an ack (SUCCESS)
  // only when the serial API started the calibration, MANUAL otherwise.
  bool calibFromApi = ((int)args & CONF_CALIB_API_FLAG) != 0;
  int stepNumber = (int)args & ~CONF_CALIB_API_FLAG;
  String stepKey = "CA" + String(stepNumber);       // Key to write new calibration point to Flash memory
  String stepCommand = "CA," + String(stepNumber);  // Command to output calibration point via serial
  pointFloatType maxPoint;
  int magnetZDirection = js.getMagnetZDirection();
  // A FAULT latch (0) must not zero the fallback corners (4.5.7 review):
  // the default-corner geometry multiplies by this direction, and a 0 here
  // replaced every fallback corner with {0,0} — a stored corner that then
  // failed setMinimumRadius's validity check and left the radius at the
  // full 30 mT default (a stiff, barely-responsive cursor). Same
  // DEFAULT-polarity fallback the boot path uses (setMagnetDirection): a
  // briefly wrong axis beats a degenerate corner.
  if (magnetZDirection == JOY_DIRECTION_FAULT) magnetZDirection = JOY_DIRECTION_DEFAULT;

  //Serial.print("Step started: ");   // TODO: Remove these print statements
  //Serial.print(stepNumber);
  //Serial.print(" numRuns: ");
  //Serial.println(calibrationTimer.getNumRuns(calibrationTimerId[1]));

  // Turn on and set all leds to orange to indicate start of the process // TODO Jake update to non-neopixel LEDS
  if (calibrationTimer.getNumRuns(calibrationTimerId[1]) == 1) {  // Turn LLED's ON when timer is running for first time
    setLedState(LED_ACTION_ON, CONF_JOY_CALIB_LED_COLOR, CONF_JOY_CALIB_LED_NUMBER, 0, 0, led.getLedBrightness());
    performLedAction(ledCurrentState);
  }

  maxPoint = js.getInputMax(stepNumber);  // Get maximum x and y for the step number

  // Turn off all the LEDs to orange to indicate end of the process
  if (calibrationTimer.getNumRuns(calibrationTimerId[1]) == CONF_JOY_CALIB_READING_NUMBER) {  // Turn LED's OFF when timer is running for last time
    // Validate only after all ten readings have accumulated. The old
    // per-reading fallback installed a 13 mT default on the first sample if
    // the user was still moving into position; that default then beat every
    // later real corner below 13 mT and could never be replaced.
    if ((abs(maxPoint.x) < CONF_JOY_CALIB_CORNER_MIN) || (abs(maxPoint.y) < CONF_JOY_CALIB_CORNER_MIN)) {
      pointFloatType tempDefaultPoint = { 0, 0 };
      switch (stepNumber) {
        case 1:  // Top left corner
          tempDefaultPoint = { float(CONF_JOY_CALIB_CORNER_DEFAULT) * magnetZDirection, float(-CONF_JOY_CALIB_CORNER_DEFAULT) * magnetZDirection };
          break;
        case 2:  // Top right corner
          tempDefaultPoint = { float(-CONF_JOY_CALIB_CORNER_DEFAULT) * magnetZDirection, float(-CONF_JOY_CALIB_CORNER_DEFAULT) * magnetZDirection };
          break;
        case 3:  // Bottom right corner
          tempDefaultPoint = { float(-CONF_JOY_CALIB_CORNER_DEFAULT) * magnetZDirection, float(CONF_JOY_CALIB_CORNER_DEFAULT) * magnetZDirection };
          break;
        case 4:  // Bottom left corner
          tempDefaultPoint = { float(CONF_JOY_CALIB_CORNER_DEFAULT) * magnetZDirection, float(CONF_JOY_CALIB_CORNER_DEFAULT) * magnetZDirection };
          break;
      }
      maxPoint = tempDefaultPoint;
      js.setInputMax(stepNumber, maxPoint);
      g_calibrationError = true;
    }

    // The settings-size budget guard can refuse the store (LSMemory): the
    // corner response must then report FAIL,3, not SUCCESS — otherwise the
    // app's calibration readout would show a corner the next boot forgets.
    bool cornerStored = mem.writePoint(CONF_SETTINGS_FILE, stepKey, maxPoint);
    setLedState(LED_ACTION_OFF, LED_CLR_NONE, CONF_JOY_CALIB_LED_NUMBER, 0, 0, led.getLedBrightness());
    performLedAction(ledCurrentState);
    printResponseFloatPoint(true, calibFromApi, cornerStored, cornerStored ? 0 : 3, stepCommand, true, maxPoint);
    if (!cornerStored) {
      // A live-only corner is not a completed calibration. Stop the already-
      // scheduled continuation, reload all persisted corners, and show/report
      // failure instead of reaching step 6 and telling the user "calibrated"
      // with values the next boot will forget.
      abortJoystickCalibration(calibFromApi, "corner persistence failed");
      return;
    }
    if (g_calibrationError) {
      screen.fullCalibrationPrompt(CONF_JOY_CALIB_ERROR);
      // Feed the watchdog through the deliberate dwell (4.5.7 review):
      // upstream's own 3 s blocking hold (its TODO still asks "Why the
      // delay?") sat exactly at the TIMER3 hang witness's 3 s threshold —
      // a tick landing in the overshoot fired a false "hang witnessed"
      // SREQ mid-calibration. The dwell UX is kept, but the loop keeps the
      // watchdog (and the witness's un-fed-seconds counter) alive.
      unsigned long errorDwellStart = millis();
      while (millis() - errorDwellStart < 3000) {
        if (g_watchdogArmed) {
          watchdogLoop();
        }
        delay(10);
      }
      g_calibrationError = false;
    }
  }
}

//***JOYSTICK LOOP FUNCTION***//
// Function   : joystickLoop
//
// Description: This function handles joystick move and scroll actions.
//
// Parameters : void
//
// Return     : void
//****************************************//
void joystickLoop() {
  //if (USB_DEBUG) { Serial.println("USBDEBUG: joystickLoop"); }
  js.update();  // Request new values

  pointIntType joyOutPoint = js.getXYOut();  // Read the filtered values

  // Cursor hold during sip & puff (CF, roadmap item 11 / upstream #44): the
  // cursor freezes while a mouthpiece input is in progress, so deflecting
  // the stick mid-sip cannot drag the pointer around. The old
  // !g_sapDisabled term is gone (4.5.7 review): the pressure state machine
  // keeps tracking sips with SD set (SD gates ACTIONS, not sensing), and a
  // user physically sipping — head motion perturbing the stick — still
  // deserves CF's protection; the premise "with SD there is no mouthpiece
  // input at all" was false.
  bool sapInProgress = g_freezeCursorDuringSap && (ps.getState().mainState != PRESS_SAP_MAIN_STATE_NONE);

  // Bus-crawl backoff suppresses cursor output entirely (4.5.7 review):
  // during the self-measured backoff the last computed output stays on the
  // buffers, and performJoystick replayed it as relative movement every
  // tick — a user holding a corner when the shared bus wedged got a cursor
  // that flew to and ground against the screen edge for up to 60 s with NO
  // input able to stop it (returning the stick to center changed nothing:
  // the stale output was what replayed). Zero motion until real readings
  // return.
  bool outputSuppressed = js.isPollBackedOff();

  if (g_resetCenterComplete && !sapInProgress && !outputSuppressed) {  // Don't output joystick movement until the center position has been reset
    performJoystick(joyOutPoint);                 // Perform joystick move action
  }

  //if (USB_DEBUG) { Serial.println("USBDEBUG: End of joystickLoop"); }
}

//***PERFORM JOYSTICK FUNCTION***//
// Function   : performJoystick
//
// Description: This function performs joystick move and scroll actions.
//
// Parameters : inputPoint : pointIntType : The output cursor x and y
//
// Return     : void
//****************************************//
void performJoystick(pointIntType inputPoint) {
  pointIntType outputPoint = {0,0};
  
  if (g_operatingMode == CONF_OPERATING_MODE_MOUSE) {
    int maxMouse = js.getMouseSpeedRange();
    outputPoint.x = js.mapRoundInt(inputPoint.x, -CONF_JOY_OUTPUT_XY_MAX, CONF_JOY_OUTPUT_XY_MAX ,-maxMouse, maxMouse);
    outputPoint.y = js.mapRoundInt(inputPoint.y, -CONF_JOY_OUTPUT_XY_MAX, CONF_JOY_OUTPUT_XY_MAX ,-maxMouse, maxMouse);
    // Deflection-based acceleration (roadmap item 9): reshapes the mapped
    // cursor curve per axis; full deflection keeps the full speed of the
    // current speed level, and level 0 (the default) is a no-op.
    outputPoint.x = accelerationModifier(outputPoint.x, maxMouse, acceleration);
    outputPoint.y = accelerationModifier(outputPoint.y, maxMouse, acceleration);
    // 0 = None , 1 = USB , 2 = Wireless
    if (g_comMode == CONF_COM_MODE_USB) {
      (outputAction == CONF_ACTION_SCROLL) ? usbmouse.scroll(scrollModifier(round(inputPoint.y), CONF_JOY_OUTPUT_XY_MAX, g_scrollLevel)) : usbmouse.move(outputPoint.x, outputPoint.y);

    } else if (g_comMode == CONF_COM_MODE_BLE) {
      (outputAction == CONF_ACTION_SCROLL) ? btmouse.scroll(scrollModifier(round(inputPoint.y), CONF_JOY_OUTPUT_XY_MAX, g_scrollLevel)) : btmouse.move(outputPoint.x, outputPoint.y);
    }
  } else if (g_operatingMode == CONF_OPERATING_MODE_GAMEPAD) {
    // Gamepad is USB only, if wireless gamepad functionality is added, add that here
    outputPoint.x = js.mapRoundInt(inputPoint.x, -CONF_JOY_OUTPUT_XY_MAX, CONF_JOY_OUTPUT_XY_MAX ,-CONF_JOY_OUTPUT_XY_MAX_GAMEPAD, CONF_JOY_OUTPUT_XY_MAX_GAMEPAD);
    outputPoint.y = js.mapRoundInt(inputPoint.y, -CONF_JOY_OUTPUT_XY_MAX, CONF_JOY_OUTPUT_XY_MAX ,-CONF_JOY_OUTPUT_XY_MAX_GAMEPAD, CONF_JOY_OUTPUT_XY_MAX_GAMEPAD);
    gamepad.move(outputPoint.x, outputPoint.y);
    gamepad.send();
  }
}

//***SCROLL MOVEMENT MODIFIER FUNCTION***//
// Function   : scrollModifier
//
// Description: This function converts y cursor movements to y scroll movements based on y cursor value and scroll speed level.
//
// Parameters : cursorValue : const int : y cursor value.
//              cursorMaxValue : const int : maximum y cursor value.
//              scrollLevelValue : const int : scroll speed level value.
//
// Return     : cursorOutput : int : The modified scroll value.
//****************************************//
int scrollModifier(const int cursorValue, const int cursorMaxValue, const int scrollLevelValue) {
  int scrollOutput = 0;

  //int scrollMaxSpeed = round((1.0 * pow(CONF_SCROLL_MOVE_MAX, scrollLevelValue / 10.0)) + CONF_SCROLL_MOVE_BASE);
  //int scrollMaxSpeed = round((1.0 * pow(CONF_SCROLL_MOVE_MAX, scrollLevelValue / CONF_SCROLL_LEVEL_MAX)) + CONF_SCROLL_MOVE_BASE);
  int scrollMaxSpeed = round((1.0 * CONF_SCROLL_MOVE_MAX * scrollLevelValue/CONF_SCROLL_LEVEL_MAX) + CONF_SCROLL_MOVE_BASE); // Max scroll speed at a given scroll level

  //scrollOutput = map(cursorValue, 0, cursorMaxValue, 0, scrollMaxSpeed);
  //scrollOutput = -1 * constrain(scrollOutput, -1 * scrollMaxSpeed, scrollMaxSpeed);

  scrollOutput = round(float(cursorValue) * float(scrollMaxSpeed) / float(cursorMaxValue));     // Actual scroll output based on amount of joystick movement
  scrollOutput = -1 * constrain(scrollOutput, -1 * scrollMaxSpeed, scrollMaxSpeed);


  //Serial.print(cursorValue);  Serial.print("\t");
  //Serial.print(cursorMaxValue); Serial.print("\t");
  //Serial.println(scrollOutput);  

  // 4.5.7 review: at scroll level 10 the max speed is 17, so a strong-but-
  // not-full deflection (|y| in ~[934, 993] of 1024) computed
  // |scrollOutput| == 16 and this modulus became X % 0 — one pulse, then
  // dead scroll while the deflection stayed in that band (and a HardFault
  // on any future core with DIV_0_TRP). Clamp the period to >= 1: full
  // pulse rate at the top of the band.
  int scrollPulsePeriod = CONF_SCROLL_MOVE_MAX - abs(scrollOutput);
  if (scrollPulsePeriod < 1) scrollPulsePeriod = 1;
  if (g_scrollNumRuns % scrollPulsePeriod == 0){
    if (cursorValue < 0) {
      scrollOutput = 1;
    } else if (cursorValue > 0){
      scrollOutput = -1;
    } else { 
      scrollOutput = 0;
    }
    g_scrollNumRuns = 0;
  } else {
    scrollOutput = 0;
  }

  g_scrollNumRuns++;
  return scrollOutput;
}


//***ACCELERATION MOVEMENT MODIFIER FUNCTION***//
// Function   : accelerationModifier
//
// Description: Deflection-based cursor response curve (roadmap item 9,
//              upstream #86). The stored level (-10..10, default 0) bends
//              the deflection-to-speed curve while leaving both endpoints
//              fixed: zero deflection stays zero, and FULL deflection
//              always maps to the full speed of the current cursor speed
//              level — acceleration trades mid-range precision for speed,
//              never top speed.
//                level  0  → linear (identical to the pre-acceleration output)
//                level 10  → exponent 0.0: any deflection moves at ~full speed
//                level -10 → exponent 2.0: gentle deflections move very slowly
//              The exponent moves 0.1 per level:
//                out = sign(v) · max · (|v| / max) ^ (1 − level·0.1)
//              Host-side acceleration varies per device and affects other
//              mice when tuned for the LipSync — this keeps the curve on the
//              device where the speed level already lives.
//
// Parameters : cursorValue : const int : The mapped cursor axis value (-max..max).
//              cursorMaxValue : const int : The maximum cursor axis value.
//              accelerationValue : const int : The acceleration level (-10..10).
//
// Return     : cursorOutput : int : The reshaped cursor axis value.
//****************************************//
int accelerationModifier(const int cursorValue, const int cursorMaxValue, const int accelerationValue) {
  if (cursorValue == 0 || cursorMaxValue <= 0 || accelerationValue == 0) {
    return cursorValue;  // Zero maps to zero; level 0 is the identity curve
  }

  float exponent = 1.0f - (accelerationValue * 0.1f);
  if (exponent < 0.0f) exponent = 0.0f;
  if (exponent > 2.0f) exponent = 2.0f;

  float magnitude = fabs((float)cursorValue);
  float scaled = pow(magnitude / (float)cursorMaxValue, exponent) * (float)cursorMaxValue;
  int accelerationOutput = (int)round(scaled);
  return (cursorValue < 0) ? -accelerationOutput : accelerationOutput;
}


//*********************************//
// Debug Functions
//*********************************//

//***INITIALIZE DEBUG FUNCTION***//
// Function   : initDebug
//
// Description: This function initializes debug mode and debug state.
//
// Parameters : void
//
// Return     : void
//****************************************//
void initDebug() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initDebug()"); }
  g_debugMode = getDebugMode(false, false);  // Get debug mode number stored in flash memory
  setDebugState(g_debugMode);                // Set debug operation state based on the debug mode
}

//***DEBUG LOOP FUNCTION***//
// Function   : debugLoop
//
// Description: This function outputs debug data based on debug mode.
//
// Parameters : void
//
// Return     : void
//****************************************//
void debugLoop() {
  //if (USB_DEBUG) { Serial.println("USBDEBUG: debugLoop"); }
  // Debug mode is off if the debug mode is #0
  if (g_debugMode == CONF_DEBUG_MODE_JOYSTICK) {  // Debug #1
    js.update();                                  // Request new values from joystick class
    pointFloatType debugJoystickArray[3];
    debugJoystickArray[0] = js.getXYRaw();                                       // Read the raw values
    debugJoystickArray[1] = { (float)js.getXYIn().x, (float)js.getXYIn().y };    // Read the filtered values
    debugJoystickArray[2] = { (float)js.getXYOut().x, (float)js.getXYOut().y };  // Read the output values
    printResponseFloatPointArray(true, true, true, 0, "DEBUG,1", true, "", 3, ',', debugJoystickArray);
  } else if (g_debugMode == CONF_DEBUG_MODE_PRESSURE) {  // Debug #2
    // pressureLoop owns all sampling/state advancement. Taking another
    // sample here (on a separate 100 ms timer) can land beside its 50 ms tick
    // and count one 25 Hz sensor conversion twice in the engagement filter.
    float debugPressureArray[4];
    debugPressureArray[0] = ps.getSapPressureAbs();   // Read the main pressure
    debugPressureArray[1] = ps.getAmbientPressure();  // Read the ref pressure
    debugPressureArray[2] = ps.getSapPressure();      // Read the diff pressure
    debugPressureArray[3] = ps.getOffsetPressure();      // Read the diff pressure    
    printResponseFloatArray(true, true, true, 0, "DEBUG,2", true, "", 4, ',', debugPressureArray);
  } else if (g_debugMode == CONF_DEBUG_MODE_BUTTON) {  // Debug #3
    int debugButtonArray[3];
    debugButtonArray[0] = buttonState.mainState;         // Read the main state
    debugButtonArray[1] = buttonState.secondaryState;    // Read the secondary state
    debugButtonArray[2] = (int)buttonState.elapsedTime;  // Read the Elapsed Time
    printResponseIntArray(true, true, true, 0, "DEBUG,3", true, "", 3, ',', debugButtonArray);
  } else if (g_debugMode == CONF_DEBUG_MODE_SWITCH) {  // Debug #4
    int debugSwitchArray[3];
    debugSwitchArray[0] = switchState.mainState;         // Read the main state
    debugSwitchArray[1] = switchState.secondaryState;    // Read the secondary state
    debugSwitchArray[2] = (int)switchState.elapsedTime;  // Read the Elapsed Time
    printResponseIntArray(true, true, true, 0, "DEBUG,4", true, "", 3, ',', debugSwitchArray);
  } else if (g_debugMode == CONF_DEBUG_MODE_SAP) {  // Debug #5
    int debugSapArray[3];
    debugSapArray[0] = sapActionState.mainState;         // Read the main state
    debugSapArray[1] = sapActionState.secondaryState;    // Read the secondary state
    debugSapArray[2] = (int)sapActionState.elapsedTime;  // Read the Elapsed Time
    printResponseIntArray(true, true, true, 0, "DEBUG,5", true, "", 3, ',', debugSapArray);
  }
}

//***SET DEBUG STATE FUNCTION***//
// Function   : setDebugState
//
// Description: This function configures the state of operation based on the debug mode
//
// Parameters : inputDebugMode : int : The current debug mode
//
// Return     : void
//****************************************//
void setDebugState(int inputDebugMode) {
  if (USB_DEBUG) {
    Serial.print("USBDEBUG: setDebugState( ");
    Serial.print(inputDebugMode);
    Serial.println(" )");
  }

  if (inputDebugMode == CONF_DEBUG_MODE_NONE) {
    pollTimer.disable(pollTimerId[CONF_TIMER_DEBUG]);
  } else if (!g_safeModeEnabled) {
    // Safe-mode gate (4.8.1 review): toggleSafeMode deliberately shuts the
    // DEBUG poll down (initDebug ran BEFORE it, so the safe boot won); the
    // API is not filtered by safe mode, so an ungated enable here would let
    // a serial DM,1..5 re-arm a 100 ms poll against hardware the safe boot
    // deliberately stopped touching (sensorless boots: js is never begun —
    // the same class the joystick restore below gates on g_safeModeEnabled).
    // A debug stream on the CDC-only recovery surface is also pure noise
    // for the caregiver using it.
    pollTimer.enable(pollTimerId[CONF_TIMER_DEBUG]);
  }

  if (inputDebugMode == CONF_DEBUG_MODE_JOYSTICK) {
    pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);  // Disable joystick data polling
    pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);    // Disable scroll data polling
  } else {
    // Leaving joystick-debug mode must restore exactly one normal joystick
    // loop. The old code restored neither when switching DM=1 -> DM=2..5,
    // freezing cursor/gamepad movement; DM=0 enabled BOTH loops and doubled
    // reports until the next input-state tick happened to correct it.
    if (!g_safeModeEnabled && g_joystickSensorConnected) {
      if (outputAction == CONF_ACTION_SCROLL) {
        pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);
        pollTimer.enable(pollTimerId[CONF_TIMER_SCROLL]);
      } else {
        pollTimer.enable(pollTimerId[CONF_TIMER_JOYSTICK]);
        pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);
      }
    } else {
      pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);
      pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);
    }
  }
}


//***READ VDD MILLIVOLTS FUNCTION***//
// Function   : readVddMillivolts
//
// Description: Measures the chip's own VDD — electrically the +3V3 net that
//              feeds all four I2C devices (the XIAO's 3V pin, the display on
//              J1 and the joystick pod on J2). The boot-bus hunt's field
//              evidence (B22b, 20 power cycles: ~35% of power-on boots land
//              all-missing with clean NACKs on an idle bus, stochastic across
//              dwell time and plug technique, healing in per-device stages)
//              reads as "the master is alone on the bus" — either the shared
//              rail sagging/never-cycling (USB input, connector, regulator)
//              or an open between the rail and the slaves. The nRF52840
//              survives a much lower VDD than the sensors do, so the rail can
//              sag far enough to kill every slave while the MCU boots fine —
//              and the SAADC's internal VDD channel answers that from the
//              wire: a degraded boot reporting vdd=~3300 points downstream
//              (contacts/wiring/slaves), vdd well below ~3100 points at the
//              rail itself. Diagnostic only — no behavior keys on it.
//
//              AR_INTERNAL (0.6 V ref, gain 1/6) gives a 3.6 V full scale;
//              12-bit resolution maps raw*3600/4095 to millivolts. Two
//              samples with the first discarded — the first conversion after
//              a SAADC config change carries the startup artifact. ~2x<50 us
//              per call, blocking; called from BH (on demand) and the
//              degraded HB line (every 5 s in safe mode).
//
// Parameters : void
//
// Return     : int : measured VDD in millivolts (0 on a failed conversion)
//****************************************//
int readVddMillivolts() {
  analogReference(AR_INTERNAL);
  analogReadResolution(12);
  (void)analogReadVDD();  // discard the post-config-change first sample
  const uint32_t raw = analogReadVDD();
  if (raw == 0 || raw > 4095) return 0;
  return (int)((raw * 3600UL) / 4095UL);
}

//***CHECK I2C FUNCTION***//
// Function   : checkI2C
//
// Description: This function checks to ensure the necessary i2C devices are connected.
//
// Parameters : void
//
// Return     : void
//****************************************//
void checkI2C() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: checkI2C"); }

  // No Wire.end() here (4.5.4): this used to disable the TWIM peripheral
  // behind it — scanner-example residue with no consumer — and the bus only
  // worked afterwards because the display's and the pressure sensors'
  // begin()s happen to call Wire.begin() as a side effect. The XENSIV
  // migration deliberately stopped the joystick library from re-beginning
  // the shared bus (executeInit=false), which left the joystick-only
  // degraded boot reading against a dead controller until the vendored
  // Wire's bounded recovery re-enabled it. One owner instead: the bus comes
  // up at setup()'s top (4.9.8 fix A) and stays up for every consumer — this
  // begin() remains as the idempotent re-assert for any future caller that
  // reaches the scan without the setup-top bring-up.

  // 4.9.8 (boot-bus fix C): the scan is now BOUNDED-RETRY, not single-shot.
  // The field episode (app log 2026-11-15/16) showed the failure mode the
  // single pass could never survive: a slave left in a non-idle protocol
  // state by the previous session's mid-transaction NVIC_SystemReset() (or
  // stranded by the floating pre-begin bus — no external pull-ups on this
  // PCB) answers its address with a CLEAN NACK forever, a clean NACK never
  // reaches the vendored Wire's timeout recovery, and the whole session was
  // condemned to safe mode on pass 1 — with safe mode generating zero I2C
  // traffic, so NOTHING could heal until a lucky boot scanned a bus that a
  // previous pass had happened to realign ("two beeps" -> "one beep" ->
  // healthy, one device class per boot). The retry turns that healing curve
  // into boot-time work: the probes' own address clocks plus the inter-pass
  // settle + proactive bus-clear realign the slaves HERE, within one boot.
  // Costs: a healthy boot exits after pass 1 (identical to the old single
  // shot — silence, no notes), and a truly-absent device delays the verdict
  // by at most (CONF_I2C_SCAN_PASSES - 1) x (CONF_I2C_SCAN_SETTLE_MS + probe
  // time) before the same "not found" outcome as before.
  struct I2CProbe {
    uint8_t address;
    bool* connected;   // the global verdict flag hardwareErrorCheck/BH read
    const char* name;  // the legacy per-device "Not found" string
    uint8_t snsBit;    // this device's bit in the heartbeat's sns= nibble (LSI2CScan.h)
  };
  const I2CProbe probes[] = {
    { I2CADDR_DISPLAY, &g_displayConnected, "Display", LSI2C_SNS_DISPLAY },
    { I2CADDR_LPS22, &g_ambientPressureSensorConnected, "Ambient Pressure Sensor", LSI2C_SNS_AMBIENT },
    { I2CADDR_LPS35HW, &g_mouthpiecePressureSensorConnected, "Mouthpiece Pressure Sensor", LSI2C_SNS_MOUTHPIECE },
    { I2CADDR_TLV493D, &g_joystickSensorConnected, "Joystick Sensor", LSI2C_SNS_JOYSTICK },
  };
  const uint8_t probeCount = sizeof(probes) / sizeof(probes[0]);

  uint8_t foundMask = 0;  // devices that have answered on ANY pass so far
  int passesDone = 0;
  do {
    if (passesDone > 0) {
      // The realignment window between passes: settle, then the proactive
      // bus-clear (bounded STOP + NXP 9-clock bus-clear + explicit STOP).
      // NOT stamped into the recovery telemetry — this is bring-up work,
      // not a wedge, and a scan that healed a bus must not read as
      // recoveries>0 in the BH row.
      delay(CONF_I2C_SCAN_SETTLE_MS);
      Wire.busClear();
    }
    for (uint8_t probeIdx = 0; probeIdx < probeCount; probeIdx++) {
      if (foundMask & probes[probeIdx].snsBit) continue;  // already answered — one ACK is final
      Wire.beginTransmission(probes[probeIdx].address);
      const byte probeError = Wire.endTransmission();
      if (probeError == 0) {
        foundMask |= probes[probeIdx].snsBit;  // Display found / sensor found
        if (passesDone > 0) {
          // A pass-1 NACK that a later pass healed is exactly the state the
          // field episode could only diagnose from the app's BH rows — name
          // it on the wire (queued pre-attach: the TX queue's boot-diagnostics
          // window, 4.9.9 review round 3, buffers it for the first host that
          // opens the port; the 4.6.4 anti-replay gate would otherwise drop
          // it). First-pass success stays SILENT (the
          // healthy-boots-print-nothing contract).
          char healNote[80];  // worst case: "INFO: I2C scan: " + the longest name
                              // ("Mouthpiece Pressure Sensor", 26) + " answered on pass 3 of 3" = 67
          const int healNoteLen = snprintf(healNote, sizeof(healNote),
                                           "INFO: I2C scan: %s answered on pass %d of %d",
                                           probes[probeIdx].name, passesDone + 1,
                                           (int)CONF_I2C_SCAN_PASSES);
          if (healNoteLen > 0) {
            serialTxEnqueueDiagLine(healNote, (size_t)healNoteLen);
          }
        }
      }
    }
    passesDone++;
  } while (lsi2cScanWantsAnotherPass(passesDone, (uint8_t)(LSI2C_SNS_ALL & ~foundMask)));

  // Final verdicts — written once, after the scan budget, in the legacy
  // string shape (the raw prints land in TinyUSB's pre-attach discard
  // window; the wire-visible copies are hardwareErrorCheck's ERROR lines,
  // which reach the wire through the TX queue's boot-diagnostics buffering
  // window — 4.9.9 review round 3; the 4.6.4 anti-replay gate used to drop
  // them whenever the host had not asserted DTR by enqueue time).
  for (uint8_t probeIdx = 0; probeIdx < probeCount; probeIdx++) {
    if (foundMask & probes[probeIdx].snsBit) {
      *probes[probeIdx].connected = true;
    } else {
      Serial.print("ERROR: ");
      Serial.print(probes[probeIdx].name);
      Serial.println(": Not found");
      *probes[probeIdx].connected = false;
    }
  }
}


//*********************************//
// LED Functions
//*********************************//

//***INITIALIZE LED FUNCTION***//
// Function   : initLed
//
// Description: This function initializes LED output as feedback method.
//
// Parameters : void
//
// Return     : void
//****************************************//
void initLed() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: Initializing LEDs"); }
  led.begin();
  *ledCurrentState = { 0, 0, 0, 0, 0, 0 };  // Initialize pointer ledAction, ledColorNumber, ledBlinkNumber, ledBlinkTime, ledBrightness
  turnLedAllOff();

  led.setLightModeLevel(getLightMode(false, false));
  led.setLedBrightnessLevel(getLightBrightnessLevel(false, false)); 
}


//***LED WAIT FEEDBACK FUNCTION***//
// Function   : ledWaitFeedback
//
// Description: This function sets the LEDS to cue the user to wait for initialization.
//
// Parameters : void
//
// Return     : void
//****************************************//
void ledWaitFeedback() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: All LEDS on"); }
  setLedState(LED_ACTION_ON, LED_CLR_RED, CONF_LED_ALL, 0, 0, led.getLedBrightness());  // Turn on all LEDS
  performLedAction(ledCurrentState);
}

// (ledReadyFeedback REMOVED — 4.8.1 review: dead code, its only call is
// commented out at the setup call site; the ready cue is the buzzer's
// playReadySound plus the LED defaults. Restore only with a real consumer.)

//***STARTUP INITIALIZATION LED FUNCTION***//
// Function   : startupFeedback
//
// Description: This function performs the startup initialization feedback.
//
// Parameters : void
//
// Return     : void
//****************************************//
void startupFeedback() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: startupFeedback"); }
  // The historical startup callback body is empty. Do not consume a timer
  // slot for a zero-delay no-op; setup enables LED actions explicitly.
  ledTimerId[CONF_TIMER_LED_STARTUP] = -1;
}

//***SET LED STATE FUNCTION***//
// Function   : setLedState
//
// Description: This function sets LED states based on led number, blink number, color number, blink delay , and brightness.
//
// Parameters : ledAction      : int : led action ( NOTHING , ON , OFF , BLINK )
//              ledColorNumber : int : led color number
//              ledNumber      : int : led number ( 1, 2, 3, 4 or all )
//              ledBlinkNumber : int : led blink number
//              ledBlinkTime : unsigned long : led blink delay time
//              ledBrightness : int : led brightness
//
// Return     : void
//****************************************//
void setLedState(int ledAction, int ledColorNumber, int ledNumber, int ledBlinkNumber, unsigned long ledBlinkTime, int ledBrightness) {
  if (ledNumber >= CONF_LED_NONE && ledNumber <= OUTPUT_LED_NUM + 1 &&
      ledAction >= LED_ACTION_NONE && ledAction <= LED_ACTION_BLINK &&
      ledBlinkNumber >= 0) {
    ledCurrentState->ledAction = ledAction;
    ledCurrentState->ledColorNumber = ledColorNumber;
    ledCurrentState->ledNumber = ledNumber;
    ledCurrentState->ledBlinkNumber = ledBlinkNumber;
    ledCurrentState->ledBlinkTime = ledBlinkTime;
    ledCurrentState->ledBrightness = ledBrightness;
  }
}


// (ledStartupEffect and ledIBMEffect REMOVED — 4.8.1 review: dead code.
// ledStartupEffect was entirely commented out; ledIBMEffect had no callers
// and was a wrong-re-enable hazard if ever rewired — its end branch called
// enablePoll(true), force-enabling PRESSURE/INPUT/BLUETOOTH polls while
// ignoring safe mode AND debug mode (the exact "re-enable polls wrongly"
// class the rest of this file keeps gating), and it re-armed from the
// SHARED ledCurrentState (the mid-run hijack the blinkStateSnapshot fix
// removed for blinks). CONF_TIMER_LED_IBM's slot holder stays; the id
// remains -1 forever. Restore only with a real consumer and its own gates.)


//***LED BLINK EFFECT FUNCTION***//
// Function   : ledBlinkEffect
//
// Description: This function performs the blink LED effect based on step number, led number passed by arguments.
//
// Parameters : args : ledStateStruct* : It includes step number, LED number.
//
// Return     : void
//****************************************//
void ledBlinkEffect(ledStateStruct* args) {
  if (ledStateTimer.getNumRuns(ledTimerId[CONF_TIMER_LED_BLINK]) % 2) {
    led.setLedColor(args->ledNumber, 0, args->ledBrightness);
  } else {
    led.setLedColor(args->ledNumber, args->ledColorNumber, args->ledBrightness);
  }

  if (ledStateTimer.getNumRuns(ledTimerId[CONF_TIMER_LED_BLINK]) == ((args->ledBlinkNumber) * 2) + 1) {
    setLedDefault();  // return all LEDs to default after blink finished
    // 4.5.7 review: the blink self-deleted its slot — clear the id so the
    // stale name can never make a later blinkLed's delete-before-rearm hit
    // a RECYCLED slot (e.g. the BT scan timer that took the freed slot in
    // BLE-disconnected mode).
    ledTimerId[CONF_TIMER_LED_BLINK] = -1;
  }
}

//***LED BLUETOOTH SCAN EFFECT FUNCTION***//
// Function   : ledBtScanEffect
//
// Description: This function performs bluetooth scan blink LED effect.
//
// Return     : void
//****************************************//
void ledBtScanEffect() {
  const int runs = ledStateTimer.getNumRuns(ledTimerId[CONF_TIMER_LED_BT]);
  if (runs % 2) {
    led.setLedColor(CONF_BT_LED_NUMBER, LED_CLR_NONE, CONF_BT_LED_BRIGHTNESS);

  } else {
    led.setLedColor(CONF_BT_LED_NUMBER, CONF_BT_LED_COLOR, CONF_BT_LED_BRIGHTNESS);
  }
  if (runs == ((CONF_BT_SCAN_BLINK_NUMBER * 2) + 1)) {
    ledTimerId[CONF_TIMER_LED_BT] = -1;
  }
}

//***LED BLUETOOTH FAILED EFFECT FUNCTION***//
// Function   : ledBtFailedEffect
//
// Description: This function performs the BLE-init-failed blink (red) —
// btFeedbackLoop re-arms it per poll while the init task has reported
// failure, the logless user's "Bluetooth is broken" cue (bench 2026-10-26:
// the user watched a fully dark device and had no way to know the stack
// had never come up). Reuses the CONF_TIMER_LED_BT slot — it can never
// coexist with the scan blink above: the scan blink requires
// needsInitialization false, this one requires it true.
//
// Return     : void
//****************************************//
void ledBtFailedEffect() {
  const int runs = ledStateTimer.getNumRuns(ledTimerId[CONF_TIMER_LED_BT]);
  if (runs % 2) {
    led.setLedColor(CONF_BT_LED_NUMBER, LED_CLR_NONE, CONF_BT_LED_BRIGHTNESS);

  } else {
    led.setLedColor(CONF_BT_LED_NUMBER, LED_CLR_RED, CONF_BT_LED_BRIGHTNESS);
  }
  if (runs == ((CONF_BT_SCAN_BLINK_NUMBER * 2) + 1)) {
    ledTimerId[CONF_TIMER_LED_BT] = -1;
  }
}

//***LED ERROR EFFECT FUNCTION***//
// Function   : ledErrorEffect
//
// Description: This function performs LED error ffect.
//
// Return     : void
//****************************************//
static int ledErrorRunTarget = 0;

void ledErrorEffect() {
  const int runs = ledStateTimer.getNumRuns(ledTimerId[CONF_TIMER_LED_ERROR]);
  if (runs % 2) {
    led.setLedColor(CONF_ERROR_LED_NUMBER, LED_CLR_NONE, CONF_ERROR_LED_BRIGHTNESS);

  } else {
    led.setLedColor(CONF_ERROR_LED_NUMBER, CONF_ERROR_LED_COLOR, CONF_ERROR_LED_BRIGHTNESS);
  }
  if (runs == ledErrorRunTarget) {
    ledTimerId[CONF_TIMER_LED_ERROR] = -1;
  }
}

//***LED ERROR FUNCTION***//
// Function   : ledError
//
// Description: This function displays LED sequence for hardware error
//
// Return     : void
//****************************************//
void ledError(int errorBlinks) {
  const int blinkStartDelay = 0;
  if (ledTimerId[CONF_TIMER_LED_ERROR] >= 0) {
    ledStateTimer.deleteTimer(ledTimerId[CONF_TIMER_LED_ERROR]);
    ledTimerId[CONF_TIMER_LED_ERROR] = -1;
  }
  if (errorBlinks <= 0) return;
  ledErrorRunTarget = (errorBlinks * 2) + 1;
  ledTimerId[CONF_TIMER_LED_ERROR] = ledStateTimer.setTimer(CONF_ERROR_LED_BLINK_DELAY, blinkStartDelay, ledErrorRunTarget, ledErrorEffect);
}

//***TURN ALL LEDS OFF FUNCTION***//
// Function   : turnLedAllOff
//
// Description: This function turns off all the LEDs.
//
// Parameters : void
//
// Return     : void
//****************************************//
void turnLedAllOff() {
  led.clearLedAll();
}

//***TURN LED OFF FUNCTION***//
// Function   : turnLedOff
//
// Description: This function turns off the specified LED based on led number passed by arguments.
//
// Parameters : args : ledStateStruct* : It includes led number.
//
// Return     : void
//****************************************//
void turnLedOff(ledStateStruct* args) {
  led.clearLed(args->ledNumber);
}

//***TURN LED ON FUNCTION***//
// Function   : turnLedOn
//
// Description: This function turns on the specified LED based on led number passed by arguments.
//
// Parameters : args : ledStateStruct* : It includes led number.
//
// Return     : void
//****************************************//
void turnLedOn(ledStateStruct* args) {
  led.setLedColor(args->ledNumber, args->ledColorNumber, args->ledBrightness);
}


//***BLINK LED FUNCTION***//
// Function   : blinkLed
//
// Description: This function blinks the specified LED based on led number and number of blinks passed by arguments.
//
// Parameters : args : ledStateStruct* : It includes led number and number of blinks.
//
// Return     : void
//****************************************//
static ledStateStruct blinkStateSnapshot;  // 4.5.7 review: the running blink reads ITS OWN captured parameters — see blinkLed

void blinkLed(ledStateStruct* args) {
  int blinkOffset = 0;  // number of milliseconds to delay start of blink
  // 4.5.7 review: delete the superseded blink before re-arming — the id was
  // simply overwritten, so a still-pending long blink (the 3 x 1000 ms
  // com-mode/brightness cues) kept firing after a newer, shorter blink
  // self-deleted its slot: ledBlinkEffect then read getNumRuns of the FREED
  // slot (0), took the else branch, lit the stale action's LED, and never
  // reached its setLedDefault cleanup — an LED stuck ON until an unrelated
  // event. The new blink's own final run performs the default restore, so
  // deleting the old tail is the correct supersede semantics. (The BT scan
  // blink deliberately re-arms per poll and must NOT do this — deletion
  // there would reset its cadence every second.)
  if (ledTimerId[CONF_TIMER_LED_BLINK] >= 0) {
    ledStateTimer.deleteTimer(ledTimerId[CONF_TIMER_LED_BLINK]);
  }
  // Snapshot the parameters (4.5.7 review): the effect used to dereference
  // the SHARED ledCurrentState on every fire, so any later setLedState (a
  // hold's 20 ms re-assert, a mode cue) hijacked the pending blink's
  // number/color/LED mid-run and misrouted its cleanup. The blink now runs
  // on its own captured copy; only one blink is ever live (the
  // delete-before-rearm above supersedes).
  blinkStateSnapshot = *args;
  ledTimerId[CONF_TIMER_LED_BLINK] = ledStateTimer.setTimer(blinkStateSnapshot.ledBlinkTime, blinkOffset, ((blinkStateSnapshot.ledBlinkNumber) * 2) + 1, ledBlinkEffect, &blinkStateSnapshot);
  if (ledTimerId[CONF_TIMER_LED_BLINK] < 0) setLedDefault();
}

//***SET DEFAULT LED EFFECT FUNCTION***//
// Function   : setLedDefault
//
// Description: This function sets the LED to default operating color based on led number and color passed by arguments.
//
// Parameters : args : ledStateStruct* : It includes led number and color.
//
// Return     : void
//****************************************//
void setLedDefault() {
  led.clearLedAll();  // Clear all LEDs

  switch (g_operatingMode) {
    case CONF_OPERATING_MODE_MOUSE:
      {
        if (g_comMode == CONF_COM_MODE_USB) {
          led.setLedColor(CONF_LED_MICRO, LED_CLR_PURPLE, led.getLedBrightness());  // USB: micro LED purple (stock v4.1 visual, kept — the v4.1 comment claimed this was the BLE indication, but the branch conditions and their comments were swapped)
        } else if (g_comMode == CONF_COM_MODE_BLE && btmouse.isConnected()) {    // BLE connected: micro LED solid blue — while DISCONNECTED btFeedbackLoop blinks it blue when advertising is up, red when init failed, dark while init is in flight
          led.setLedColor(CONF_BT_LED_NUMBER, LED_CLR_BLUE, led.getLedBrightness());
        }
        break;
      }
    case CONF_OPERATING_MODE_GAMEPAD:
      {
        led.setLedColor(CONF_LED_MICRO, LED_CLR_YELLOW, led.getLedBrightness());
        break;
      }
    case CONF_OPERATING_MODE_SAFE:
      {
       led.setLedColor(CONF_LED_ALL, LED_CLR_RED, led.getLedBrightness());
       break;
      }
  }
}

//***BLUETOOTH SCAN AND LED FEEDBACK LOOP FUNCTION***//
// Function   : btFeedbackLoop
//
// Description: This function performs the default LED effects to indicate the device is connected.
//
// Parameters : void
//
// Return     : void
//****************************************//
void btFeedbackLoop() {

  //if (USB_DEBUG) { Serial.println("USBDEBUG: btFeedbackLoop"); }

  // The BLE connection poll only matters in Bluetooth mode. In USB mode the
  // call is wasted — and on safe-mode boots the Bluefruit stack may never
  // have been initialized, where btmouse.isConnected() blocks the SoftDevice
  // for a full second (observed live as a flat 1 s main-loop tax).
  if (g_comMode != CONF_COM_MODE_BLE) return;
  // needsInitialization: the SoftDevice must actually have been begun (4.5.7
  // review) — a stored/live state with CM=BLE but no BLE begin() blocks 1 s
  // per poll on isConnected(). 4.5.13: if the init task has FINISHED while
  // needsInitialization is still true, the stack never came up (ble=3) —
  // blink the BT LED red per poll so a user without a log sees the degraded
  // state instead of a dark device; re-armed without deleting exactly like
  // the scan blink below (a delete would reset the cadence every second).
  // While the init is still in flight (g_bleInitDone false) the state is
  // transient — stay dark and return.
  if (needsInitialization) {
    if (g_bleInitPending && g_bleInitDone) {
      if (ledTimerId[CONF_TIMER_LED_BT] < 0) {
        ledTimerId[CONF_TIMER_LED_BT] = ledStateTimer.setTimer(CONF_BT_SCAN_BLINK_DELAY, 0, ((CONF_BT_SCAN_BLINK_NUMBER * 2) + 1), ledBtFailedEffect);
      }
    }
    return;
  }

  // Get the current bluetooth connection state
  bool tempIsConnected = btmouse.isConnected();

  // 4.9.4 (round 3, cross-module): a SWITCH WINDOW is not a host change. While
  // the bouncer holds the lockout, every non-target reconnect is deliberately
  // connected-then-dropped within milliseconds — and this 1 s poll cannot tell
  // that storm from real host transitions. Ungated, each bounce cycle drove
  // the full transition narration: the scan-blink timer armed and deleted
  // repeatedly (LED churn on a device whose user is watching the Hub for the
  // switch to complete), g_btIsConnected thrashed, and — the part that
  // matters — releaseOutputAction() fired on every transient drop, tearing
  // down a DRAG/SCROLL latch the window's own lsHostExecuteSwitch had already
  // released once. Worse, the push half (lsHostPushState below) narrated
  // bouncer traffic to the app as if the user had changed hosts.
  // The window's own tick owns connection decisions for its whole duration
  // (it bounces non-targets, admits the target and closes), and the close
  // path restores stock radio state — so the honest thing is to let the
  // window own the narration too and resync once, on the pass after it
  // closes. isConnected is still polled (the drag-latch guard below is
  // meaningful only against real state) but the transition bookkeeping is
  // suppressed while a window is open, and g_btIsConnected is re-synced on
  // the first pass after the window ends so the close is not mistaken for a
  // fresh transition.
  const bool switchWindowOpen = lsHostSwitchWindowOpen();
  static bool switchWindowWasOpen = false;
  // 4.9.4 (round 6, a defect in this gate's own first draft): the resync must
  // REPAINT, not merely adopt. Setting g_btIsConnected here made the
  // transition block below see "no change" on the very pass that follows the
  // window — so the LED kept whatever the window's last bounce/close left it
  // showing, with nothing in the steady state to repaint it (the 4.5.28
  // dark-until-unrelated-event class, reintroduced by this gate). Adopt the
  // settled state AND drive the LED to match it on this one pass: solid blue
  // when the target is connected, the scanning blink when it is not. The
  // transition bookkeeping is still not replayed — this is one direct paint
  // from the settled truth, not a replay of the storm's transitions.
  const bool windowJustEnded = (switchWindowWasOpen && !switchWindowOpen);
  if (windowJustEnded) {
    g_btIsConnected = tempIsConnected;
    if (ledTimerId[CONF_TIMER_LED_BT] >= 0) {
      ledStateTimer.deleteTimer(ledTimerId[CONF_TIMER_LED_BT]);
      ledTimerId[CONF_TIMER_LED_BT] = -1;
    }
    if (tempIsConnected) {
      led.setLedColor(CONF_BT_LED_NUMBER, LED_CLR_BLUE, led.getLedBrightness());
    } else {
      setLedDefault();  // no host — hand the LED back to the default path
    }
  }
  switchWindowWasOpen = switchWindowOpen;

  // (4.9.4 round 3) Never carry a drag/scroll latch across hosts — but the
  // 4.9.4 final-diff-audit (minor, confirmed) showed the round-3 window gate
  // reintroduced the exact class it was written to bound, by a different route:
  // the guard below is suppressed for the WHOLE window, the input polls stay
  // live, so a gesture engaged MID-WINDOW armed the latch while the guard was
  // down — and on the SUCCESS path (target admitted) tempIsConnected is true
  // on every later pass, so the latch crossed into the new host and swallowed
  // its first input (the SCROLL half unguarded end-to-end: cursorScroll sets
  // no wire state, so the take-and-clear disconnect-cleanup flag never raises;
  // DRAG was mostly caught by that flag within one main-loop pass). Two
  // triggers, each covering what the other misses:
  //   (a) the original disconnected-state guard — the pre-4.9.4 behavior for
  //       every non-window path, unchanged;
  //   (b) a HOST-IDENTITY edge (4.9.5): the connected host's MAC changed —
  //       none->target at admission, racer->none->target through the bounce
  //       storm, or host->host across a sub-second switch whose whole window
  //       fits between two 1 s polls (an ordering the reconciliation statics
  //       never observe). The key cannot reintroduce the bounce-storm churn
  //       the gate fixed: it flaps during bounces only while a latch is
  //       HELD, and the first edge releases it (outputAction -> NOTHING), so
  //       later flaps are no-ops and the LED/push narration stays suppressed.
  //   (b) releases through cancelSapOutputHold() — LED default paired with
  //       the release, matching the sensor-fault and unmount mirrors (the
  //       hold's window color must not outlive the latch). No action-bearing
  //       event either way.
  if (!switchWindowOpen && !tempIsConnected && (outputAction == CONF_ACTION_DRAG || outputAction == CONF_ACTION_SCROLL)) {
    releaseOutputAction();  // (a) disconnected with a held latch (never in a window — see the gate)
  }
  // The key the latch was armed under. s_latchGuardHostMac tracks the last
  // seen host; only a latch-HELD pass consults the crossing decision (a
  // latch-free pass cannot need a release), which is also what keeps the
  // bounce-storm churn suppressed: during bounces the key flaps, but the
  // first edge releases the latch, so every later flap is a no-op.
  // 4.9.7 (review B1, found independently by two reviewers): the key is now
  // refreshed on EVERY pass through lsHostLatchGuardPass (LSHostSwitch.h,
  // where the cadence is host-pinned), not only on held ones. The 4.9.6
  // shape refreshed inside the held branch only, so the key retained the
  // PREVIOUS episode's host across every latch-free stretch: boot with a
  // bonded host left it "" and a BT,1 switch left it pointing at the old
  // host — in both cases the user's FIRST drag/scroll on the new host
  // compared against the stale key, hit the crossing edge, and was killed
  // mid-hold by cancelSapOutputHold() (the exact one-swallowed-input class
  // 4.9.5/4.9.6 shipped to fix, reintroduced by the fix; live in the
  // published V4.9.6 binary). The compare-before-refresh order inside the
  // helper keeps the intended crossing protection: a hold that STARTS on a
  // host never sees a stale key, while a hold that CROSSES a host change
  // still releases on the first differing pass. lsHostActiveMac is a bounded
  // stack query, no FS — cheap and safe on every pass (it no-ops while the
  // stack is down, nothing is connected, or the peer is unbonded); STORED
  // BOND identity (stable across an RPA host's rotation).
  static char s_latchGuardHostMac[LSHOST_MAC_CHARS + 1] = "";
  // 4.9.9 review round 3: the previous pass's latch state — the guard's arm
  // rule needs it (a FIRST held pass arms under the current key instead of
  // comparing against the stored one; see lsHostLatchGuardPass).
  static bool s_latchGuardWasHeld = false;
  const bool latchHeld = (outputAction == CONF_ACTION_DRAG || outputAction == CONF_ACTION_SCROLL);
  char activeHostMac[LSHOST_MAC_CHARS + 1];
  const bool haveActiveHost = lsHostActiveMac(activeHostMac);
  const char* currentHostKey = haveActiveHost ? activeHostMac : "";
  if (lsHostLatchGuardPass(currentHostKey, s_latchGuardHostMac, sizeof(s_latchGuardHostMac), latchHeld ? 1 : 0, s_latchGuardWasHeld ? 1 : 0)) {
    cancelSapOutputHold();  // (b) the connected host changed under a held latch — the latch must not cross
  }
  s_latchGuardWasHeld = latchHeld;

  //if (USB_DEBUG) { Serial.println(tempIsConnected); }
  // 4.9.4 (round 3): the LED transition narration is suppressed for the
  // window's duration — see the switch-window gate above. A bounce is not a
  // host departure, and painting "disconnected / scanning" at the user while
  // they wait for the switch to complete (then repainting on the next cycle)
  // is narration of the lockout working, not of the device's state.
  if (switchWindowOpen) {
    // The window owns connection decisions; skip the transition block
    // entirely but still run the watchdog/push/tick below.
  } else
  // Perform Bluetooth LED blinking if Bluetooth is not connected and wasn't connected before
  if (g_comMode == CONF_COM_MODE_BLE && tempIsConnected == false && tempIsConnected == g_btIsConnected) {
    g_btIsConnected = false;
    const int blinkStartDelay = 0;
    if (ledTimerId[CONF_TIMER_LED_BT] < 0) {
      ledTimerId[CONF_TIMER_LED_BT] = ledStateTimer.setTimer(CONF_BT_SCAN_BLINK_DELAY, blinkStartDelay, ((CONF_BT_SCAN_BLINK_NUMBER * 2) + 1), ledBtScanEffect);
    }

  }  // Set the default LED effect if bluetooth connection state is changed
  else if (g_comMode == CONF_COM_MODE_BLE && tempIsConnected != g_btIsConnected) {
    g_btIsConnected = tempIsConnected;
    if (tempIsConnected) {
      // 4.5.28 bench report fix: on the CONNECTED transition, paint the solid
      // blue DIRECTLY from this poll's own result. setLedDefault() makes a
      // SECOND live isConnected() query, and during the pairing handshake
      // (the host connects, drops, and re-bonds around the exchange) that
      // second query can transiently disagree with this one — clearLedAll()
      // had already run, the blue branch didn't match, and the LED was left
      // dark with nothing repainting it in the steady state (the observed
      // bug: dark from pairing until an unrelated setLedDefault — a menu
      // exit — repainted it). The disconnected transition keeps the default
      // path; the scan blink re-arms within one poll.
      // 4.6.0 fix: the scan-blink timer armed during the (possibly long)
      // disconnected advertising window is still pending and its final run
      // lands on LED_CLR_NONE (off) — it clobbered the blue paint within
      // ~1.5 s and left the LED dark. Delete it before painting.
      if (ledTimerId[CONF_TIMER_LED_BT] >= 0) {
        ledStateTimer.deleteTimer(ledTimerId[CONF_TIMER_LED_BT]);
        ledTimerId[CONF_TIMER_LED_BT] = -1;
      }
      led.setLedColor(CONF_BT_LED_NUMBER, LED_CLR_BLUE, led.getLedBrightness());
    } else {
      if (ledTimerId[CONF_TIMER_LED_BT] >= 0) {
        ledStateTimer.deleteTimer(ledTimerId[CONF_TIMER_LED_BT]);
        ledTimerId[CONF_TIMER_LED_BT] = -1;
      }
      setLedDefault();
    }
  }

  // #16: the app's host list/active marker (BT,4/BT,5) is change-detected, so
  // this runs EVERY pass, not only on connect/disconnect transitions. The
  // transition-only shape left the app stale for the two events that land
  // AFTER the connect transition: a first pairing writes the bond file in the
  // lib's deferred callback (seconds after CONNECTED), and a reconnect's
  // bonding completes at CONN_SEC_UPDATE (also after the CONNECTED event) —
  // both were only picked up on the NEXT transition. The per-pass enumeration
  // is one LittleFS directory read over <=8 entries at the 1 s poll rate; the
  // boot prime keeps the first pass silent, and the change-detect keeps every
  // pass after it silent until something actually changes (the 4.5.29
  // healthy-boots-print-nothing contract; the CH,5 pattern).
  // 4.9.4 (round 3): suppressed while a switch window is open — during the
  // bouncer's connect/drop storm the ACTIVE ROW flaps (the bounced non-target
  // is briefly the connected-but-unbonded peer, then nothing, then the target
  // on success), so an ungated push narrated the lockout to the app as a
  // series of host changes and left the app's active marker depending on
  // which microsecond its poll landed in. The window's close path restores
  // stock radio state, and the next pass after it re-pushes the settled
  // truth through the normal change-detect.
  if (!switchWindowOpen) {
    lsHostPushState();
  }

  // HID-subscription watchdog (4.8.18, the bench 2026-11-07 "connected but
  // deaf" class): a bonded link whose HID subscription never re-enables is
  // cycled (bounded) so the state self-corrects instead of needing a host
  // toggle/reboot/re-pair. No-op unless BLE is up and no window is open.
  lsHidWatchdogLoop();

  // Multi-host switching (upstream #16) — whitelist switch window (bench B4):
  // drive the window tick in the feedback loop so the window can close
  // (target connected or timeout) even while no page is actively polling.
  // Window state (g_switchWindowOpen) is guarded by the loop task only.
  int w = lsHostSwitchWindowTick();
  (void)w;

  // 4.9.4 (round 7, fix-set audit): the tick above can CLOSE the window on
  // this very pass (target admitted, bound elapsed, bounce cap hit) — and this
  // pass's gate read the PRE-tick state, so the window-end reconciliation
  // (the LED repaint and the host-table push) could only ever happen on the
  // NEXT 1 s pass. The damage is bounded — lsHostPushState is change-detected
  // against persisted values, so a delayed push still lands, and the repaint
  // likewise lands one pass later — but the three consumers inside ONE pass
  // disagreed about whether a window was open, which is exactly the kind of
  // split-state the gate exists to eliminate. Re-evaluate after the tick so
  // the pass ends with every consumer agreeing, and run the reconciliation
  // immediately when this pass is the one that ended the window.
  if (switchWindowWasOpen && !lsHostSwitchWindowOpen()) {
    g_btIsConnected = btmouse.isConnected();
    if (ledTimerId[CONF_TIMER_LED_BT] >= 0) {
      ledStateTimer.deleteTimer(ledTimerId[CONF_TIMER_LED_BT]);
      ledTimerId[CONF_TIMER_LED_BT] = -1;
    }
    if (g_btIsConnected) {
      led.setLedColor(CONF_BT_LED_NUMBER, LED_CLR_BLUE, led.getLedBrightness());
    } else {
      setLedDefault();
    }
    switchWindowWasOpen = false;
    lsHostPushState();  // the settled truth, pushed from the pass that settled it
  }

  //if (USB_DEBUG) { Serial.println("USBDEBUG: end of btFeedbackLoop"); }
}

//***PERFORM LED ACTION FUNCTION***//
// Function   : performLedAction
//
// Description: This function performs LED actions based on led number, blink number, color number, blink delay, and brightness.
//
// Parameters : args : ledStateStruct* : It includes LED number, blink number, color number, blink delay, and brightness.
//
// Return     : void
//****************************************//
void performLedAction(ledStateStruct* args) {
  bootTrailStamp(4);  // witness v7: an LED action is running
  switch (args->ledAction)  // Get LED action
  {
    case LED_ACTION_NONE:
      {
        //setLedDefault(); // TODO Check to see if this should be uncommented
        break;
      }
    case LED_ACTION_OFF:
      {
        turnLedOff(args);
        break;
      }
    case LED_ACTION_ON:
      {
        turnLedOn(args);
        break;
      }
    case LED_ACTION_BLINK:
      {
        blinkLed(args);
        break;
      }

      /* case LED_ACTION_BLINKFAST:  // TODO 2025-Feb-21 Fix or remove blinkfast leds
    {
      blinkLedFast(args);
      break;
    }
    */
  }
}


//***SOFTWARE RESET FUNCTION***//
// Function   : softwareReset
//
// Description: This function initiates a software reset.
//
// Parameters :  none
//
// Return     : none
//******************************************//
// 4.9.9 review round 4 (the split of round 3's in-place guard): the
// endpoints that mutate live state or print an ack before resetting
// (OM/CM/MP/SR/RS/FR) call THIS first — on refusal nothing has been mutated
// and the endpoint answers FAIL,3. The menu paths call softwareReset()
// directly, whose own gate keeps them protected.
bool softwareResetGate() {
  // 4.9.9 review round 3 (the guard enterUpdateMode has always had): serial
  // dispatch AND the Hub menu are both reachable while the BLE init task is
  // inside Bluefruit.begin() (the menu input poll lives from setup; the
  // bench-documented wedged-SVC stall can stretch the window to seconds).
  // softwareReset()'s teardown would run Bluefruit teardown on the loop
  // task while the init task drives begin() on its own stack — undefined
  // behavior with the SD mid-enable, realistically a HardFault (the core's
  // handler resets instantly), which beats the intended SREQ and loses the
  // SR/CM/RS/FR ack. Wait the window out bounded, then fail SAFE like UM:
  // name the refusal, leave the device up, let a retry (or the 30 s DOG on
  // a truly wedged init) finish the job.
  {
    const unsigned long srWaitDeadlineMs = millis() + 2000;
    while (lipsyncRetentionUnsafe() && (long)(srWaitDeadlineMs - millis()) > 0) {
      if (g_watchdogArmed) watchdogLoop();  // the wait runs inside a dispatch/menu handler — keep the feed explicit
      delay(10);
    }
  }
  if (lipsyncRetentionUnsafe()) {
    // The witness exemption must not survive a refused shutdown: the format
    // path (FR) pre-sets the flag for its own window, and a refusal here
    // leaves the device very much alive.
    g_shutdownInProgress = false;
    serialTxEnqueueLine("ERROR: restart refused — the BLE init window is still open; retry in a moment");
    return false;
  }
  return true;
}

void softwareReset() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: softwareReset()"); }

  // 4.9.9 review round 4: the endpoints gate BEFORE their mutations/acks
  // (softwareResetGate); this second gate is instant for them (the window
  // cannot reopen — the init task runs once per boot) and is the sole
  // protection for the direct menu callers.
  if (!softwareResetGate()) {
    return;
  }

  g_shutdownInProgress = true;
  bootTrailStamp(5);  // witness v7: a software reset is starting — the next boot's pt=5 names this path

  // 4.9.4 (round 5, the ownership sweep): close any OPEN SWITCH WINDOW before
  // tearing the radio down. This is the SHARED reset path (CM/MP/SR/RS/FR and
  // both menu resets all funnel here), and every one of them can fire while a
  // window is open — the window's bound is 60 s, so a user who starts a
  // switch and then changes mode (or a remote app that resets) would otherwise
  // reset out from under live window state: g_switchWindowOpen still true, the
  // stock DISCONNECTED auto-restart still SUSPENDED (lsHostSuspendAutoRestart),
  // an armed target IRK, a bounce counter, and a deferred-advertising-restart
  // flag armed for a radio that is about to vanish. btmouse.end() below then
  // tears down the stack the window was mid-flight against, and the window's
  // pending INFO lines can interleave with the shutdown page's own output.
  // Closing first restores the stock radio state, so the reset happens from
  // exactly the state a normal reset does. Placed BEFORE the teardown calls
  // (not after) so the window never observes a half-dead stack.
  if (lsHostSwitchWindowOpen()) {
    lsHostCloseSwitchWindow();
  }

  // 4.9.8 (boot-bus fix D): quiesce every I2C-driving poll BEFORE the farewell
  // traffic. The CONF_RESET_DWELL_MS (3 s) used to leave the 20 ms screen
  // poll, the 20 ms joystick/scroll polls and the 50 ms pressure poll
  // transacting right up to NVIC_SystemReset() — a reset landing
  // mid-transaction strands a slave between protocol states, and the slave
  // then answers the SUCCESSOR boot's scan with a clean NACK forever (a clean
  // NACK never reaches the vendored Wire's timeout recovery — the 2026-11-15
  // field episode: every SR/CM/MP restart risked manufacturing the exact
  // "all devices missing" safe-mode boot the scan retry now heals). After
  // this point the ONLY I2C traffic in the reset path is the synchronous
  // restart-page push, the clear push, and the final bus-clear — each
  // bounded, each completing before the reset fires. The SCREEN poll is the
  // one that matters most: its pending state-timer callback (restartPage's
  // own scheduled finish) is the one framebuffer push that could otherwise
  // land inside the final milliseconds.
  pollTimer.disable(pollTimerId[CONF_TIMER_SCREEN]);
  pollTimer.disable(pollTimerId[CONF_TIMER_JOYSTICK]);
  pollTimer.disable(pollTimerId[CONF_TIMER_SCROLL]);
  pollTimer.disable(pollTimerId[CONF_TIMER_PRESSURE]);

  screen.restartPage();
  buzzer.playShutdownSound();

  releaseOutputAction();
  usbmouse.end();
  gamepad.end();
  btmouse.end();

  // 4.9.1: the dwell must DRAIN the response queue. The response-before-reset
  // guarantee (CM/MP/SR/RS/FR acks) silently depended on the CDC FIFO having
  // room: a host that stopped reading the IN pipe left the ack in the TX
  // queue, serialTxService wrote 0 bytes, and the reset below killed the
  // queue with the ack still in it — the port dropped with no response at
  // all. Servicing every 10 ms hands the queue the whole dwell.
  const unsigned long resetDwellDeadlineMs = millis() + CONF_RESET_DWELL_MS;
  while ((long)(resetDwellDeadlineMs - millis()) > 0) {
    serialTxService();
    delay(10);
  }
  screen.clear();

  // 4.9.8 (boot-bus fix D, second half): leave the bus IDLE at the reset
  // instant. The proactive bus-clear returns any slave the farewell pushes
  // left between protocol states to idle (bounded STOP, NXP 9-clock
  // bus-clear, explicit STOP), so the successor boot's scan probes a clean
  // bus instead of inheriting this session's tail. ~100 µs on a healthy bus;
  // stamps no recovery telemetry.
  Wire.busClear();

  NVIC_SystemReset();
  
}
