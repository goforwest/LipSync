/* 
* File: LSCircularBuffer.h
* Firmware: LipSync
* Developed by: MakersMakingChange
* Version: v4.1 (28 March 2025)
  License: GPL v3.0 or later

  Copyright (C) 2024 - 2025 Neil Squire Society
  This program is free software: you can redistribute it and/or modify it under the terms of
  the GNU General Public License as published by the Free Software Foundation,
  either version 3 of the License, or (at your option) any later version.
  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  You should have received a copy of the GNU General Public License along with this program.
  If not, see <http://www.gnu.org/licenses/>

  * Based on: CircularBuffer.h
*/

// Header definition
#ifndef _LSCIRCULARBUFFER_H
#define _LSCIRCULARBUFFER_H


// The definition of the CircularBuffer class.
template<typename T>
class LSCircularBuffer {
  public:
    LSCircularBuffer();
    ~LSCircularBuffer();
    LSCircularBuffer(const LSCircularBuffer&) = delete;
    LSCircularBuffer& operator=(const LSCircularBuffer&) = delete;
    T getElement( uint16_t );  // Zero is the MOST RECENTLY pushed element (4.9.1 doc fix: pushElement advances the pointer BEFORE writing, so index 0 reads the newest sample, and the next push lands one past it)
    void begin( uint16_t inputSize );
    void clear();
    void pushElement(const T elementVal);
    void updateLastElement(const T elementVal);
    T getLastElement( void ); 
    uint16_t getLength( void );

  private:
    uint16_t cBufferSize = 0;
    T *cBufferData = nullptr;  // null until begin() (the destructor checks)
    int32_t cBufferLastPtr = 0;
    uint16_t cBufferElementsUsed = 0;
};

//*********************************//
// Function   : LSCircularBuffer
//
// Description: Construct LSCircularBuffer. Storage is allocated by begin()
//              (no-arg ctor: members already value-initialized in-class);
//              the old inputSize-taking body is retired.
//
// Arguments :  void
//
// Return     : void
//*********************************//
template<typename T>
LSCircularBuffer<T>::LSCircularBuffer()
{
}

//*********************************//
// Function   : ~LSCircularBuffer 
// 
// Description: Destruct LSCircularBuffer
// 
// Arguments :  void
// 
// Return     : void
//*********************************//
template<typename T>
LSCircularBuffer<T>::~LSCircularBuffer()
{
  // begin() may never have run (LSPressure::begin is skipped when the
  // pressure sensors are absent) — delete[] on an uninitialized pointer
  // is UB. Only free what was allocated.
  if (cBufferData) delete[] cBufferData;
}

//*********************************//
// Function   : begin
//
// Description: create LSCircularBuffer type with arguments
//
// Arguments :  uint16_t inputSize: number of elements
//
// Return :  void
//*********************************//
template<typename T>
void LSCircularBuffer<T>::begin(uint16_t inputSize)
{
  // Value-initialize the storage (4.5.7 review): `new T[n]` left POD
  // elements as uninitialized heap, and getLastElement()/getElement() have
  // no empty-state check — a buffer whose begin() ran but whose seeding
  // push never did (LSPressure::begin is skipped when the pressure
  // sensors are absent, yet ps.getState() is still reachable from
  // joystickLoop's CF gate) read uninitialized memory into live logic.
  // Zeros are the harmless reading for every instantiation here (state
  // structs, points, pressures).
  if (cBufferData) {
    delete[] cBufferData;
    cBufferData = nullptr;
  }
  cBufferSize = 0;
  cBufferLastPtr = 0;
  cBufferElementsUsed = 0;
  if (inputSize == 0) return;

  cBufferData = new T[inputSize]();
  if (!cBufferData) return;
  cBufferLastPtr = 0;
  cBufferElementsUsed = 0;
  cBufferSize = inputSize;
}

//*********************************//
// Function   : clear
//
// Description: Discard every logical element while retaining the allocated
//              storage. The next push starts a fresh sample window.
//*********************************//
template<typename T>
void LSCircularBuffer<T>::clear()
{
  cBufferLastPtr = 0;
  cBufferElementsUsed = 0;
}

//*********************************//
// Function   : getElement 
// 
// Description: Get an element at some depth into the circular buffer
//              zero is the MOST RECENTLY pushed element (4.9.1 doc fix —
//              pushElement increments the pointer before writing, so the
//              push location of the NEXT element is one past index 0).
//              Max: cBufferSize - 1
//
// Arguments :  uint16_t elementNum: number of element in
// 
// Return     : element type T
//*********************************//
template<typename T>
T LSCircularBuffer<T>::getElement( uint16_t elementNum )
{
  if (cBufferData == nullptr || cBufferSize == 0) {
    return T{};
  }
  if (elementNum >= cBufferElementsUsed && cBufferElementsUsed > 0) {
    elementNum = cBufferElementsUsed - 1;
  } else if (cBufferElementsUsed == 0) {
    return T{};
  }
  // Translate elementNum into terms of cBufferLastPtr.
  // int32 arithmetic (the pointer's own width): an int16 here could go
  // negative despite the wrap fix below when a future instantiation grows
  // past 32 K elements and a deep index arrives — the bound then becomes
  // structural, not size-dependent.
  int32_t virtualElementNum = cBufferLastPtr - (int32_t)elementNum;
  if( virtualElementNum < 0 ) {
    virtualElementNum += cBufferSize;
  }
  
  // Output the value
  return cBufferData[virtualElementNum];
}

//*********************************//
// Function   : pushElement 
// 
// Description: Push a new element into the buffer
//              and expand the size up to the max size.
//
// Arguments :  T elementVal: value of new element
// 
// Return     : void
//*********************************//
template<typename T>
void LSCircularBuffer<T>::pushElement(const T elementVal )
{
  if (cBufferData == nullptr || cBufferSize == 0) return;
  // inc. the pointer
  cBufferLastPtr++;

  // deal with roll
  if( cBufferLastPtr >= cBufferSize ) {
    cBufferLastPtr = 0;
  }

  // Write data
  cBufferData[cBufferLastPtr] = elementVal;

  // Increase length up to cBufferSize
  if( cBufferElementsUsed < cBufferSize ) {
    cBufferElementsUsed++;
  }
}

//*********************************//
// Function   : updateLastElement 
// 
// Description: Update the last element pushed into the buffer.
//
// Arguments :  T elementVal: value of new element
// 
// Return     : void
//*********************************//
template<typename T>
void LSCircularBuffer<T>::updateLastElement(const T elementVal){
  if (cBufferData == nullptr || cBufferSize == 0 || cBufferElementsUsed == 0) return;
  // Write data
  cBufferData[cBufferLastPtr] = elementVal; 
}

//*********************************//
// Function   : getLastElement 
// 
// Description: Get the last element pushed into the buffer.
//
// Arguments :  void
// 
// Return     : void
//*********************************//
template<typename T>
T LSCircularBuffer<T>::getLastElement( void )
{
  if (cBufferData == nullptr || cBufferSize == 0 || cBufferElementsUsed == 0) {
    return T{};
  }
  // Output the value of last element
  return cBufferData[cBufferLastPtr];
}

//*********************************//
// Function   : getLength 
// 
// Description: Return the current size of the buffer
//
// Arguments :  void
// 
// Return     : uint16_t current size of the buffer
//*********************************//
template<typename T>
uint16_t LSCircularBuffer<T>::getLength( void )
{
  return cBufferElementsUsed;
}

#endif // _LSCIRCULARBUFFER_H
