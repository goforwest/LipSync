/* 
* File: LSWatchdog.h
* Firmware: LipSync
* Developed by: MakersMakingChange
* Version: v4.1 (28 March 2025)
  License: GPL v3.0 or later

  Copyright (C) 2024 - 2025 Neil Squire Society
  This program is free software: you can redistribute it and/or modify it under the terms of
  the GNU General Public License as published by the Free Software Foundation,
  either version 3 of the License, or (at your option) any later version.
  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.
  You should have received a copy of the GNU General Public License along with this program.
  If not, see <http://www.gnu.org/licenses/>
*/

// Header definition
#ifndef _LSWATCHDOG_H
#define _LSWATCHDOG_H

#include <nrf_wdt.h>
#include <hal/nrf_power.h>  //  Defines reset reasons for NRF52 (https://github.com/particle-iot/nrf5_sdk/blob/master/modules/nrfx/hal/nrf_power.h)

extern bool g_watchdogReset;
extern uint8_t g_watchdogBootCount;  // Consecutive watchdog-reset boots this power cycle (tracked in GPREGRET2)
extern uint8_t g_hangBootStreak;    // Consecutive witnessed loop-hang deaths (GPREGRET2 bits 0-1 — the functional budget)
extern bool g_usbRecoveryRestartedPrev; // Previous boot deliberately spent the one-shot USB recovery restart
extern unsigned long g_watchdogLastFeedMs;  // Loop-liveness witness (bench 2026-10-18): ms timestamp of the last feed
extern volatile bool g_watchdogArmed;        // True from initWatchdog() until the retry limit stops re-arming (ISR-read by the TIMER3 witness)
extern volatile uint32_t g_witnessSecondsUnfed;  // Witness-ISR <-> loop handshake (see LipSync_Firmware.ino)
extern uint32_t g_lastRebootReason;

//*********************************//
// Watchdog Functions
//*********************************//

//***CHECK RESET REASON FUNCTION***//
// Function   : initWatchdog
//
// Description: This function checks why the microcontroller was reset / powered.
//
// Parameters : void
//
// Return     : void
//****************************************//
void checkResetReason() {
  // Check the internal register for why the device was reset 
   
  // Determine last reset reason
    g_lastRebootReason = readResetReason(); // from Adafruit_nRF52_Arduino/cores/NRF/wiring.c

  	
  // Check why the device was reset
  if(USB_DEBUG) { Serial.print("Reset reason: "); }
  if ((g_lastRebootReason & NRF_POWER_RESETREAS_RESETPIN_MASK) == NRF_POWER_RESETREAS_RESETPIN_MASK) { 
    if(USB_DEBUG) { Serial.println("Reset Pin Reset"); }
  } else if ((g_lastRebootReason & NRF_POWER_RESETREAS_DOG_MASK) == NRF_POWER_RESETREAS_DOG_MASK) {
    if(USB_DEBUG) { Serial.println("Watchdog Reset"); }
    g_watchdogReset = true;
  } else if ((g_lastRebootReason & NRF_POWER_RESETREAS_SREQ_MASK) == NRF_POWER_RESETREAS_SREQ_MASK) {
    if(USB_DEBUG) { Serial.println("Software Reset"); }
  } else {
    if(USB_DEBUG) { Serial.println("Other reset"); }
  }

  // THE HANG-WITNESS STREAK (4.5.7 review) — the settling budget that
  // actually works on this platform. The old consecutive-watchdog-boot
  // counter never accumulated: the hardware watchdog reset WIPES
  // GPREGRET2 (bench-proven, 4.5.6 — every DOG-successor read the trail
  // at 0), so the "3-strike" budget was decorative; it is kept documented
  // as such. But the TIMER3 hang witness resets via SREQ, which PRESERVES
  // GPREGRET2 — so a streak of consecutive witnessed loop-hang deaths CAN
  // accumulate in bits 0-1:
  //   - Previous boot died in a witnessed hang (hang marker bits 2-4 set
  //     at death, still unread — setup() consumes them AFTER this
  //     function): streak = min(streak + 1, 3).
  //   - Previous boot ended any other way (clean power-cycle, reset pin,
  //     software reset, watchdog): streak = 0.
  // checkSafeMode() settles the device in safe mode at
  // CONF_WATCHDOG_BOOT_RETRY_LIMIT straight witnessed-hang/fault deaths, and
  // g_watchdogBootCount mirrors the streak so setup() stops re-arming TIMER3
  // on the settled boot. The nRF52 hardware WDT itself cannot be stopped once
  // started, so setup keeps feeding any inherited instance. A boot that stays up
  // for CONF_WATCHDOG_BOOT_CLEAR_MS clears the streak (watchdogLoop), so
  // isolated hangs never exhaust the budget. All writes touch only their
  // own bits; the trail lives in bits 5-7.
  uint8_t prevHangMarker = (uint8_t)((lipsyncRetentionGet(1) >> 2) & 0x07UL);  // 4.5.27: SD-aware
  g_usbRecoveryRestartedPrev = (prevHangMarker == CONF_RETENTION_MARKER_USB_RECOVERY);
  const bool previousBootCrashed = (prevHangMarker == CONF_RETENTION_MARKER_HANG)
                                || (prevHangMarker == CONF_RETENTION_MARKER_HARDFAULT);
  if (!g_watchdogReset && previousBootCrashed) {
    uint8_t hangStreak = (uint8_t)(lipsyncRetentionGet(1) & 0x03UL) + 1;
    if (hangStreak > 3) hangStreak = 3;
    lipsyncRetentionUpdate(1, 0x03, hangStreak);  // 4.5.27: SD-aware — a raw POWER write is an APP_MEMACC kill with the SD up
    g_hangBootStreak = hangStreak;
  } else {
    lipsyncRetentionUpdate(1, 0x03, 0);  // clear the streak — the previous boot did not die in a witnessed hang (4.5.27: SD-aware)
    g_hangBootStreak = 0;
  }
  // The watchdog-reset counter: a DOG reset wipes the register wholesale
  // (the witness-v8 fact), so this count cannot accumulate — it is always 1
  // after a watchdog boot (4.9.1: the old shape READ bits the else branch
  // above had just cleared, a structurally dead read that implied an
  // accumulation that cannot happen; set the documented value directly).
  // The 4.2.0 budget stays decorative; the hang streak above is the
  // functional settling path.
  if (g_watchdogReset) {
    g_watchdogBootCount = 1;
  } else {
    g_watchdogBootCount = g_hangBootStreak;
  }
}

//***INITIALIZE WATCHDOG FUNCTION***//
// Function   : initWatchdog
//
// Description: This function initializes the hardware watchdog
//
// Parameters : void
//
// Return     : void
//****************************************//
void initWatchdog() {
  if (USB_DEBUG) { Serial.println("USBDEBUG: initWatchdog()"); }
  // Configure watchdog timer with a defined timeout
  NRF_WDT->CONFIG = (WDT_CONFIG_HALT_Pause << WDT_CONFIG_HALT_Pos) |  // Pause while the CPU is halted (a debugger session does not get WDT-reset)
                    (WDT_CONFIG_SLEEP_Run << WDT_CONFIG_SLEEP_Pos);   // Keep running in sleep mode
  NRF_WDT->CRV = CONF_WATCHDOG_TIMEOUT_SEC * 32768;                   // Convert timeout in seconds to watchdog cycles (1 cycle = 1/32.768kHz)
  NRF_WDT->RREN |= WDT_RREN_RR0_Msk;                                  // Enable reload register 0
  NRF_WDT->TASKS_START = 1;                                           // Start watchdog
  g_watchdogArmed = true;
  NRF_WDT->RR[0] = WDT_RR_RR_Reload;                                  // Begin every setup with the full timeout budget
  g_watchdogLastFeedMs = millis();
}

//***WATCHDOG LOOP FUNCTION***//
// Function   : watchdogLoop
//
// Description: This function resets the watchdog timer to prevent reset
//
// Parameters : void
//
// Return     : void
//****************************************//
void watchdogLoop(void) {
  //if (USB_DEBUG) { Serial.println("USBDEBUG: watchDogLoop"); }

  if (g_watchdogArmed) {
    g_watchdogLastFeedMs = millis();
    g_witnessSecondsUnfed = 0;  // The loop is alive — reset the witness ISR's un-fed-seconds counter (4.5.7 review; a single aligned volatile store)
    NRF_WDT->RR[0] = WDT_RR_RR_Reload;  // Feed (reset) the watchdog timer
  }

  // A boot that stays up this long proves any hang was transient — restore
  // the full hang-streak budget for the next one (and the watchdog boot
  // count, for the DOG class).
  static bool watchdogBootCountCleared = false;
  if (!watchdogBootCountCleared && millis() > CONF_WATCHDOG_BOOT_CLEAR_MS) {
    // 4.5.27 (Fable 5.1 consult): THIS was the next scheduled death — the
    // 120 s streak-clear is a raw POWER write that runs on LIVE boots with
    // the SoftDevice up (the stamp fixes would only have moved the kill to
    // t=120 s). SD-aware now. 4.6.6: inside the Bluefruit.begin() window
    // neither path is safe — skip the clear (the next boot re-evaluates the
    // streak anyway; a 120 s cadence loses nothing to a sub-second skip).
    if (!lipsyncRetentionUnsafe()) {
      lipsyncRetentionUpdate(1, 0x03, 0);  // clear only the counter bits (the trail bits 5-7 stay)
    }
    watchdogBootCountCleared = true;
  }
}


#endif
