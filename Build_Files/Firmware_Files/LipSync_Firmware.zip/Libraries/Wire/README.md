# Wire (nRF52) — LipSync patched fork

Vendored fork of the `Wire` library bundled with `Seeeduino:nrf52@1.1.13`
(the core the LipSync firmware pins). Re-validate against the core's
`libraries/Wire/` if the core version is ever bumped — see
`.github/workflows/build_firmware.yml` for the pinned version.

## Why this fork exists

The stock driver waits on TWIM event registers with no bound
(`while (!EVENTS_LASTRX && !EVENTS_ERROR);`). If the I2C bus wedges — a
sensor browned-out mid-transaction holding SDA low, a damaged interface
cable (see upstream issue #73) — the event never fires and the transaction
never returns: the firmware's main loop hangs until the hardware watchdog
resets the device (~30 s of dead USB), or forever on watchdog-less boots
in older firmware.

## What changed

- Every TWIM event wait is bounded by `WIRE_TRANSACTION_TIMEOUT_MS`
  (50 ms — ~25x a full 100 kHz transaction, so healthy buses are
  unaffected). Since 4.5.7 the bound is one deadline **per call** shared
  across the call's sequential waits (per-wait bounds stacked to ~150 ms
  per transaction and ~21 transactions per SSD1306 framebuffer push);
  the STOP/SUSPEND waits never exit early on `EVENTS_ERROR` (the TWIM
  rejects a new START until the previous STOP completes — an early
  return manufactured a 50 ms wedge plus a spurious recovery on every
  poll of a merely absent device, and a stale `EVENTS_STOPPED` that
  disarmed the read path's STOP wait until the next recovery);
  `requestFrom` pre-clears `EVENTS_STOPPED`, clamps the read length to
  the 64-byte `rxBuffer`, and clears `ERRORSRC` on its error path so
  `endTransmission`'s next classification reads clean bits.
- On timeout, `wireRecoverBus()` runs: a bounded STOP, then the peripheral
  is disconnected and disabled, the pins are driven as GPIO for the NXP
  I2C bus-clear (I2C-bus spec 3.1.16: up to 9 SCL clocks — each verified
  to actually rise, since SCL is open-drain and a clock-stretching slave
  turns unverified clocks into silent no-ops — to release a
  slave stuck mid-byte), and the TWIM is re-attached and re-enabled. The
  pins' `PIN_CNF` registers are then restored to the `begin()`
  configuration (input, pull-up, open-drain) — the bus-clear leaves SCL as
  a GPIO output, which PSEL re-attachment makes benign, but a recovered
  bus should be bit-identical to a freshly begun one (4.3.0, roadmap
  item 4).
- The failing call then reports an error (`requestFrom` returns 0 bytes,
  `endTransmission` returns 4), which the firmware's sensor-health layer
  turns into "sensor unhealthy" — a slow re-probe cycle instead of a hang.
- `TwoWire::busHealthy()` reports false for a 1 s window after any recovery,
  letting firmware loops (joystick ticks, screen draws, the USB-retry page)
  back off all I2C while the bus is held — a held bus then costs one bounded
  recovery per window instead of a constant timeout tax.
- `TwoWire::recoveryCount()` / `TwoWire::lastRecoveryMs()` expose the
  recovery total and the millis() stamp of the latest one; the firmware's
  `BH` serial endpoint turns them into the "seconds since the bus last
  wedged" diagnostic (4.3.0, roadmap item 3).
- Since 4.5.17 the TWIM/TWIS interrupt priority is 7, not upstream's 3 —
  the bench (2026-10-26, rounds 8-11) pinned the actual S140 6.1.1
  SoftDevice-reserved priority set to {0, 1, 4} (the core's own TinyUSB
  port documents it; the stock example passes the SDM's enable check with
  USBD at 2), which also means upstream's 3 was legal all along — the
  first fix attempt (4.5.15, priority 4) was itself illegal and
  contributed to sd_softdevice_enable's 0x1001 refusal. Priority 7 is
  legal under both reservation models, never masked by FreeRTOS's
  BASEPRI=2 critical sections, and the handler calls no kernel APIs.

`Wire.h` differs from the core's copy only by the `busHealthy()`,
`recoveryCount()` and `lastRecoveryMs()` declarations and their comments;
everything else lives in `Wire_nRF52.cpp`, marked with `LipSync patch`
comment blocks.

## How the build uses it

- CI (`build_firmware.yml`) and the interface repo's local twin
  (`dev/firmware/build-firmware.sh`) pass this folder to
  `arduino-cli compile --libraries`, which takes precedence over the
  core's bundled Wire.
- Arduino IDE builders: copy this `Wire` folder into your sketchbook
  libraries directory (`~/Documents/Arduino/libraries/` on macOS,
  `~/Arduino/libraries/` on Windows/Linux) so it shadows the core's copy.
- Without this library the firmware still functions; the always-armed
  hardware watchdog (firmware 4.2.0+) recovers a wedged bus in ~30 s.
