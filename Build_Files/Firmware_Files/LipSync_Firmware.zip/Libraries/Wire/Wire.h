/*
 * TWI/I2C library for mRF5x
 * Copyright (c) 2015 Arduino LLC. All rights reserved.
 * Copyright (c) 2016 Sandeep Mistry All right reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef TwoWire_h
#define TwoWire_h

#include "nrf.h"

#include "Stream.h"
#include "variant.h"
#include "RingBuffer.h"

// WIRE_HAS_END means Wire has end()
#define WIRE_HAS_END 1

class TwoWire : public Stream
{
  public:
    TwoWire(NRF_TWIM_Type * p_twim, NRF_TWIS_Type * p_twis, IRQn_Type IRQn, uint8_t pinSDA, uint8_t pinSCL);
    void begin();
    void begin(uint8_t);
    void end();
    void setClock(uint32_t);
    void setPins(uint8_t pinSDA, uint8_t pinSCL);

    void beginTransmission(uint8_t);
    uint8_t endTransmission(bool stopBit);
    uint8_t endTransmission(void);

    uint8_t requestFrom(uint8_t address, size_t quantity, bool stopBit);
    uint8_t requestFrom(uint8_t address, size_t quantity);

    size_t write(uint8_t data);
    size_t write(const uint8_t * data, size_t quantity);

    virtual int available(void);
    virtual int read(void);
    virtual int peek(void);
    virtual void flush(void);

    void onReceive(void(*)(int));
    void onRequest(void(*)(void));
    void onService(void);

    // *** LipSync patch *** — implemented in Wire_nRF52.cpp
    // False while the bus is being held: a transaction hit the bounded-timeout
    // recovery path recently. Firmware loops consult this to back off all I2C
    // (joystick ticks, screen draws) so a held bus costs one bounded recovery
    // per WIRE_BUS_HOLD_DEBOUNCE_MS instead of a constant timeout tax.
    bool busHealthy();

    // *** LipSync patch *** — total bounded-timeout recoveries this boot.
    // Consumers compare it across an operation to detect that their own
    // transaction was the one that wedged (e.g. a display framebuffer push).
    uint32_t recoveryCount();

    // *** LipSync patch *** — the millis() stamp of the latest recovery
    // (0 when none happened this boot). The bus-health diagnostic endpoint
    // turns it into "seconds since the bus last wedged".
    unsigned long lastRecoveryMs();

    inline size_t write(unsigned long n) { return write((uint8_t)n); }
    inline size_t write(long n)          { return write((uint8_t)n); }
    inline size_t write(unsigned int n)  { return write((uint8_t)n); }
    inline size_t write(int n)           { return write((uint8_t)n); }
    using Print::write;

  private:
#if defined(NRF52) || defined(NRF52_SERIES)
    NRF_TWIM_Type * _p_twim;
    NRF_TWIS_Type * _p_twis;
#else
    NRF_TWI_Type * _p_twi;
#endif

    IRQn_Type _IRQn;

    uint8_t _uc_pinSDA;
    uint8_t _uc_pinSCL;

    bool master;
    bool receiving;
    bool transmissionBegun;
    bool suspended;

    // RX Buffer
    RingBuffer rxBuffer;

    // TX buffer
    RingBuffer txBuffer;
    uint8_t txAddress;

    // Callback user functions
    void (*onRequestCallback)(void);
    void (*onReceiveCallback)(int);

    // TWI clock frequency
    static const uint32_t TWI_CLOCK = 100000;
};

#if WIRE_INTERFACES_COUNT > 0
extern TwoWire Wire;
#endif

#if WIRE_INTERFACES_COUNT > 1
extern TwoWire Wire1;
#endif

#endif
